import 'package:bons_adua/noyau/calculs.dart';
import 'package:bons_adua/noyau/client.dart';
import 'package:bons_adua/noyau/operation.dart';
import 'package:flutter_test/flutter_test.dart';

int _n = 0;

Operation op(TypeOperation t, int montant, DateTime date,
    {String etat = etatValide}) {
  _n++;
  return Operation(
    cle: 'o$_n',
    clientCle: 'c1',
    clientRang: 1,
    type: t,
    montant: montant,
    dateOperation: date,
    saisieLe: date,
    etat: etat,
  );
}

void main() {
  final aujourdhui = DateTime(2026, 11, 22, 10, 0);

  group('solde', () {
    test('bons moins versements', () {
      final ops = [
        op(TypeOperation.bon, 10000, DateTime(2026, 10, 1)),
        op(TypeOperation.bon, 5000, DateTime(2026, 10, 5)),
        op(TypeOperation.versement, 4000, DateTime(2026, 10, 9)),
      ];
      expect(calculerSolde(ops), 11000);
    });

    test('les opérations annulées ou effacées sont ignorées', () {
      final ops = [
        op(TypeOperation.bon, 10000, DateTime(2026, 10, 1)),
        op(TypeOperation.bon, 7000, DateTime(2026, 10, 2), etat: etatAnnule),
        op(TypeOperation.versement, 3000, DateTime(2026, 10, 3),
            etat: etatEfface),
      ];
      expect(calculerSolde(ops), 10000);
    });

    test('appels et messages ne changent pas le solde', () {
      final ops = [
        op(TypeOperation.bon, 2000, DateTime(2026, 10, 1)),
        op(TypeOperation.appel, 0, DateTime(2026, 10, 2)),
        op(TypeOperation.message, 0, DateTime(2026, 10, 3)),
      ];
      expect(calculerSolde(ops), 2000);
    });
  });

  group('situation et retard', () {
    test('retard depuis le premier bon quand il n y a aucun versement', () {
      final s = calculerSituation(
        [op(TypeOperation.bon, 5000, DateTime(2026, 8, 24))],
        maintenant: aujourdhui,
      );
      expect(s.retardJours, 90);
      expect(s.horsTolerance, false); // 90 jours : pas strictement plus
    });

    test('hors tolérance au-delà de 90 jours', () {
      final s = calculerSituation(
        [op(TypeOperation.bon, 5000, DateTime(2026, 8, 23))],
        maintenant: aujourdhui,
      );
      expect(s.retardJours, 91);
      expect(s.horsTolerance, true);
    });

    test('retard depuis le dernier versement', () {
      final s = calculerSituation([
        op(TypeOperation.bon, 9000, DateTime(2026, 1, 1)),
        op(TypeOperation.versement, 1000, DateTime(2026, 11, 12)),
      ], maintenant: aujourdhui);
      expect(s.retardJours, 10);
      expect(s.horsTolerance, false);
      expect(s.du, 8000);
    });

    test('aucun retard si le client ne doit rien', () {
      final s = calculerSituation([
        op(TypeOperation.bon, 3000, DateTime(2025, 1, 1)),
        op(TypeOperation.versement, 3000, DateTime(2025, 1, 2)),
      ], maintenant: aujourdhui);
      expect(s.du, 0);
      expect(s.retardJours, isNull);
      expect(s.horsTolerance, false);
    });

    test('montant élevé : strictement au-dessus du seuil', () {
      final a = calculerSituation(
          [op(TypeOperation.bon, 10000, DateTime(2026, 11, 1))],
          maintenant: aujourdhui);
      final b = calculerSituation(
          [op(TypeOperation.bon, 10001, DateTime(2026, 11, 1))],
          maintenant: aujourdhui);
      expect(a.montantEleve, false);
      expect(b.montantEleve, true);
    });

    test('dernières dates par type', () {
      final s = calculerSituation([
        op(TypeOperation.bon, 100, DateTime(2026, 5, 1)),
        op(TypeOperation.bon, 100, DateTime(2026, 6, 1)),
        op(TypeOperation.appel, 0, DateTime(2026, 7, 1)),
        op(TypeOperation.message, 0, DateTime(2026, 8, 1)),
      ], maintenant: aujourdhui);
      expect(s.dernierBon, DateTime(2026, 6, 1));
      expect(s.dernierAppel, DateTime(2026, 7, 1));
      expect(s.dernierMessage, DateTime(2026, 8, 1));
      expect(s.dernierVersement, isNull);
    });

    test('montants du dernier bon et du dernier versement', () {
      final s = calculerSituation([
        op(TypeOperation.bon, 100, DateTime(2026, 5, 1)),
        op(TypeOperation.bon, 250, DateTime(2026, 6, 1)),
        op(TypeOperation.versement, 40, DateTime(2026, 6, 5)),
        op(TypeOperation.versement, 60, DateTime(2026, 6, 20)),
      ], maintenant: aujourdhui);
      expect(s.montantDernierBon, 250);
      expect(s.montantDernierVersement, 60);
    });
  });

  group('listes du tableau de bord', () {
    Client cl(String cle, int rang, {bool bloque = false}) => Client(
        cle: cle,
        rang: rang,
        nom: 'C$rang',
        bloque: bloque,
        creeLe: DateTime(2026, 1, 1));

    Situation sit(int du, {bool ht = false, bool eleve = false}) => Situation(
        du: du, retardJours: du > 0 ? 5 : null, horsTolerance: ht, montantEleve: eleve);

    final lignes = [
      LigneSuivi(cl('a', 1), sit(5000)),
      LigneSuivi(cl('b', 2, bloque: true), sit(20000, ht: true, eleve: true)),
      LigneSuivi(cl('c', 3), sit(0)),
      LigneSuivi(cl('d', 4, bloque: true), sit(0)),
      LigneSuivi(cl('e', 5), sit(30000, eleve: true)),
    ];

    test('synthèse', () {
      final s = calculerSynthese(lignes);
      expect(s.totalDu, 55000);
      expect(s.nbAvecDette, 3);
      expect(s.nbHorsTolerance, 1);
      expect(s.montantHorsTolerance, 20000);
      expect(s.nbMontantsEleves, 2);
      expect(s.nbBloques, 2);
    });

    test('filtre montants élevés : plus gros d abord', () {
      final r = filtrerLignes(lignes, FiltreListe.montantsEleves);
      expect(r.map((l) => l.client.rang), [5, 2]);
    });

    test('filtre bloqués : par rang, même sans dette', () {
      final r = filtrerLignes(lignes, FiltreListe.bloques);
      expect(r.map((l) => l.client.rang), [2, 4]);
    });

    test('filtre avec dette', () {
      final r = filtrerLignes(lignes, FiltreListe.avecDette);
      expect(r.map((l) => l.client.rang), [5, 2, 1]);
    });
  });

  group('affichage', () {
    test('formaterMontant', () {
      expect(formaterMontant(0), '0 F');
      expect(formaterMontant(950), '950 F');
      expect(formaterMontant(12500), '12 500 F');
      expect(formaterMontant(1234567), '1 234 567 F');
      expect(formaterMontant(-4000), '-4 000 F');
    });

    test('formaterDate', () {
      expect(formaterDate(DateTime(2026, 3, 5)), '05/03/2026');
    });

    test('remplirModele', () {
      expect(remplirModele('Bonjour [nom] ([rang])', {'nom': 'Moussa', 'rang': '12'}),
          'Bonjour Moussa (12)');
    });

    test('libelleRetard', () {
      expect(libelleRetard(1), '1 jour');
      expect(libelleRetard(45), '45 jours');
    });
  });
}
