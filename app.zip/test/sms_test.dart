import 'package:bons_adua/noyau/calculs.dart';
import 'package:bons_adua/noyau/client.dart';
import 'package:bons_adua/noyau/operation.dart';
import 'package:bons_adua/noyau/sms.dart';
import 'package:flutter_test/flutter_test.dart';

Operation op(String cle, TypeOperation t, int m, DateTime d,
    {String sms = 'en_attente', bool repris = false, String note = ''}) {
  return Operation(
    cle: cle,
    clientCle: 'c',
    clientRang: 7,
    type: t,
    montant: m,
    note: note,
    dateOperation: d,
    saisieLe: d,
    smsEtat: sms,
    smsRepris: repris,
  );
}

final client = Client(cle: 'c', rang: 7, nom: 'Moussa', creeLe: DateTime(2026, 1, 1));
const modBon = 'Bon [montant] [nom] [rang] avant [total_avant] apres [total_apres]';
const modVer = 'Vers [montant] reste [total_apres] avant [total_avant]';

void main() {
  group('heures calmes', () {
    test('22h-7h', () {
      expect(dansHeuresCalmes(DateTime(2026, 1, 1, 23), 22, 7), true);
      expect(dansHeuresCalmes(DateTime(2026, 1, 1, 3), 22, 7), true);
      expect(dansHeuresCalmes(DateTime(2026, 1, 1, 7), 22, 7), false);
      expect(dansHeuresCalmes(DateTime(2026, 1, 1, 12), 22, 7), false);
      expect(dansHeuresCalmes(DateTime(2026, 1, 1, 22), 22, 7), true);
    });
  });

  group('decider', () {
    final maintenant = DateTime(2026, 11, 23, 12);
    DecisionSms d(Operation o, DateTime m) => decider(o,
        maintenant: m, delaiMaxHeures: 48, calmeDebut: 22, calmeFin: 7);

    test('envoi normal', () {
      expect(d(op('a', TypeOperation.bon, 100, DateTime(2026, 11, 23, 11)), maintenant),
          DecisionSms.envoyer);
    });
    test('trop ancien : expire', () {
      expect(d(op('a', TypeOperation.bon, 100, DateTime(2026, 11, 20, 11)), maintenant),
          DecisionSms.expirer);
    });
    test('trop ancien mais renvoi manuel : envoyé', () {
      expect(
          d(op('a', TypeOperation.bon, 100, DateTime(2026, 11, 20, 11), repris: true),
              maintenant),
          DecisionSms.envoyer);
    });
    test('heures calmes : attendre', () {
      expect(d(op('a', TypeOperation.bon, 100, DateTime(2026, 11, 23, 21)),
              DateTime(2026, 11, 23, 23)),
          DecisionSms.attendre);
    });
    test('déjà envoyé : ignorer', () {
      expect(
          d(op('a', TypeOperation.bon, 100, DateTime(2026, 11, 23, 11), sms: 'envoye'),
              maintenant),
          DecisionSms.ignorer);
    });
  });

  group('composerSms', () {
    final b1 = op('b1', TypeOperation.bon, 5000, DateTime(2026, 11, 1));
    final v1 = op('v1', TypeOperation.versement, 2000, DateTime(2026, 11, 5));
    final b2 = op('b2', TypeOperation.bon, 3000, DateTime(2026, 11, 10));
    final tous = [b1, v1, b2];

    test('bon : avant et après', () {
      final t = composerSms(b2, tous, client, modeleBon: modBon, modeleVersement: modVer);
      expect(t, 'Bon 3 000 F Moussa 7 avant 3 000 F apres 6 000 F');
    });
    test('versement : reste à payer', () {
      final t = composerSms(v1, tous, client, modeleBon: modBon, modeleVersement: modVer);
      expect(t, 'Vers 2 000 F reste 3 000 F avant 5 000 F');
    });
    test('une opération annulée ne compte pas', () {
      final annule = b1.avecEtat(etatAnnule, motif: 'erreur');
      final t = composerSms(b2, [annule, v1, b2], client,
          modeleBon: modBon, modeleVersement: modVer);
      expect(t, 'Bon 3 000 F Moussa 7 avant -2 000 F apres 1 000 F');
    });
    test('message manuel : texte tel quel', () {
      final m = op('m', TypeOperation.message, 0, DateTime(2026, 11, 11), note: 'Bonjour');
      expect(composerSms(m, tous, client, modeleBon: modBon, modeleVersement: modVer),
          'Bonjour');
    });
  });

  group('relance', () {
    final maintenant = DateTime(2026, 11, 23);
    Situation s({bool ht = true, DateTime? msg}) =>
        Situation(du: 5000, horsTolerance: ht, dernierMessage: msg);

    test('jamais relancé : due', () => expect(relanceDue(s(), maintenant, 30), true));
    test('relancé il y a 10 jours : pas due',
        () => expect(relanceDue(s(msg: DateTime(2026, 11, 13)), maintenant, 30), false));
    test('relancé il y a 30 jours : due',
        () => expect(relanceDue(s(msg: DateTime(2026, 10, 24)), maintenant, 30), true));
    test('dans la tolérance : jamais',
        () => expect(relanceDue(s(ht: false), maintenant, 30), false));
    test('clé de relance du jour', () {
      expect(cleRelance('abc', DateTime(2026, 3, 5, 9)), 'relance_abc_2026-03-05');
    });
    test('numéro nettoyé', () {
      expect(numeroPourSms('+227 96-45 67 13'), '+227964567 13'.replaceAll(' ', ''));
    });
  });
}
