import 'package:bons_adua/noyau/calculs.dart';
import 'package:bons_adua/noyau/client.dart';
import 'package:bons_adua/noyau/operation.dart';
import 'package:bons_adua/services/rapport_pdf.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final client = Client(
      cle: 'c',
      rang: 12,
      nom: 'Élodie Œuvre — test',
      telephone1: '96 45 67 13',
      creeLe: DateTime(2026, 1, 1));
  Operation op(String cle, TypeOperation t, int m, DateTime d,
          {String etat = etatValide}) =>
      Operation(
        cle: cle,
        clientCle: 'c',
        clientRang: 12,
        type: t,
        montant: m,
        note: 'Note avec accents é à ç et signes — ’ …',
        dateOperation: d,
        saisieLe: d,
        etat: etat,
        annuleMotif: 'erreur de saisie',
      );
  final ops = [
    op('1', TypeOperation.bon, 5000, DateTime(2026, 9, 1)),
    op('2', TypeOperation.versement, 1000, DateTime(2026, 9, 10)),
    op('3', TypeOperation.bon, 7000, DateTime(2026, 9, 20), etat: etatAnnule),
    op('4', TypeOperation.appel, 0, DateTime(2026, 10, 1)),
  ];
  final sit = calculerSituation(ops, maintenant: DateTime(2026, 11, 23));

  test('relevé résumé : fichier PDF', () async {
    final b = await releveClient(
        client: client,
        operations: ops,
        situation: sit,
        complet: false,
        date: DateTime(2026, 11, 23));
    expect(String.fromCharCodes(b.take(4)), '%PDF');
  });

  test('relevé complet : fichier PDF', () async {
    final b = await releveClient(
        client: client,
        operations: ops,
        situation: sit,
        complet: true,
        date: DateTime(2026, 11, 23));
    expect(String.fromCharCodes(b.take(4)), '%PDF');
  });

  test('liste de comptes : fichier PDF', () async {
    final b = await listeClients(
        titre: 'Test',
        sousTitre: 'sous-titre',
        lignes: [LigneSuivi(client, sit)],
        date: DateTime(2026, 11, 23));
    expect(String.fromCharCodes(b.take(4)), '%PDF');
  });

  test('relevé sans opération', () async {
    final b = await releveClient(
        client: client,
        operations: const <Operation>[],
        situation: const Situation(du: 0),
        complet: true,
        date: DateTime(2026, 11, 23));
    expect(b.length, greaterThan(500));
  });
}
