import 'package:bons_adua/noyau/client.dart';
import 'package:bons_adua/noyau/rangs.dart';
import 'package:bons_adua/noyau/texte.dart';
import 'package:flutter_test/flutter_test.dart';

Client c(
  String cle,
  int rang, {
  DateTime? le,
  bool actif = true,
  int decalage = 0,
}) {
  return Client(
    cle: cle,
    rang: rang,
    nom: 'Client $cle',
    actif: actif,
    creeLe: le ?? DateTime(2026, 1, 1, 10, 0),
    decalageHorlogeMs: decalage,
  );
}

void main() {
  group('texte', () {
    test('normaliser retire accents, majuscules et espaces en trop', () {
      expect(normaliser('  Élodie   ÇA  '), 'elodie ca');
      expect(normaliser('MOUSSA'), 'moussa');
      expect(normaliser('Hélène Œuvre'), 'helene oeuvre');
    });

    test('chiffres garde seulement les chiffres', () {
      expect(chiffres('+227 96 45 67 13'), '22796456713');
      expect(chiffres('96-45-67-13'), '96456713');
      expect(chiffres('abc'), '');
    });
  });

  group('premierRangLibre', () {
    test('aucun rang pris : 1', () {
      expect(premierRangLibre(<int>[]), 1);
    });

    test('trouve le premier trou', () {
      expect(premierRangLibre(<int>[1, 2, 4, 5]), 3);
      expect(premierRangLibre(<int>[2, 3]), 1);
    });

    test('un rang libéré redevient libre', () {
      expect(premierRangLibre(<int>[1, 3]), 2);
    });

    test('1000 rangs pris : null', () {
      final tous = List<int>.generate(1000, (i) => i + 1);
      expect(premierRangLibre(tous), isNull);
      tous.remove(777);
      expect(premierRangLibre(tous), 777);
    });
  });

  group('etatsConflit', () {
    test('rangs tous différents : aucun conflit', () {
      final r = etatsConflit(<Client>[c('a', 1), c('b', 2), c('c', 3)]);
      expect(r['a'], false);
      expect(r['b'], false);
      expect(r['c'], false);
    });

    test('le plus ancien garde le rang, l autre est en conflit', () {
      final ancien = c('x', 5, le: DateTime(2026, 1, 1, 9, 0));
      final recent = c('y', 5, le: DateTime(2026, 1, 1, 12, 0));
      final r = etatsConflit(<Client>[recent, ancien]);
      expect(r['x'], false);
      expect(r['y'], true);
    });

    test('à égalité d heure, la plus petite clé garde le rang', () {
      final r = etatsConflit(<Client>[c('b', 7), c('a', 7)]);
      expect(r['a'], false);
      expect(r['b'], true);
    });

    test('l écart d horloge corrige l ancienneté', () {
      // A a été saisi à 10h00, B à 09h59 mais son horloge retardait de 2 min :
      // en heure serveur B est à 10h01, donc A est le plus ancien.
      final a = c('a', 3, le: DateTime(2026, 1, 1, 10, 0));
      final b = c('b', 3,
          le: DateTime(2026, 1, 1, 9, 59), decalage: 120000);
      final r = etatsConflit(<Client>[b, a]);
      expect(r['a'], false);
      expect(r['b'], true);
    });

    test('un client supprimé est ignoré et libère le conflit', () {
      final gagnant = c('x', 5, le: DateTime(2026, 1, 1, 9, 0), actif: false);
      final autre = c('y', 5, le: DateTime(2026, 1, 1, 12, 0));
      final r = etatsConflit(<Client>[gagnant, autre]);
      expect(r.containsKey('x'), false);
      expect(r['y'], false);
    });

    test('trois clients sur le même rang : un seul garde le numéro', () {
      final r = etatsConflit(<Client>[
        c('a', 9, le: DateTime(2026, 1, 1, 11, 0)),
        c('b', 9, le: DateTime(2026, 1, 1, 8, 0)),
        c('c', 9, le: DateTime(2026, 1, 1, 10, 0)),
      ]);
      expect(r['b'], false);
      expect(r['c'], true);
      expect(r['a'], true);
    });
  });
}
