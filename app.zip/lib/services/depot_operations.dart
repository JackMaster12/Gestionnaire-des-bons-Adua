import '../donnees/firebase.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../constantes.dart';
import '../noyau/calculs.dart';
import '../noyau/client.dart';
import '../noyau/operation.dart';
import 'appareil_service.dart';
import 'depot_parametres.dart';
import 'journal_service.dart';
import 'outils.dart';
import 'suivi_collection.dart';

/// Toutes les opérations (bons, versements, appels, messages).
/// Une opération n'est jamais modifiée : seul son état peut changer
/// (annulée, effacée).
class DepotOperations extends ChangeNotifier {
  DepotOperations._();
  static final DepotOperations instance = DepotOperations._();

  late final SuiviCollection<Operation> _suivi = SuiviCollection<Operation>(
    collection: colOperations,
    construire: _depuisDonnees,
    surChangement: _recalculer,
  );

  Map<String, List<Operation>> _parClient = <String, List<Operation>>{};

  bool get pret => _suivi.pret;

  void demarrer() {
    lancer(() => _suivi.demarrer());
  }

  void arreter() {
    _suivi.arreter();
    _parClient = <String, List<Operation>>{};
  }

  static DateTime _date(Object? v, DateTime defaut) =>
      v is Timestamp ? v.toDate() : defaut;

  static Operation _depuisDonnees(String id, Map<String, dynamic> d) {
    final maintenant = DateTime.now();
    final saisie = _date(d['saisieLe'], maintenant);
    return Operation(
      cle: id,
      clientCle: (d['clientCle'] ?? '') as String,
      clientRang: (d['clientRang'] as num?)?.toInt() ?? 0,
      type: typeDepuisCode((d['type'] ?? '') as String) ?? TypeOperation.appel,
      montant: (d['montant'] as num?)?.toInt() ?? 0,
      note: (d['note'] ?? '') as String,
      dateOperation: _date(d['dateOperation'], saisie),
      saisieLe: saisie,
      etat: (d['etat'] ?? etatValide) as String,
      annuleMotif: (d['annuleMotif'] ?? '') as String,
      parNom: (d['parNom'] ?? '') as String,
      smsEtat: (d['smsEtat'] ?? 'aucun') as String,
      smsErreur: (d['smsErreur'] ?? '') as String,
      smsTexte: (d['smsTexte'] ?? '') as String,
      smsRepris: (d['smsRepris'] ?? false) as bool,
    );
  }

  static Map<String, dynamic> donneesPour(Operation o) {
    return <String, dynamic>{
      'cle': o.cle,
      'clientCle': o.clientCle,
      'clientRang': o.clientRang,
      'type': o.type.name,
      'montant': o.montant,
      'note': o.note,
      'dateOperation': Timestamp.fromDate(o.dateOperation),
      'saisieLe': Timestamp.fromDate(o.saisieLe),
      'etat': o.etat,
      'annuleMotif': o.annuleMotif,
      'parNom': o.parNom,
      'smsEtat': o.smsEtat,
      'smsErreur': o.smsErreur,
      'smsTexte': o.smsTexte,
      'smsRepris': o.smsRepris,
    };
  }

  void _recalculer() {
    final m = <String, List<Operation>>{};
    for (final o in _suivi.elements.values) {
      if (o.etat == etatEfface) continue;
      m.putIfAbsent(o.clientCle, () => <Operation>[]).add(o);
    }
    for (final l in m.values) {
      l.sort(comparerOperations);
    }
    _parClient = m;
    notifyListeners();
  }

  // ---------- Lecture ----------

  /// Opérations d'un client (annulées comprises), de la plus ancienne à la plus récente.
  List<Operation> deClient(String clientCle) =>
      _parClient[clientCle] ?? const <Operation>[];

  Situation situationDe(String clientCle) {
    final p = DepotParametres.instance;
    return calculerSituation(
      deClient(clientCle),
      maintenant: DateTime.now(),
      tolerance: p.toleranceJours,
      seuil: p.seuilMontant,
    );
  }

  List<LigneSuivi> lignes(Iterable<Client> clients) {
    return clients.map((c) => LigneSuivi(c, situationDe(c.cle))).toList();
  }

  bool existe(String cle) => _suivi.elements.containsKey(cle);

  // ---------- File des SMS ----------

  /// Opérations dont le SMS est dans l'un de ces états (plus ancien d'abord).
  List<Operation> smsDansEtats(Set<String> etats) {
    final liste = _suivi.elements.values
        .where((o) => o.etat != etatEfface && etats.contains(o.smsEtat))
        .toList();
    liste.sort((a, b) => a.saisieLe.compareTo(b.saisieLe));
    return liste;
  }

  int get nombreSmsEnAttente =>
      smsDansEtats(<String>{'en_attente', 'en_cours'}).length;

  /// Change l'état d'envoi d'un SMS (seul le téléphone expéditeur l'utilise,
  /// plus « Réessayer » à la main).
  void majSms(
    Operation op, {
    required String etat,
    String erreur = '',
    String texte = '',
    bool? repris,
  }) {
    final ref = FirebaseFirestore.instance.collection(colOperations).doc(op.cle);
    final champs = <String, dynamic>{
      'smsEtat': etat,
      'smsErreur': erreur,
      'smsMajLe': FieldValue.serverTimestamp(),
      'majLe': FieldValue.serverTimestamp(),
    };
    if (texte.isNotEmpty) champs['smsTexte'] = texte;
    if (repris != null) champs['smsRepris'] = repris;
    if (etat == 'envoye') champs['smsEnvoyeLe'] = FieldValue.serverTimestamp();
    lancer(() => ref.update(champs));
    _suivi.injecter(
        op.cle,
        op.avecSms(
            etat: etat,
            erreur: erreur,
            texte: texte.isEmpty ? null : texte,
            repris: repris));
    _recalculer();
  }

  // ---------- Écriture (hors ligne : partent à la reconnexion) ----------

  Future<Operation> ajouter({
    required Client client,
    required TypeOperation type,
    required int montant,
    required String note,
    required DateTime date,
    required String parNom,
    String? cleImposee,
    String origine = 'manuel',
  }) async {
    final cle = cleImposee ?? const Uuid().v4();
    final existante = _suivi.elements[cle];
    if (existante != null) return existante;
    final maintenant = DateTime.now();
    final avecSms = type != TypeOperation.appel &&
        client.telephone1.trim().isNotEmpty;
    final op = Operation(
      cle: cle,
      clientCle: client.cle,
      clientRang: client.rang,
      type: type,
      montant: montant,
      note: note.trim(),
      dateOperation: date,
      saisieLe: maintenant,
      parNom: parNom,
      smsEtat: avecSms ? 'en_attente' : 'aucun',
    );
    final appareil = await ServiceAppareil.id();
    final user = FirebaseAuth.instance.currentUser;
    final donnees = donneesPour(op)
      ..['creePar'] = user?.uid ?? ''
      ..['appareilId'] = appareil
      ..['origine'] = origine
      ..['majLe'] = FieldValue.serverTimestamp();
    final ref = FirebaseFirestore.instance.collection(colOperations).doc(cle);
    lancer(() => ref.set(donnees));
    _suivi.injecter(cle, op);
    _recalculer();
    Journal.ecrire('operation_${type.name}',
        detail: 'rang ${client.rang} - ${client.nom} - $montant F');
    return op;
  }

  void annuler(Operation op, String motif, String parNom) {
    final user = FirebaseAuth.instance.currentUser;
    final ref = FirebaseFirestore.instance.collection(colOperations).doc(op.cle);
    lancer(() => ref.update(<String, dynamic>{
          'etat': etatAnnule,
          'annuleMotif': motif,
          'annuleLe': FieldValue.serverTimestamp(),
          'annulePar': user?.uid ?? '',
          'annuleParNom': parNom,
          'majLe': FieldValue.serverTimestamp(),
        }));
    _suivi.injecter(op.cle, op.avecEtat(etatAnnule, motif: motif));
    _recalculer();
    Journal.ecrire('operation_annulee',
        detail:
            '${libelleType(op.type)} ${op.montant} F, rang ${op.clientRang} - $motif');
  }

  /// Retire tout l'historique d'un client (état « effacé » : les lignes
  /// restent dans la base mais ne comptent plus et ne s'affichent plus).
  void effacerHistorique(Client client, String parNom) {
    final db = FirebaseFirestore.instance;
    final ops = deClient(client.cle).toList();
    var lot = db.batch();
    var n = 0;
    for (final o in ops) {
      lot.update(db.collection(colOperations).doc(o.cle), <String, dynamic>{
        'etat': etatEfface,
        'majLe': FieldValue.serverTimestamp(),
      });
      _suivi.injecter(o.cle, o.avecEtat(etatEfface));
      n++;
      if (n == 400) {
        final envoi = lot;
        lancer(() => envoi.commit());
        lot = db.batch();
        n = 0;
      }
    }
    if (n > 0) {
      final envoi = lot;
      lancer(() => envoi.commit());
    }
    _recalculer();
    Journal.ecrire('historique_efface',
        detail: 'rang ${client.rang} - ${client.nom} (${ops.length} opérations)');
  }
}
