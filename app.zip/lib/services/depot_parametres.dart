import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../constantes.dart';
import 'journal_service.dart';
import 'outils.dart';

/// Paramètres de l'application (tolérance, seuil, modèles de SMS).
class DepotParametres extends ChangeNotifier {
  DepotParametres._();
  static final DepotParametres instance = DepotParametres._();

  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _abonnement;

  int toleranceJours = 90;
  int seuilMontant = 10000;
  String modeleRelance = parametresParDefaut()['modeleRelance'] as String;
  String modeleSmsBon = parametresParDefaut()['modeleSmsBon'] as String;
  String modeleSmsVersement =
      parametresParDefaut()['modeleSmsVersement'] as String;
  int delaiMaxSmsHeures = 48;
  int heuresCalmesDebut = 22;
  int heuresCalmesFin = 7;
  int pauseSmsSecondes = 4;
  int simIndex = 1;
  String appareilExpediteurId = '';
  bool relanceAutoActive = true;
  int relanceAutoHeure = 9;
  int relanceAutoIntervalleJours = 30;

  DocumentReference<Map<String, dynamic>> get _ref => FirebaseFirestore
      .instance
      .collection(colParametres)
      .doc(docParametres);

  void demarrer() {
    if (_abonnement != null) return;
    _abonnement = _ref.snapshots().listen((snap) {
      final d = snap.data();
      if (d != null) {
        toleranceJours = (d['toleranceJours'] as num?)?.toInt() ?? 90;
        seuilMontant = (d['seuilMontant'] as num?)?.toInt() ?? 10000;
        final m = d['modeleRelance'];
        if (m is String && m.trim().isNotEmpty) modeleRelance = m;
        final b = d['modeleSmsBon'];
        if (b is String && b.trim().isNotEmpty) modeleSmsBon = b;
        final v = d['modeleSmsVersement'];
        if (v is String && v.trim().isNotEmpty) modeleSmsVersement = v;
        int entier(String k, int defaut) => (d[k] as num?)?.toInt() ?? defaut;
        delaiMaxSmsHeures = entier('delaiMaxSmsHeures', 48);
        heuresCalmesDebut = entier('heuresCalmesDebut', 22);
        heuresCalmesFin = entier('heuresCalmesFin', 7);
        pauseSmsSecondes = entier('pauseSmsSecondes', 4);
        simIndex = entier('simIndex', 1);
        appareilExpediteurId = (d['appareilExpediteurId'] ?? '') as String;
        relanceAutoActive = (d['relanceAutoActive'] ?? true) as bool;
        relanceAutoHeure = entier('relanceAutoHeure', 9);
        relanceAutoIntervalleJours = entier('relanceAutoIntervalleJours', 30);
      }
      notifyListeners();
    }, onError: (Object _) {});
  }

  void arreter() {
    _abonnement?.cancel();
    _abonnement = null;
  }

  /// Enregistre des champs (la valeur revient toute seule par l'écoute).
  void modifier(Map<String, dynamic> champs, {String journal = ''}) {
    lancer(() => _ref.set(<String, dynamic>{
          ...champs,
          'majLe': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true)));
    if (journal.isNotEmpty) Journal.ecrire('parametres_modifies', detail: journal);
  }

  void enregistrerSeuils({required int tolerance, required int seuil}) {
    toleranceJours = tolerance;
    seuilMontant = seuil;
    notifyListeners();
    lancer(() => _ref.set(<String, dynamic>{
          'toleranceJours': tolerance,
          'seuilMontant': seuil,
          'majLe': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true)));
    Journal.ecrire('parametres_modifies',
        detail: 'tolérance $tolerance j, seuil $seuil F');
  }
}
