import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';

import '../constantes.dart';
import 'journal_service.dart';
import 'outils.dart';

/// Paramètres de l'application (tolérance, seuil, modèles de SMS).
class DepotParametres extends ChangeNotifier {
  DepotParametres._();
  static final DepotParametres instance = DepotParametres._();

  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _abonnement;

  int toleranceJours = 90;
  int seuilMontant = 10000;
  String modeleRelance = parametresParDefaut()['modeleRelance'] as String;

  DocumentReference<Map<String, dynamic>> get _ref => FirebaseFirestore
      .instance
      .collection(colParametres)
      .doc(docParametres);

  void demarrer() {
    if (_abonnement != null) return;
    _abonnement = _ref.snapshots().listen((snap) {
      final d = snap.data();
      if (d != null) {
        toleranceJours = (d['toleranceJours'] as num?)?.toInt() ?? 90;
        seuilMontant = (d['seuilMontant'] as num?)?.toInt() ?? 10000;
        final m = d['modeleRelance'];
        if (m is String && m.trim().isNotEmpty) modeleRelance = m;
      }
      notifyListeners();
    }, onError: (Object _) {});
  }

  void arreter() {
    _abonnement?.cancel();
    _abonnement = null;
  }

  void enregistrerSeuils({required int tolerance, required int seuil}) {
    toleranceJours = tolerance;
    seuilMontant = seuil;
    notifyListeners();
    lancer(() => _ref.set(<String, dynamic>{
          'toleranceJours': tolerance,
          'seuilMontant': seuil,
          'majLe': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true)));
    Journal.ecrire('parametres_modifies',
        detail: 'tolérance $tolerance j, seuil $seuil F');
  }
}
