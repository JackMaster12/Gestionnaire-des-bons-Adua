import 'dart:async';

import 'package:flutter/foundation.dart';

import '../noyau/sms.dart';
import 'appareil_service.dart';
import 'depot_clients.dart';
import 'depot_operations.dart';
import 'depot_parametres.dart';
import 'outils.dart';
import 'relance_service.dart';
import 'sms_natif.dart';

/// Envoi des SMS : tourne uniquement sur le téléphone désigné comme expéditeur,
/// tant que l'application est ouverte. Il vide la file « en attente » et crée
/// chaque jour les relances automatiques.
class ServiceSms extends ChangeNotifier {
  ServiceSms._();
  static final ServiceSms instance = ServiceSms._();

  Timer? _minuteur;
  bool _occupe = false;
  bool _ecranMis = false;
  DateTime? _derniereRelanceAuto;

  /// Dernier problème rencontré (affiché dans Paramètres).
  String dernierMessage = '';

  /// Cet appareil est-il l'expéditeur désigné ?
  bool estExpediteur = false;
  bool permissionOk = false;

  void demarrer() {
    if (!SmsNatif.disponible || _minuteur != null) return;
    _minuteur = Timer.periodic(const Duration(seconds: 30), (_) => _declencher());
    DepotOperations.instance.addListener(_declencher);
    DepotParametres.instance.addListener(_declencher);
    _declencher();
  }

  void arreter() {
    _minuteur?.cancel();
    _minuteur = null;
    DepotOperations.instance.removeListener(_declencher);
    DepotParametres.instance.removeListener(_declencher);
    if (_ecranMis) SmsNatif.ecranAllume(false);
    _ecranMis = false;
    estExpediteur = false;
  }

  void _declencher() {
    lancer(_cycle);
  }

  void _noter(String message) {
    if (message != dernierMessage) {
      dernierMessage = message;
      notifyListeners();
    }
  }

  Future<void> _cycle() async {
    if (_occupe) return;
    _occupe = true;
    try {
      final p = DepotParametres.instance;
      final moi = await ServiceAppareil.id();
      final expediteur = p.appareilExpediteurId.isNotEmpty &&
          p.appareilExpediteurId == moi;
      if (expediteur != estExpediteur) {
        estExpediteur = expediteur;
        notifyListeners();
      }
      if (!expediteur) {
        if (_ecranMis) {
          _ecranMis = false;
          await SmsNatif.ecranAllume(false);
        }
        return;
      }
      if (!_ecranMis) {
        _ecranMis = true;
        await SmsNatif.ecranAllume(true);
      }
      final ok = await SmsNatif.permissionOk();
      if (ok != permissionOk) {
        permissionOk = ok;
        notifyListeners();
      }
      if (!ok) {
        _noter("Permission d'envoi de SMS non accordée.");
        return;
      }
      if (!DepotOperations.instance.pret || !DepotClients.instance.pret) return;
      await _relanceAuto();
      await _viderFile();
    } finally {
      _occupe = false;
    }
  }

  Future<void> _relanceAuto() async {
    final p = DepotParametres.instance;
    if (!p.relanceAutoActive) return;
    final maintenant = DateTime.now();
    if (maintenant.hour < p.relanceAutoHeure) return;
    if (dansHeuresCalmes(maintenant, p.heuresCalmesDebut, p.heuresCalmesFin)) {
      return;
    }
    final derniere = _derniereRelanceAuto;
    if (derniere != null && maintenant.difference(derniere).inMinutes < 10) {
      return;
    }
    _derniereRelanceAuto = maintenant;
    await RelanceService.creer(
      DepotClients.instance.actifs,
      origine: 'relance_auto',
      parNom: 'Relance automatique',
      respecterIntervalle: true,
    );
  }

  Future<void> _viderFile() async {
    final depot = DepotOperations.instance;
    final clients = DepotClients.instance;
    final p = DepotParametres.instance;
    for (final op in depot.smsDansEtats(<String>{'en_attente'})) {
      if (!p.appareilExpediteurId.isNotEmpty) return;
      final client = clients.parCle(op.clientCle);
      if (!op.valide || client == null || !client.actif) {
        depot.majSms(op, etat: 'aucun');
        continue;
      }
      if (client.enConflit) continue; // suspendu tant que le rang est en conflit
      final decision = decider(
        op,
        maintenant: DateTime.now(),
        delaiMaxHeures: p.delaiMaxSmsHeures,
        calmeDebut: p.heuresCalmesDebut,
        calmeFin: p.heuresCalmesFin,
      );
      if (decision == DecisionSms.expirer) {
        depot.majSms(op, etat: 'expire', erreur: 'Trop ancien pour être envoyé');
        continue;
      }
      if (decision != DecisionSms.envoyer) continue;

      final numero = numeroPourSms(client.telephone1);
      if (numero.isEmpty) {
        depot.majSms(op, etat: 'echec', erreur: 'Pas de numéro de téléphone');
        continue;
      }
      final texte = composerSms(
        op,
        depot.deClient(op.clientCle),
        client,
        modeleBon: p.modeleSmsBon,
        modeleVersement: p.modeleSmsVersement,
      );
      // « en cours » d'abord : si l'application s'arrête en plein envoi,
      // le SMS n'est jamais envoyé deux fois (il apparaît dans la file).
      depot.majSms(op, etat: 'en_cours', texte: texte);
      final erreur = await SmsNatif.envoyer(numero, texte, p.simIndex);
      if (erreur == null) {
        depot.majSms(op, etat: 'envoye', texte: texte);
        _noter('');
      } else {
        depot.majSms(op, etat: 'echec', erreur: erreur, texte: texte);
        _noter('Dernier échec : $erreur');
      }
      await Future<void>.delayed(Duration(seconds: p.pauseSmsSecondes));
    }
  }
}

