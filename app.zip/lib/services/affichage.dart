import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../donnees/plateforme.dart';

/// Taille des écritures, réglable dans Paramètres (propre à chaque appareil).
/// Sur ordinateur, la valeur par défaut est plus grande.
class Affichage extends ChangeNotifier {
  Affichage._();
  static final Affichage instance = Affichage._();

  static const String _cle = 'echelle_texte';
  static const List<double> choix = <double>[1.0, 1.25, 1.5, 1.75];

  double echelle = estWindows ? 1.25 : 1.0;

  static String libelle(double e) {
    if (e <= 1.0) return 'Normal';
    if (e <= 1.25) return 'Grand';
    if (e <= 1.5) return 'Très grand';
    return 'Énorme';
  }

  Future<void> charger() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final v = prefs.getDouble(_cle);
      if (v != null && v >= 0.8 && v <= 2.2) echelle = v;
    } catch (_) {}
  }

  Future<void> definir(double valeur) async {
    echelle = valeur;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble(_cle, valeur);
    } catch (_) {}
  }
}
