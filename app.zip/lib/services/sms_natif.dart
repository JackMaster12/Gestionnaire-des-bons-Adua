import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Pont vers l'envoi de SMS d'Android (code Kotlin MainActivity).
class SmsNatif {
  static const MethodChannel _canal = MethodChannel('adua/sms');

  /// Seul Android peut envoyer des SMS.
  static bool get disponible =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  static Future<bool> permissionOk() async {
    if (!disponible) return false;
    try {
      return (await _canal.invokeMethod<bool>('permissions')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> demanderPermissions() async {
    if (!disponible) return false;
    try {
      return (await _canal.invokeMethod<bool>('demanderPermissions')) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Envoie un SMS avec la SIM demandée. Retourne null si le SMS est parti,
  /// sinon le message d'erreur.
  static Future<String?> envoyer(String numero, String texte, int sim) async {
    if (!disponible) return "Envoi de SMS impossible sur cet appareil.";
    try {
      final r = await _canal.invokeMethod<String>('envoyer', <String, dynamic>{
        'numero': numero,
        'texte': texte,
        'sim': sim,
      });
      if (r == 'ok') return null;
      if (r != null && r.startsWith('erreur:')) return r.substring(7);
      return 'Réponse inattendue : $r';
    } catch (e) {
      return 'Erreur : $e';
    }
  }

  static Future<void> ecranAllume(bool actif) async {
    if (!disponible) return;
    try {
      await _canal.invokeMethod<bool>('ecranAllume', <String, dynamic>{'actif': actif});
    } catch (_) {}
  }
}
