import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../constantes.dart';
import '../noyau/calculs.dart';
import '../noyau/client.dart';
import 'depot_operations.dart';
import 'journal_service.dart';
import 'outils.dart';

/// Opérations rares sur un compte client.
class GestionCompte {
  /// Supprime un compte : copie dans les archives (avec le motif),
  /// puis le compte devient inactif et son numéro est libéré.
  static void supprimer(Client c,
      {required String motif, required String parNom}) {
    final db = FirebaseFirestore.instance;
    final user = FirebaseAuth.instance.currentUser;
    final ops = DepotOperations.instance.deClient(c.cle).toList();
    final du = calculerSolde(ops);
    final archive = db.collection(colArchive).doc(c.cle);

    // Les écritures partent dans l'ordre : archive, opérations, puis compte inactif.
    lancer(() => archive.set(<String, dynamic>{
          'cle': c.cle,
          'rang': c.rang,
          'nom': c.nom,
          'telephone1': c.telephone1,
          'telephone2': c.telephone2,
          'autresInfos': c.autresInfos,
          'montantDuALaSuppression': du,
          'motif': motif,
          'supprimePar': user?.uid ?? '',
          'supprimeParNom': parNom,
          'supprimeLe': FieldValue.serverTimestamp(),
          'majLe': FieldValue.serverTimestamp(),
        }));

    var lot = db.batch();
    var n = 0;
    for (final o in ops) {
      final donnees = DepotOperations.donneesPour(o)
        ..['majLe'] = FieldValue.serverTimestamp();
      lot.set(archive.collection(colOperations).doc(o.cle), donnees);
      n++;
      if (n == 400) {
        final envoi = lot;
        lancer(() => envoi.commit());
        lot = db.batch();
        n = 0;
      }
    }
    if (n > 0) {
      final envoi = lot;
      lancer(() => envoi.commit());
    }

    final ref = db.collection(colClients).doc(c.cle);
    lancer(() => ref.update(<String, dynamic>{
          'actif': false,
          'motifSuppression': motif,
          'supprimeLe': FieldValue.serverTimestamp(),
          'supprimePar': user?.uid ?? '',
          'majLe': FieldValue.serverTimestamp(),
        }));
    Journal.ecrire('client_supprime',
        detail:
            'rang ${c.rang} - ${c.nom} - dû ${formaterMontant(du)}${motif.isEmpty ? '' : ' - $motif'}');
  }
}
