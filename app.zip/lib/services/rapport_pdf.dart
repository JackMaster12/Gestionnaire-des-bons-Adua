import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../noyau/calculs.dart';
import '../noyau/client.dart';
import '../noyau/operation.dart';
import '../noyau/sms.dart';

/// Génération des PDF (relevé d'un client, listes). Pur Dart : la même
/// fonction servira sur Windows.

/// Les polices PDF standard ne contiennent que les lettres latines usuelles :
/// on remplace les signes spéciaux pour éviter les carrés vides.
String _p(String s) {
  const remplacements = <String, String>{
    '—': '-',
    '–': '-',
    '•': '-',
    '’': "'",
    '‘': "'",
    '“': '"',
    '”': '"',
    'œ': 'oe',
    'Œ': 'OE',
    '…': '...',
    ' ': ' ',
    ' ': ' ',
    '→': '->',
  };
  final sb = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    final remplace = remplacements[c];
    if (remplace != null) {
      sb.write(remplace);
    } else if (r == 10 || (r >= 32 && r <= 255)) {
      sb.write(c);
    } else {
      sb.write('?');
    }
  }
  return sb.toString();
}

String _court(String s, int max) {
  final t = _p(s).replaceAll('\n', ' ').trim();
  return t.length <= max ? t : '${t.substring(0, max - 3)}...';
}

String _iso(DateTime d) {
  String deux(int n) => n < 10 ? '0$n' : '$n';
  return '${d.year}-${deux(d.month)}-${deux(d.day)}';
}

pw.Widget _entete(String titre, DateTime date) {
  return pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.start,
    children: [
      pw.Text('Depot pharmaceutique ADUA - Zinder',
          style: pw.TextStyle(fontSize: 11, color: PdfColors.grey700)),
      pw.SizedBox(height: 2),
      pw.Text(_p(titre),
          style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
      pw.Text('Edite le ${formaterDate(date)}',
          style: pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
      pw.SizedBox(height: 8),
      pw.Divider(),
    ],
  );
}

pw.Widget _pied(pw.Context ctx) {
  return pw.Align(
    alignment: pw.Alignment.centerRight,
    child: pw.Text('Page ${ctx.pageNumber} / ${ctx.pagesCount}',
        style: pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
  );
}

pw.Widget _cellule(String texte,
    {bool gras = false,
    bool droite = false,
    PdfColor? couleur,
    double taille = 9}) {
  return pw.Padding(
    padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 3),
    child: pw.Align(
      alignment: droite ? pw.Alignment.centerRight : pw.Alignment.centerLeft,
      child: pw.Text(
        _p(texte),
        style: pw.TextStyle(
          fontSize: taille,
          fontWeight: gras ? pw.FontWeight.bold : pw.FontWeight.normal,
          color: couleur,
        ),
      ),
    ),
  );
}

pw.TableRow _ligneEntete(List<String> titres, {Set<int> droite = const {}}) {
  return pw.TableRow(
    decoration: const pw.BoxDecoration(color: PdfColors.grey300),
    children: [
      for (var i = 0; i < titres.length; i++)
        _cellule(titres[i], gras: true, droite: droite.contains(i)),
    ],
  );
}

/// Relevé d'un client : [complet] = tout l'historique (annulations comprises),
/// sinon situation + 10 derniers bons et versements.
Future<Uint8List> releveClient({
  required Client client,
  required List<Operation> operations,
  required Situation situation,
  required bool complet,
  required DateTime date,
}) async {
  // Reste à payer après chaque bon ou versement valide (ordre réel du compte).
  final soldes = <String, int>{};
  var courant = 0;
  for (final o in operations) {
    if (!o.valide) continue;
    if (o.type == TypeOperation.bon) {
      courant += o.montant;
      soldes[o.cle] = courant;
    } else if (o.type == TypeOperation.versement) {
      courant -= o.montant;
      soldes[o.cle] = courant;
    }
  }

  List<Operation> lignes;
  if (complet) {
    lignes = operations.toList();
  } else {
    final fin = operations
        .where((o) =>
            o.valide &&
            (o.type == TypeOperation.bon || o.type == TypeOperation.versement))
        .toList();
    lignes = fin.length > 10 ? fin.sublist(fin.length - 10) : fin;
  }

  final rouge = situation.horsTolerance;
  final qr = 'ADUA|BONS|rang=${client.rang}|du=${situation.du}|le=${_iso(date)}';

  final doc = pw.Document();
  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      header: (_) => _entete(
          complet ? 'Releve de compte - historique complet' : 'Releve de compte - resume',
          date),
      footer: _pied,
      build: (ctx) => [
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(_p(client.nom),
                      style: pw.TextStyle(
                          fontSize: 18, fontWeight: pw.FontWeight.bold)),
                  pw.SizedBox(height: 4),
                  pw.Text('Rang (numero d\'ordre) : ${client.rang}'),
                  if (client.telephone1.isNotEmpty)
                    pw.Text('Telephone : ${_p(client.telephone1)}'),
                  if (client.telephone2.isNotEmpty)
                    pw.Text('Telephone 2 : ${_p(client.telephone2)}'),
                  if (client.autresInfos.isNotEmpty)
                    pw.Text(_court(client.autresInfos, 100)),
                ],
              ),
            ),
            pw.BarcodeWidget(
              barcode: pw.Barcode.qrCode(),
              data: qr,
              width: 80,
              height: 80,
            ),
          ],
        ),
        pw.SizedBox(height: 14),
        pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            border: pw.Border.all(
                color: rouge ? PdfColors.red800 : PdfColors.grey600,
                width: rouge ? 2 : 1),
            borderRadius: pw.BorderRadius.circular(6),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Montant du',
                  style: pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
              pw.Text(formaterMontant(situation.du),
                  style: pw.TextStyle(
                      fontSize: 24,
                      fontWeight: pw.FontWeight.bold,
                      color: rouge ? PdfColors.red800 : PdfColors.black)),
              pw.SizedBox(height: 4),
              pw.Text(
                  'Retard : ${situation.retardJours == null ? '-' : libelleRetard(situation.retardJours!)}'
                  '${rouge ? '  (hors periode de tolerance)' : ''}'),
              pw.Text(
                  'Dernier bon : ${_d(situation.dernierBon)}    Dernier versement : ${_d(situation.dernierVersement)}'),
              if (client.bloque)
                pw.Text('Compte bloque : aucun nouveau bon.',
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold, color: PdfColors.red800)),
            ],
          ),
        ),
        pw.SizedBox(height: 16),
        pw.Text(complet ? 'Historique' : 'Dix dernieres operations',
            style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        if (lignes.isEmpty)
          pw.Text('Aucune operation.')
        else
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.5),
            columnWidths: const <int, pw.TableColumnWidth>{
              0: pw.FixedColumnWidth(58),
              1: pw.FixedColumnWidth(62),
              2: pw.FixedColumnWidth(62),
              3: pw.FixedColumnWidth(66),
              4: pw.FlexColumnWidth(),
            },
            children: [
              _ligneEntete(
                  const ['Date', 'Operation', 'Montant', 'Reste a payer', 'Note'],
                  droite: const {2, 3}),
              for (final o in lignes)
                pw.TableRow(
                  children: [
                    _cellule(formaterDate(o.dateOperation)),
                    _cellule(libelleType(o.type)),
                    _cellule(o.montant > 0 ? formaterMontant(o.montant) : '',
                        droite: true),
                    _cellule(
                        soldes[o.cle] == null ? '' : formaterMontant(soldes[o.cle]!),
                        droite: true),
                    _cellule(
                      o.valide
                          ? _court(o.note, 90)
                          : 'ANNULEE : ${_court(o.annuleMotif, 70)}',
                      couleur: o.valide ? null : PdfColors.red800,
                    ),
                  ],
                ),
            ],
          ),
      ],
    ),
  );
  return doc.save();
}

String _d(DateTime? d) => d == null ? '-' : formaterDate(d);

/// Liste de comptes (dashboard, tous les clients) avec le total dû.
Future<Uint8List> listeClients({
  required String titre,
  required String sousTitre,
  required List<LigneSuivi> lignes,
  required DateTime date,
}) async {
  var total = 0;
  for (final l in lignes) {
    if (l.situation.du > 0) total += l.situation.du;
  }
  final doc = pw.Document();
  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      header: (_) => _entete(titre, date),
      footer: _pied,
      build: (ctx) => [
        pw.Text(_p(sousTitre), style: const pw.TextStyle(fontSize: 10)),
        pw.SizedBox(height: 4),
        pw.Text(
            '${lignes.length} compte${lignes.length > 1 ? 's' : ''}  -  Total du : ${formaterMontant(total)}',
            style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 8),
        if (lignes.isEmpty)
          pw.Text('Aucun compte.')
        else
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey500, width: 0.5),
            columnWidths: const <int, pw.TableColumnWidth>{
              0: pw.FixedColumnWidth(32),
              1: pw.FlexColumnWidth(),
              2: pw.FixedColumnWidth(72),
              3: pw.FixedColumnWidth(68),
              4: pw.FixedColumnWidth(52),
              5: pw.FixedColumnWidth(70),
            },
            children: [
              _ligneEntete(
                  const ['Rang', 'Nom', 'Telephone', 'Montant du', 'Retard', 'Statut'],
                  droite: const {3}),
              for (final l in lignes)
                pw.TableRow(
                  children: [
                    _cellule('${l.client.rang}'),
                    _cellule(_court(l.client.nom, 40), gras: true),
                    _cellule(l.client.telephone1),
                    _cellule(formaterMontant(l.situation.du),
                        droite: true,
                        couleur:
                            l.situation.horsTolerance ? PdfColors.red800 : null),
                    _cellule(l.situation.retardJours == null
                        ? '-'
                        : '${l.situation.retardJours} j'),
                    _cellule([
                      if (l.client.bloque) 'Bloque',
                      if (l.situation.horsTolerance) 'Hors tol.',
                      if (l.situation.montantEleve) 'Eleve',
                    ].join(', ')),
                  ],
                ),
            ],
          ),
      ],
    ),
  );
  return doc.save();
}


/// Petit reçu long (ticket) pour un bon ou un versement.
/// [largeurMm] : 80 (rouleau standard) ou 57 (petit rouleau).
Future<Uint8List> recuOperation({
  required Client client,
  required Operation op,
  required Iterable<Operation> operationsClient,
  required int largeurMm,
  required DateTime edite,
}) async {
  final s = soldesOperation(op, operationsClient);
  final etroit = largeurMm < 70;
  final t = etroit ? 8.0 : 10.0;
  final format = PdfPageFormat(
    largeurMm * PdfPageFormat.mm,
    double.infinity,
    marginAll: 3 * PdfPageFormat.mm,
  );
  final estBon = op.type == TypeOperation.bon;

  pw.Widget centre(String texte, {double? taille, bool gras = false}) => pw.Center(
        child: pw.Text(_p(texte),
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
                fontSize: taille ?? t,
                fontWeight: gras ? pw.FontWeight.bold : pw.FontWeight.normal)),
      );
  pw.Widget ligne(String gauche, String droite, {bool gras = false, double? taille}) =>
      pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 1.5),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(_p(gauche),
                style: pw.TextStyle(
                    fontSize: taille ?? t,
                    fontWeight: gras ? pw.FontWeight.bold : pw.FontWeight.normal)),
            pw.SizedBox(width: 4),
            pw.Flexible(
              child: pw.Text(_p(droite),
                  textAlign: pw.TextAlign.right,
                  style: pw.TextStyle(
                      fontSize: taille ?? t,
                      fontWeight: gras ? pw.FontWeight.bold : pw.FontWeight.normal)),
            ),
          ],
        ),
      );
  pw.Widget trait() => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 4),
        child: pw.Divider(thickness: 0.8, height: 1),
      );

  final doc = pw.Document();
  doc.addPage(
    pw.Page(
      pageFormat: format,
      build: (ctx) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          centre('DEPOT PHARMACEUTIQUE ADUA', taille: t + 2, gras: true),
          centre('Zinder - Niger'),
          trait(),
          centre(estBon ? 'RECU DE BON' : 'RECU DE VERSEMENT',
              taille: t + 3, gras: true),
          trait(),
          ligne('Client', client.nom, gras: true),
          ligne('Rang', '${client.rang}'),
          ligne('Date', formaterDate(op.dateOperation)),
          ligne('Heure', formaterDateHeure(op.saisieLe)),
          trait(),
          ligne(estBon ? 'Montant du bon' : 'Montant verse',
              formaterMontant(op.montant),
              gras: true, taille: t + 3),
          trait(),
          ligne('Reste avant', formaterMontant(s.avant)),
          ligne('RESTE A PAYER', formaterMontant(s.apres), gras: true, taille: t + 1),
          if (op.note.trim().isNotEmpty) ...[
            trait(),
            pw.Text(_p('Note : ${op.note.trim()}'), style: pw.TextStyle(fontSize: t - 1)),
          ],
          trait(),
          if (op.parNom.isNotEmpty)
            pw.Text(_p('Servi par : ${op.parNom}'), style: pw.TextStyle(fontSize: t - 1)),
          pw.SizedBox(height: 14),
          pw.Text('Signature :', style: pw.TextStyle(fontSize: t - 1)),
          pw.SizedBox(height: 22),
          trait(),
          centre('Merci de votre confiance', gras: true),
          centre('Edite le ${formaterDateHeure(edite)}', taille: t - 2),
          pw.SizedBox(height: 10),
        ],
      ),
    ),
  );
  return doc.save();
}
