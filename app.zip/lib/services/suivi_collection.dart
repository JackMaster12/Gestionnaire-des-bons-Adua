import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

/// Suivi d'une grande collection en lisant le moins possible :
/// 1) on relit d'abord le cache local (gratuit) ;
/// 2) on n'écoute ensuite que les documents modifiés depuis (majLe).
/// Les lectures facturées par Firebase restent ainsi très faibles.
class SuiviCollection<T> {
  final String collection;
  final T Function(String id, Map<String, dynamic> donnees) construire;
  final void Function() surChangement;

  SuiviCollection({
    required this.collection,
    required this.construire,
    required this.surChangement,
  });

  final Map<String, T> elements = <String, T>{};
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _abonnement;
  bool _actif = false;
  bool pret = false;

  CollectionReference<Map<String, dynamic>> get _col =>
      FirebaseFirestore.instance.collection(collection);

  Future<void> demarrer() async {
    if (_actif) return;
    _actif = true;
    Timestamp? curseur;
    try {
      final cache = await _col.get(const GetOptions(source: Source.cache));
      for (final doc in cache.docs) {
        final d = doc.data();
        elements[doc.id] = construire(doc.id, d);
        final m = d['majLe'];
        if (m is Timestamp && (curseur == null || m.compareTo(curseur) > 0)) {
          curseur = m;
        }
      }
    } catch (_) {}
    if (!_actif) return;
    if (elements.isNotEmpty) {
      pret = true;
      surChangement();
    }
    final Query<Map<String, dynamic>> requete = curseur == null
        ? _col
        : _col.where('majLe', isGreaterThanOrEqualTo: curseur);
    _abonnement = requete.snapshots().listen((snap) {
      for (final ch in snap.docChanges) {
        if (ch.type == DocumentChangeType.removed) continue;
        final data = ch.doc.data();
        if (data == null) continue;
        elements[ch.doc.id] = construire(ch.doc.id, data);
      }
      pret = true;
      surChangement();
    }, onError: (Object _) {});
  }

  /// Ajoute ou remplace un élément tout de suite, sans attendre Firestore.
  void injecter(String id, T valeur) {
    elements[id] = valeur;
  }

  void arreter() {
    _actif = false;
    _abonnement?.cancel();
    _abonnement = null;
    elements.clear();
    pret = false;
  }
}
