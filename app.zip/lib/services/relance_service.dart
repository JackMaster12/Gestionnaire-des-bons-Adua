import '../noyau/calculs.dart';
import '../noyau/client.dart';
import '../noyau/operation.dart';
import '../noyau/sms.dart';
import 'depot_operations.dart';
import 'depot_parametres.dart';

/// Création des messages de relance (automatique ou par le bouton général).
/// Chaque relance reçoit une clé fixe « relance_<client>_<jour> » : même si
/// deux appareils agissent, un client n'est relancé qu'une fois par jour.
class RelanceService {
  /// Crée une relance pour chacun des [clients] ; retourne le nombre créé.
  static Future<int> creer(
    Iterable<Client> clients, {
    required String origine,
    required String parNom,
    bool respecterIntervalle = false,
  }) async {
    final depot = DepotOperations.instance;
    final p = DepotParametres.instance;
    final maintenant = DateTime.now();
    var n = 0;
    for (final c in clients) {
      if (!c.actif || c.enConflit || c.telephone1.trim().isEmpty) continue;
      final s = depot.situationDe(c.cle);
      if (!s.horsTolerance) continue;
      if (respecterIntervalle &&
          !relanceDue(s, maintenant, p.relanceAutoIntervalleJours)) {
        continue;
      }
      final cle = cleRelance(c.cle, maintenant);
      if (depot.existe(cle)) continue;
      await depot.ajouter(
        client: c,
        type: TypeOperation.message,
        montant: 0,
        note: texteRelance(p.modeleRelance, c, s),
        date: maintenant,
        parNom: parNom,
        cleImposee: cle,
        origine: origine,
      );
      n++;
    }
    return n;
  }
}
