import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../constantes.dart';
import '../noyau/client.dart';
import '../noyau/rangs.dart';
import '../noyau/texte.dart';
import 'appareil_service.dart';
import 'journal_service.dart';
import 'outils.dart';

/// Tous les comptes clients, gardés en mémoire et mis à jour en direct.
/// C'est la « porte » entre l'application et Firestore : la version Windows
/// aura son propre dépôt (SQLite), avec les mêmes fonctions.
class DepotClients extends ChangeNotifier {
  DepotClients._();
  static final DepotClients instance = DepotClients._();

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _abonnement;
  List<Client> _tous = <Client>[];
  bool _pret = false;
  final Set<String> _envoyes = <String>{};

  bool get pret => _pret;

  List<Client> get actifs => _tous.where((c) => c.actif).toList();

  int get nombreActifs => _tous.where((c) => c.actif).length;

  int get nombreBloques => _tous.where((c) => c.actif && c.bloque).length;

  List<Client> get enConflit {
    final liste = _tous.where((c) => c.actif && c.enConflit).toList();
    liste.sort((a, b) => a.rang.compareTo(b.rang));
    return liste;
  }

  CollectionReference<Map<String, dynamic>> get _col =>
      FirebaseFirestore.instance.collection(colClients);

  void demarrer() {
    if (_abonnement != null) return;
    _abonnement = _col.snapshots().listen((snap) {
      _tous = snap.docs.map(_depuisDoc).toList();
      _pret = true;
      _verifierConflits();
      notifyListeners();
    }, onError: (Object _) {});
  }

  /// Appelé quand l'écran d'accueil disparaît (déconnexion).
  void arreter() {
    _abonnement?.cancel();
    _abonnement = null;
    _tous = <Client>[];
    _pret = false;
    _envoyes.clear();
  }

  Client _depuisDoc(QueryDocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data();
    DateTime date(Object? v) {
      if (v is Timestamp) return v.toDate();
      return DateTime.fromMillisecondsSinceEpoch(0);
    }

    return Client(
      cle: doc.id,
      rang: (d['rang'] as num?)?.toInt() ?? 0,
      rangSpecial: (d['rangSpecial'] ?? false) as bool,
      nom: (d['nom'] ?? '') as String,
      telephone1: (d['telephone1'] ?? '') as String,
      telephone2: (d['telephone2'] ?? '') as String,
      autresInfos: (d['autresInfos'] ?? '') as String,
      bloque: (d['bloque'] ?? false) as bool,
      enConflit: (d['enConflit'] ?? false) as bool,
      actif: (d['actif'] ?? true) as bool,
      creeLe: date(d['creeLe']),
      decalageHorlogeMs: (d['decalageHorlogeMs'] as num?)?.toInt() ?? 0,
    );
  }

  // ---------- Recherche ----------

  Client? parCle(String cle) {
    for (final c in _tous) {
      if (c.cle == cle) return c;
    }
    return null;
  }

  /// Clients actifs portant ce rang (le plus ancien d'abord : c'est lui
  /// qui garde le numéro en cas de conflit).
  List<Client> parRang(int rang) {
    final liste = _tous.where((c) => c.actif && c.rang == rang).toList();
    liste.sort(comparerAnciennete);
    return liste;
  }

  List<Client> rechercherNom(String saisie) {
    final q = normaliser(saisie);
    if (q.isEmpty) return <Client>[];
    final liste =
        _tous.where((c) => c.actif && c.nomRecherche.contains(q)).toList();
    liste.sort((a, b) {
      final n = a.nomRecherche.compareTo(b.nomRecherche);
      return n != 0 ? n : a.rang.compareTo(b.rang);
    });
    return liste;
  }

  List<Client> rechercherTelephone(String saisie) {
    final q = chiffres(saisie);
    if (q.length < 3) return <Client>[];
    bool correspond(String tel) {
      final t = chiffres(tel);
      if (t.isEmpty) return false;
      return t.contains(q) || (t.length >= 6 && q.contains(t));
    }

    final liste = _tous
        .where((c) =>
            c.actif && (correspond(c.telephone1) || correspond(c.telephone2)))
        .toList();
    liste.sort((a, b) => a.rang.compareTo(b.rang));
    return liste;
  }

  // ---------- Écriture (hors ligne : les écritures partent à la reconnexion) ----------

  Future<Client> creer({
    required String nom,
    required String telephone1,
    required String telephone2,
    required String autresInfos,
    required int rang,
    required bool special,
  }) async {
    final cle = const Uuid().v4();
    final user = FirebaseAuth.instance.currentUser;
    final appareil = await ServiceAppareil.id();
    final maintenant = DateTime.now();
    final nomNet = nom.trim();
    final donnees = <String, dynamic>{
      'cle': cle,
      'rang': rang,
      'rangSpecial': special,
      'nom': nomNet,
      'nomRecherche': normaliser(nomNet),
      'telephone1': telephone1.trim(),
      'telephone2': telephone2.trim(),
      'autresInfos': autresInfos.trim(),
      'bloque': false,
      'enConflit': false,
      'actif': true,
      'creeLe': Timestamp.fromDate(maintenant),
      'decalageHorlogeMs': 0,
      'creePar': user?.uid ?? '',
      'appareilId': appareil,
      'majLe': FieldValue.serverTimestamp(),
    };
    final ref = _col.doc(cle);
    lancer(() => ref.set(donnees));
    Journal.ecrire('client_cree', detail: 'rang $rang - $nomNet');
    return Client(
      cle: cle,
      rang: rang,
      rangSpecial: special,
      nom: nomNet,
      telephone1: telephone1.trim(),
      telephone2: telephone2.trim(),
      autresInfos: autresInfos.trim(),
      creeLe: maintenant,
    );
  }

  void modifier(
    Client c, {
    required String nom,
    required String telephone1,
    required String telephone2,
    required String autresInfos,
  }) {
    final nomNet = nom.trim();
    final ref = _col.doc(c.cle);
    lancer(() => ref.update(<String, dynamic>{
          'nom': nomNet,
          'nomRecherche': normaliser(nomNet),
          'telephone1': telephone1.trim(),
          'telephone2': telephone2.trim(),
          'autresInfos': autresInfos.trim(),
          'majLe': FieldValue.serverTimestamp(),
        }));
    Journal.ecrire('client_modifie', detail: 'rang ${c.rang} - $nomNet');
  }

  void definirBlocage(Client c, bool bloque) {
    final user = FirebaseAuth.instance.currentUser;
    final ref = _col.doc(c.cle);
    lancer(() => ref.update(<String, dynamic>{
          'bloque': bloque,
          'bloqueLe': bloque ? FieldValue.serverTimestamp() : null,
          'bloquePar': bloque ? (user?.uid ?? '') : '',
          'majLe': FieldValue.serverTimestamp(),
        }));
    Journal.ecrire(bloque ? 'client_bloque' : 'client_debloque',
        detail: 'rang ${c.rang} - ${c.nom}');
  }

  /// Réservé à l'administrateur : donne un nouveau rang à un client en conflit.
  void changerRang(Client c, int nouveauRang) {
    final ref = _col.doc(c.cle);
    lancer(() => ref.update(<String, dynamic>{
          'rang': nouveauRang,
          'rangSpecial': true,
          'enConflit': false,
          'majLe': FieldValue.serverTimestamp(),
        }));
    Journal.ecrire('rang_change',
        detail: '${c.nom} : ${c.rang} vers $nouveauRang');
  }

  // ---------- Conflits de rang ----------

  /// Marque ou démarque les clients en conflit. Le résultat est le même sur
  /// tous les appareils, donc des écritures simultanées ne se contredisent pas.
  void _verifierConflits() {
    final etats = etatsConflit(_tous);
    for (final c in _tous) {
      if (!c.actif) continue;
      final voulu = etats[c.cle];
      if (voulu == null) continue;
      if (voulu == c.enConflit) {
        _envoyes.remove('${c.cle}:true');
        _envoyes.remove('${c.cle}:false');
        continue;
      }
      final marque = '${c.cle}:$voulu';
      if (_envoyes.contains(marque)) continue;
      _envoyes.add(marque);
      final ref = _col.doc(c.cle);
      lancer(() => ref.update(<String, dynamic>{
            'enConflit': voulu,
            'majLe': FieldValue.serverTimestamp(),
          }));
    }
  }
}
