import 'package:flutter/material.dart';

/// Charte graphique : thème pharmacie, vert et bleu, clair et lisible.
class CouleursAdua {
  static const Color vert = Color(0xFF0B7A5E);
  static const Color vertFonce = Color(0xFF075E49);
  static const Color bleu = Color(0xFF1565A8);
  static const Color fond = Color(0xFFF1F6F5);
  static const Color texte = Color(0xFF14302B);
  static const Color rouge = Color(0xFFC62828);
  static const Color ambre = Color(0xFFD98200);
  static const Color gris = Color(0xFF6B7F7A);

  /// Teinte très claire d'une couleur (fond des pastilles et des cartes).
  static Color teinte(Color c, [double force = 0.12]) =>
      Color.lerp(Colors.white, c, force)!;
}

ThemeData themeAdua() {
  final base = ColorScheme.fromSeed(
    seedColor: CouleursAdua.vert,
    brightness: Brightness.light,
  ).copyWith(
    primary: CouleursAdua.vert,
    secondary: CouleursAdua.bleu,
    error: CouleursAdua.rouge,
  );
  final bordure = OutlineInputBorder(
    borderRadius: BorderRadius.circular(12),
    borderSide: BorderSide(color: Colors.grey.shade400),
  );
  final forme = RoundedRectangleBorder(borderRadius: BorderRadius.circular(12));
  return ThemeData(
    useMaterial3: true,
    colorScheme: base,
    scaffoldBackgroundColor: CouleursAdua.fond,
    visualDensity: VisualDensity.standard,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: bordure,
      enabledBorder: bordure,
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: CouleursAdua.vert, width: 2),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        shape: forme,
        minimumSize: const Size(64, 48),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        shape: forme,
        minimumSize: const Size(64, 48),
      ),
    ),
  );
}
