import 'package:flutter/material.dart';

import '../theme.dart';

/// Logo ADUA : carré arrondi vert et bleu avec une croix de pharmacie.
class LogoAdua extends StatelessWidget {
  final double taille;
  const LogoAdua({super.key, this.taille = 48});

  @override
  Widget build(BuildContext context) {
    final barre = taille * 0.56;
    final epaisseur = taille * 0.17;
    BoxDecoration blanc() => BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(epaisseur / 2),
        );
    return Container(
      width: taille,
      height: taille,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [CouleursAdua.vert, CouleursAdua.bleu],
        ),
        borderRadius: BorderRadius.circular(taille * 0.22),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(width: barre, height: epaisseur, decoration: blanc()),
          Container(width: epaisseur, height: barre, decoration: blanc()),
        ],
      ),
    );
  }
}
