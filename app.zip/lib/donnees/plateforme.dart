// Différences entre Android et Windows.
// Sur Windows ce fichier est remplacé par windows_src/plateforme.dart.
import 'package:flutter/widgets.dart';

const bool estWindows = false;
const String nomPlateforme = 'android';

/// Bouton de synchronisation (utile seulement sur l'ordinateur).
Widget boutonSync(BuildContext context) => const SizedBox.shrink();
