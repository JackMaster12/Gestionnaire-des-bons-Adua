// Différences entre Android et Windows.
// Sur Windows ce fichier est remplacé par windows_src/plateforme.dart.
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

const bool estWindows = false;
const String nomPlateforme = 'android';

/// Bouton de synchronisation (utile seulement sur l'ordinateur).
Widget boutonSync(BuildContext context, {Color? couleur}) => const SizedBox.shrink();

/// Joue le petit son de lancement (sans erreur si indisponible).
Future<void> jouerSonDemarrage() async {
  try {
    await const MethodChannel('adua/sms').invokeMethod<bool>('sonDemarrage');
  } catch (_) {}
}
