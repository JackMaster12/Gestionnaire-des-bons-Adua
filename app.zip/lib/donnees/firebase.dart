// Point d'entrée unique vers Firebase.
// Sur Android : les vrais paquets Firebase.
// Sur Windows : ce fichier est remplacé à la compilation par windows_src/firebase.dart
// (base SQLite locale + synchronisation REST), voir tools/patch_windows.py.
export 'package:cloud_firestore/cloud_firestore.dart';
export 'package:firebase_auth/firebase_auth.dart';
export 'package:firebase_core/firebase_core.dart';
