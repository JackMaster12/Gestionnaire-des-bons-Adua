import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/client.dart';
import '../services/depot_clients.dart';
import 'client_fiche.dart';

enum ModeRecherche { rang, nom, telephone }

/// Formulaire de recherche : police très grande pour lire d'un coup d'œil.
class EcranRecherche extends StatefulWidget {
  final ProfilUtilisateur profil;
  final ModeRecherche mode;
  const EcranRecherche({super.key, required this.profil, required this.mode});

  @override
  State<EcranRecherche> createState() => _EtatRecherche();
}

class _EtatRecherche extends State<EcranRecherche> {
  final _champ = TextEditingController();
  String _saisie = '';

  @override
  void dispose() {
    _champ.dispose();
    super.dispose();
  }

  String get _titre {
    switch (widget.mode) {
      case ModeRecherche.rang:
        return 'Recherche par rang';
      case ModeRecherche.nom:
        return 'Recherche par nom';
      case ModeRecherche.telephone:
        return 'Recherche par téléphone';
    }
  }

  String get _indication {
    switch (widget.mode) {
      case ModeRecherche.rang:
        return 'Saisir le rang';
      case ModeRecherche.nom:
        return 'Saisir le nom';
      case ModeRecherche.telephone:
        return 'Saisir le numéro';
    }
  }

  TextInputType get _clavier {
    switch (widget.mode) {
      case ModeRecherche.rang:
        return TextInputType.number;
      case ModeRecherche.nom:
        return TextInputType.name;
      case ModeRecherche.telephone:
        return TextInputType.phone;
    }
  }

  List<Client> _resultats(DepotClients depot) {
    switch (widget.mode) {
      case ModeRecherche.rang:
        final r = int.tryParse(_saisie.trim());
        if (r == null) return <Client>[];
        return depot.parRang(r);
      case ModeRecherche.nom:
        return depot.rechercherNom(_saisie);
      case ModeRecherche.telephone:
        return depot.rechercherTelephone(_saisie);
    }
  }

  void _ouvrir(Client c) {
    Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => EcranClient(profil: widget.profil, cle: c.cle)));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(_titre)),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: DepotClients.instance,
          builder: (context, _) {
            final depot = DepotClients.instance;
            final resultats = _resultats(depot);
            final saisieVide = _saisie.trim().isEmpty;
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: TextField(
                    controller: _champ,
                    autofocus: true,
                    keyboardType: _clavier,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 40, fontWeight: FontWeight.bold),
                    decoration: InputDecoration(
                      hintText: _indication,
                      hintStyle: const TextStyle(
                          fontSize: 28, fontWeight: FontWeight.normal),
                      contentPadding: const EdgeInsets.symmetric(vertical: 20),
                    ),
                    onChanged: (v) => setState(() => _saisie = v),
                    onSubmitted: (_) {
                      if (resultats.length == 1) _ouvrir(resultats.first);
                    },
                  ),
                ),
                if (!depot.pret)
                  const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('Chargement des comptes…'),
                  ),
                Expanded(
                  child: saisieVide
                      ? const SizedBox.shrink()
                      : resultats.isEmpty
                          ? Center(
                              child: Text('Aucun client trouvé.',
                                  style: theme.textTheme.titleLarge),
                            )
                          : ListView.separated(
                              itemCount: resultats.length,
                              separatorBuilder: (_, __) =>
                                  const Divider(height: 1),
                              itemBuilder: (context, i) {
                                final c = resultats[i];
                                return ListTile(
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 20, vertical: 8),
                                  title: Text(c.nom,
                                      style: const TextStyle(
                                          fontSize: 26,
                                          fontWeight: FontWeight.bold)),
                                  subtitle: Text(
                                      'Rang ${c.rang}'
                                      '${c.telephone1.isEmpty ? '' : '  •  ${c.telephone1}'}'
                                      '${c.bloque ? '  •  BLOQUÉ' : ''}'
                                      '${c.enConflit ? '  •  CONFLIT' : ''}',
                                      style: const TextStyle(fontSize: 18)),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () => _ouvrir(c),
                                );
                              },
                            ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
