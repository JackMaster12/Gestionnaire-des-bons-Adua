import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/client.dart';
import '../noyau/operation.dart';
import '../services/depot_operations.dart';
import '../services/depot_parametres.dart';
import 'dialogues.dart';

/// Envoi manuel d'un message au client (modèle de relance modifiable).
/// Le message est enregistré dans l'historique et mis en file d'attente :
/// le téléphone expéditeur l'enverra (étape 6).
class EcranMessageClient extends StatefulWidget {
  final ProfilUtilisateur profil;
  final Client client;
  const EcranMessageClient(
      {super.key, required this.profil, required this.client});

  @override
  State<EcranMessageClient> createState() => _EtatMessage();
}

class _EtatMessage extends State<EcranMessageClient> {
  final _texte = TextEditingController();
  bool _enCours = false;

  @override
  void initState() {
    super.initState();
    final s = DepotOperations.instance.situationDe(widget.client.cle);
    _texte.text = remplirModele(DepotParametres.instance.modeleRelance, {
      'nom': widget.client.nom,
      'rang': '${widget.client.rang}',
      'total': formaterMontant(s.du),
      'retard': s.retardJours == null ? '' : libelleRetard(s.retardJours!),
    });
  }

  @override
  void dispose() {
    _texte.dispose();
    super.dispose();
  }

  Future<void> _enregistrer() async {
    final t = _texte.text.trim();
    if (t.isEmpty) {
      afficherInfo(context, 'Écrivez le message.');
      return;
    }
    final ok = await confirmer(context,
        titre: 'Envoyer ce message ?',
        message:
            'Il sera envoyé à ${widget.client.telephone1} par le téléphone expéditeur dès que possible.',
        bouton: 'Envoyer');
    if (!ok || !mounted) return;
    setState(() => _enCours = true);
    await DepotOperations.instance.ajouter(
      client: widget.client,
      type: TypeOperation.message,
      montant: 0,
      note: t,
      date: DateTime.now(),
      parNom: widget.profil.nom,
    );
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final sansTel = widget.client.telephone1.trim().isEmpty;
    return Scaffold(
      appBar: AppBar(title: const Text('Envoyer un message')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('${widget.client.nom}  (rang ${widget.client.rang})',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(sansTel
                ? "Ce client n'a pas de numéro de téléphone."
                : 'Destinataire : ${widget.client.telephone1}'),
            const SizedBox(height: 16),
            TextField(
              controller: _texte,
              maxLines: 8,
              decoration: const InputDecoration(labelText: 'Message'),
            ),
            const SizedBox(height: 8),
            const Text(
                'Le texte vient du modèle de relance (Paramètres). Vous pouvez le modifier avant l\'envoi.'),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: (_enCours || sansTel) ? null : _enregistrer,
              icon: const Icon(Icons.sms),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Envoyer le message'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
