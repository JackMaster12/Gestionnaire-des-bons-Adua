import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/client.dart';
import '../services/depot_clients.dart';
import 'client_formulaire.dart';

/// Compte d'un client : informations et opérations.
class EcranClient extends StatelessWidget {
  final ProfilUtilisateur profil;
  final String cle;
  const EcranClient({super.key, required this.profil, required this.cle});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: DepotClients.instance,
      builder: (context, _) {
        final c = DepotClients.instance.parCle(cle);
        if (c == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Compte client')),
            body: const Center(child: CircularProgressIndicator()),
          );
        }
        if (!c.actif) {
          return Scaffold(
            appBar: AppBar(title: const Text('Compte client')),
            body: const Center(child: Text('Ce compte a été supprimé.')),
          );
        }
        return _Fiche(profil: profil, client: c);
      },
    );
  }
}

class _Fiche extends StatelessWidget {
  final ProfilUtilisateur profil;
  final Client client;
  const _Fiche({required this.profil, required this.client});

  void _bientot(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Disponible à l'étape 3B (bons et historique).")),
    );
  }

  Future<void> _basculerBlocage(BuildContext context) async {
    final bloquer = !client.bloque;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(bloquer ? 'Bloquer ce client ?' : 'Débloquer ce client ?'),
        content: Text(bloquer
            ? '${client.nom} ne pourra plus recevoir de nouveau bon. Les versements restent possibles.'
            : '${client.nom} pourra de nouveau recevoir des bons.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(bloquer ? 'Bloquer' : 'Débloquer'),
          ),
        ],
      ),
    );
    if (ok == true) DepotClients.instance.definirBlocage(client, bloquer);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final c = client;
    return Scaffold(
      appBar: AppBar(title: Text('Rang ${c.rang}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (c.enConflit)
            Card(
              color: theme.colorScheme.errorContainer,
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  "⚠️ Ce numéro d'ordre est déjà utilisé par un compte plus ancien. "
                  "L'administrateur doit changer le numéro de ce compte. "
                  "Aucun SMS n'est envoyé en attendant.",
                ),
              ),
            ),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: c.bloque
                  ? BorderSide(color: theme.colorScheme.error, width: 3)
                  : BorderSide.none,
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(c.nom,
                      style: theme.textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold)),
                  if (c.bloque || c.enConflit) ...[
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        if (c.bloque)
                          Chip(
                            label: const Text('BLOQUÉ'),
                            backgroundColor: theme.colorScheme.errorContainer,
                          ),
                        if (c.enConflit)
                          const Chip(label: Text('CONFLIT DE RANG')),
                      ],
                    ),
                  ],
                  const SizedBox(height: 12),
                  _Ligne('Rang', '${c.rang}'),
                  _Ligne('Tél', c.telephone1.isEmpty ? '—' : c.telephone1),
                  if (c.telephone2.isNotEmpty) _Ligne('Tél 2', c.telephone2),
                  if (c.autresInfos.isNotEmpty)
                    _Ligne('Autres infos', c.autresInfos),
                  const Divider(height: 24),
                  const _Ligne('Montant dû', '— (étape 3B)'),
                  const _Ligne('Retard', '— (étape 3B)'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.tonalIcon(
            onPressed: () => _bientot(context),
            icon: const Icon(Icons.add_shopping_cart),
            label: const Text('Nouveau bon'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _bientot(context),
            icon: const Icon(Icons.payments),
            label: const Text('Nouveau versement'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _bientot(context),
            icon: const Icon(Icons.phone_in_talk),
            label: const Text('Ajouter un appel'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _bientot(context),
            icon: const Icon(Icons.sms),
            label: const Text('Envoyer un message'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _bientot(context),
            icon: const Icon(Icons.history),
            label: const Text('Historique'),
          ),
          const Divider(height: 32),
          OutlinedButton.icon(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) =>
                  EcranClientFormulaire(profil: profil, client: client),
            )),
            icon: const Icon(Icons.edit),
            label: const Text('Modifier le compte'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => _basculerBlocage(context),
            icon: Icon(c.bloque ? Icons.lock_open : Icons.block),
            label: Text(c.bloque ? 'Débloquer le client' : 'Bloquer le client'),
          ),
        ],
      ),
    );
  }
}

class _Ligne extends StatelessWidget {
  final String libelle;
  final String valeur;
  const _Ligne(this.libelle, this.valeur);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text('$libelle :',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(child: Text(valeur)),
        ],
      ),
    );
  }
}
