import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/client.dart';
import '../noyau/operation.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import '../services/depot_parametres.dart';
import '../services/gestion_compte.dart';
import 'client_formulaire.dart';
import 'dialogues.dart';
import 'historique.dart';
import 'message_relance.dart';
import 'operation_form.dart';

/// Compte d'un client : informations, situation et opérations.
class EcranClient extends StatelessWidget {
  final ProfilUtilisateur profil;
  final String cle;
  const EcranClient({super.key, required this.profil, required this.cle});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        DepotClients.instance,
        DepotOperations.instance,
        DepotParametres.instance,
      ]),
      builder: (context, _) {
        final c = DepotClients.instance.parCle(cle);
        if (c == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Compte client')),
            body: const Center(child: CircularProgressIndicator()),
          );
        }
        if (!c.actif) {
          return Scaffold(
            appBar: AppBar(title: const Text('Compte client')),
            body: const Center(child: Text('Ce compte a été supprimé.')),
          );
        }
        return _Fiche(
          profil: profil,
          client: c,
          situation: DepotOperations.instance.situationDe(c.cle),
        );
      },
    );
  }
}

class _Fiche extends StatelessWidget {
  final ProfilUtilisateur profil;
  final Client client;
  final Situation situation;
  const _Fiche(
      {required this.profil, required this.client, required this.situation});

  Future<void> _operation(BuildContext context, TypeOperation type) async {
    if (type == TypeOperation.bon && client.bloque) {
      await alerte(context,
          "${client.nom} est bloqué : aucun nouveau bon n'est possible. Débloquez le client d'abord.");
      return;
    }
    if (!context.mounted) return;
    final ok = await Navigator.of(context).push<bool>(MaterialPageRoute<bool>(
      builder: (_) =>
          EcranOperation(profil: profil, client: client, type: type),
    ));
    if (ok == true && context.mounted) {
      afficherInfo(context, 'Opération enregistrée.');
    }
  }

  Future<void> _appeler(BuildContext context) async {
    final numeros = <String>[
      if (client.telephone1.trim().isNotEmpty) client.telephone1.trim(),
      if (client.telephone2.trim().isNotEmpty) client.telephone2.trim(),
    ];
    if (numeros.isEmpty) {
      await alerte(context, "Ce client n'a pas de numéro de téléphone.");
      return;
    }
    String numero = numeros.first;
    if (numeros.length > 1) {
      if (!context.mounted) return;
      final choix = await showDialog<String>(
        context: context,
        builder: (ctx) => SimpleDialog(
          title: const Text('Quel numéro appeler ?'),
          children: [
            for (final n in numeros)
              SimpleDialogOption(
                onPressed: () => Navigator.of(ctx).pop(n),
                child: Text(n, style: const TextStyle(fontSize: 20)),
              ),
          ],
        ),
      );
      if (choix == null) return;
      numero = choix;
    }
    final propre = numero.replaceAll(RegExp(r'[^0-9+]'), '');
    var ouvert = false;
    try {
      ouvert = await launchUrl(Uri(scheme: 'tel', path: propre));
    } catch (_) {}
    if (!ouvert && context.mounted) {
      afficherInfo(context, "Impossible d'ouvrir le téléphone sur cet appareil.");
    }
  }

  Future<void> _message(BuildContext context) async {
    final ok = await Navigator.of(context).push<bool>(MaterialPageRoute<bool>(
      builder: (_) => EcranMessageClient(profil: profil, client: client),
    ));
    if (ok == true && context.mounted) {
      afficherInfo(context, 'Message enregistré, en attente d\'envoi.');
    }
  }

  Future<void> _basculerBlocage(BuildContext context) async {
    final bloquer = !client.bloque;
    final ok = await confirmer(
      context,
      titre: bloquer ? 'Bloquer ce client ?' : 'Débloquer ce client ?',
      message: bloquer
          ? '${client.nom} ne pourra plus recevoir de nouveau bon. Les versements restent possibles.'
          : '${client.nom} pourra de nouveau recevoir des bons.',
      bouton: bloquer ? 'Bloquer' : 'Débloquer',
    );
    if (ok) DepotClients.instance.definirBlocage(client, bloquer);
  }

  Future<void> _effacerHistorique(BuildContext context) async {
    final ok = await confirmer(
      context,
      titre: "Effacer l'historique ?",
      message:
          "Toutes les opérations de ${client.nom} seront retirées du compte : "
          "le montant dû (${formaterMontant(situation.du)}) passera à 0.\n"
          "Cette action est enregistrée dans le journal.",
      bouton: "Effacer l'historique",
      danger: true,
    );
    if (!ok || !context.mounted) return;
    DepotOperations.instance.effacerHistorique(client, profil.nom);
    afficherInfo(context, 'Historique effacé.');
  }

  Future<void> _supprimer(BuildContext context) async {
    final avertissement = situation.du != 0
        ? '⚠️ Ce client a encore un montant dû de ${formaterMontant(situation.du)}.\n\n'
        : '';
    final motif = await demanderMotif(
      context,
      titre: 'Supprimer le compte ?',
      message:
          '${avertissement}Le compte de ${client.nom} (rang ${client.rang}) sera archivé et son numéro redeviendra libre.',
      obligatoire: false,
      bouton: 'Supprimer',
      danger: true,
    );
    if (motif == null || !context.mounted) return;
    GestionCompte.supprimer(client, motif: motif, parNom: profil.nom);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final c = client;
    final s = situation;
    final rouge = s.horsTolerance;
    String date(DateTime? d) => d == null ? '—' : formaterDate(d);
    return Scaffold(
      appBar: AppBar(title: Text('Rang ${c.rang}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (c.enConflit)
            Card(
              color: theme.colorScheme.errorContainer,
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  "⚠️ Ce numéro d'ordre est déjà utilisé par un compte plus ancien. "
                  "L'administrateur doit changer le numéro de ce compte. "
                  "Aucun SMS n'est envoyé en attendant.",
                ),
              ),
            ),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: rouge
                  ? BorderSide(color: theme.colorScheme.error, width: 4)
                  : BorderSide.none,
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(c.nom,
                      style: theme.textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold)),
                  if (c.bloque || c.enConflit || rouge || s.montantEleve) ...[
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: [
                        if (c.bloque)
                          Chip(
                            label: const Text('BLOQUÉ'),
                            backgroundColor: theme.colorScheme.errorContainer,
                          ),
                        if (rouge)
                          Chip(
                            label: const Text('HORS TOLÉRANCE'),
                            backgroundColor: theme.colorScheme.errorContainer,
                          ),
                        if (s.montantEleve) const Chip(label: Text('MONTANT ÉLEVÉ')),
                        if (c.enConflit)
                          const Chip(label: Text('CONFLIT DE RANG')),
                      ],
                    ),
                  ],
                  const SizedBox(height: 12),
                  _Ligne('Rang', '${c.rang}'),
                  _Ligne('Tél', c.telephone1.isEmpty ? '—' : c.telephone1),
                  if (c.telephone2.isNotEmpty) _Ligne('Tél 2', c.telephone2),
                  if (c.autresInfos.isNotEmpty)
                    _Ligne('Autres infos', c.autresInfos),
                  const Divider(height: 24),
                  Text(
                    formaterMontant(s.du),
                    style: theme.textTheme.displaySmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: rouge ? theme.colorScheme.error : null,
                    ),
                  ),
                  Text(s.du > 0
                      ? 'Montant dû'
                      : (s.du < 0 ? 'Le client a versé en trop' : 'Rien à payer')),
                  const SizedBox(height: 8),
                  _Ligne(
                      'Retard',
                      s.retardJours == null
                          ? '—'
                          : libelleRetard(s.retardJours!)),
                  _Ligne('Dernier bon', date(s.dernierBon)),
                  _Ligne('Dernier versement', date(s.dernierVersement)),
                  _Ligne('Dernier appel', date(s.dernierAppel)),
                  _Ligne('Dernier message', date(s.dernierMessage)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => _appeler(context),
            icon: const Icon(Icons.call),
            label: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Text(c.telephone1.isEmpty
                  ? 'Appeler le client'
                  : 'Appeler  ${c.telephone1}'),
            ),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _operation(context, TypeOperation.bon),
            icon: const Icon(Icons.add_shopping_cart),
            label: Text(c.bloque ? 'Nouveau bon (client bloqué)' : 'Nouveau bon'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _operation(context, TypeOperation.versement),
            icon: const Icon(Icons.payments),
            label: const Text('Nouveau versement'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _operation(context, TypeOperation.appel),
            icon: const Icon(Icons.phone_in_talk),
            label: const Text('Ajouter un appel'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => _message(context),
            icon: const Icon(Icons.sms),
            label: const Text('Envoyer un message'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => EcranHistorique(profil: profil, cle: c.cle))),
            icon: const Icon(Icons.history),
            label: const Text('Historique'),
          ),
          const Divider(height: 32),
          OutlinedButton.icon(
            onPressed: () => _basculerBlocage(context),
            icon: Icon(c.bloque ? Icons.lock_open : Icons.block),
            label: Text(c.bloque ? 'Débloquer le client' : 'Bloquer le client'),
          ),
          const SizedBox(height: 8),
          Card(
            child: ExpansionTile(
              leading: const Icon(Icons.settings),
              title: const Text('Options du compte'),
              children: [
                ListTile(
                  leading: const Icon(Icons.edit),
                  title: const Text('Modifier le compte'),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) =>
                        EcranClientFormulaire(profil: profil, client: client),
                  )),
                ),
                ListTile(
                  leading: Icon(Icons.cleaning_services,
                      color: theme.colorScheme.error),
                  title: const Text("Effacer l'historique"),
                  onTap: () => _effacerHistorique(context),
                ),
                ListTile(
                  leading: Icon(Icons.delete_forever,
                      color: theme.colorScheme.error),
                  title: const Text('Supprimer le compte'),
                  onTap: () => _supprimer(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Ligne extends StatelessWidget {
  final String libelle;
  final String valeur;
  const _Ligne(this.libelle, this.valeur);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text('$libelle :',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(child: Text(valeur)),
        ],
      ),
    );
  }
}
