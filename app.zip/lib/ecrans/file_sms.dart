import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/operation.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import '../services/depot_parametres.dart';
import 'dialogues.dart';

/// File des SMS : en attente, en cours, échecs et expirés des 7 derniers jours.
class EcranFileSms extends StatelessWidget {
  final ProfilUtilisateur profil;
  const EcranFileSms({super.key, required this.profil});

  static String libelleEtat(String etat) {
    switch (etat) {
      case 'en_attente':
        return "En attente d'envoi";
      case 'en_cours':
        return "Envoi en cours (ou interrompu)";
      case 'echec':
        return 'Échec';
      case 'expire':
        return 'Expiré';
      case 'envoye':
        return 'Envoyé';
      default:
        return 'Pas de SMS';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('File des SMS')),
      body: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[
          DepotOperations.instance,
          DepotClients.instance,
          DepotParametres.instance,
        ]),
        builder: (context, _) {
          final limite = DateTime.now().subtract(const Duration(days: 7));
          final liste = DepotOperations.instance
              .smsDansEtats(<String>{'en_attente', 'en_cours', 'echec', 'expire'})
              .where((o) => o.saisieLe.isAfter(limite))
              .toList();
          final sansExpediteur =
              DepotParametres.instance.appareilExpediteurId.isEmpty;
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Card(
                  color: sansExpediteur
                      ? theme.colorScheme.errorContainer
                      : theme.colorScheme.secondaryContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Text(sansExpediteur
                        ? "Aucun téléphone expéditeur n'est désigné : rien ne partira. Désignez-le dans Paramètres, sur le téléphone qui garde la SIM."
                        : "Les SMS sont envoyés par le téléphone expéditeur tant que son application est ouverte (SIM ${DepotParametres.instance.simIndex})."),
                  ),
                ),
              ),
              Expanded(
                child: liste.isEmpty
                    ? const Center(child: Text('Aucun SMS en attente.'))
                    : ListView.separated(
                        itemCount: liste.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final o = liste[i];
                          final c = DepotClients.instance.parCle(o.clientCle);
                          final suspendu = c != null && c.enConflit;
                          final sous = <String>[
                            '${libelleType(o.type)}'
                                '${o.montant > 0 ? ' ${formaterMontant(o.montant)}' : ''}'
                                ' — ${formaterDateHeure(o.saisieLe)}',
                            suspendu
                                ? 'Suspendu : conflit de numéro'
                                : libelleEtat(o.smsEtat),
                            if (o.smsErreur.isNotEmpty) o.smsErreur,
                          ].join('\n');
                          return ListTile(
                            isThreeLine: true,
                            title: Text(c == null
                                ? 'Rang ${o.clientRang}'
                                : '${c.nom} (rang ${c.rang})'),
                            subtitle: Text(sous),
                            trailing: PopupMenuButton<String>(
                              onSelected: (v) async {
                                if (v == 'reessayer') {
                                  DepotOperations.instance.majSms(o,
                                      etat: 'en_attente', repris: true);
                                  afficherInfo(context, 'Remis en file.');
                                } else if (v == 'abandonner') {
                                  final ok = await confirmer(context,
                                      titre: 'Ne plus envoyer ce SMS ?',
                                      message:
                                          "Le SMS sera retiré de la file. L'opération reste dans l'historique.",
                                      bouton: 'Retirer');
                                  if (ok) {
                                    DepotOperations.instance
                                        .majSms(o, etat: 'aucun');
                                  }
                                }
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(
                                    value: 'reessayer', child: Text('Réessayer')),
                                PopupMenuItem(
                                    value: 'abandonner',
                                    child: Text('Ne plus envoyer')),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
