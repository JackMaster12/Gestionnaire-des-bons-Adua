import 'dart:async';

import 'package:flutter/material.dart';

import '../app.dart';
import '../constantes.dart';
import '../donnees/plateforme.dart';
import '../theme.dart';
import '../widgets/logo.dart';

/// Écran d'accueil animé (logo, nom, son), puis passage à l'application.
class EcranDemarrage extends StatefulWidget {
  const EcranDemarrage({super.key});

  @override
  State<EcranDemarrage> createState() => _EtatDemarrage();
}

class _EtatDemarrage extends State<EcranDemarrage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _anim;
  Timer? _minuterie;
  bool _fini = false;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..forward();
    jouerSonDemarrage();
    _minuterie = Timer(const Duration(milliseconds: 2600), () {
      if (mounted) setState(() => _fini = true);
    });
  }

  @override
  void dispose() {
    _minuterie?.cancel();
    _anim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: _fini
          ? const PorteAcces(key: ValueKey<String>('app'))
          : KeyedSubtree(
              key: const ValueKey<String>('splash'),
              child: _splash(),
            ),
    );
  }

  Widget _splash() {
    final logo = CurvedAnimation(
        parent: _anim, curve: const Interval(0.0, 0.55, curve: Curves.elasticOut));
    final texte = CurvedAnimation(
        parent: _anim, curve: const Interval(0.45, 0.85, curve: Curves.easeOut));
    final barre = CurvedAnimation(
        parent: _anim, curve: const Interval(0.0, 1.0, curve: Curves.easeInOut));
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ScaleTransition(
              scale: logo,
              child: const LogoAdua(taille: 120),
            ),
            const SizedBox(height: 24),
            FadeTransition(
              opacity: texte,
              child: SlideTransition(
                position: Tween<Offset>(
                        begin: const Offset(0, 0.4), end: Offset.zero)
                    .animate(texte),
                child: Column(
                  children: [
                    const Text(
                      'Bons ADUA',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                        color: CouleursAdua.vertFonce,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Dépôt pharmaceutique ADUA - Zinder',
                      style: TextStyle(fontSize: 15, color: CouleursAdua.bleu),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Version $versionAppli',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 36),
            SizedBox(
              width: 160,
              child: AnimatedBuilder(
                animation: barre,
                builder: (context, _) => LinearProgressIndicator(
                  value: barre.value,
                  minHeight: 5,
                  borderRadius: BorderRadius.circular(3),
                  color: CouleursAdua.vert,
                  backgroundColor: CouleursAdua.fond,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
