import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../services/depot_parametres.dart';
import 'dialogues.dart';

/// Texte des SMS automatiques (modifiable par l'administrateur).
class EcranModelesSms extends StatefulWidget {
  final ProfilUtilisateur profil;
  const EcranModelesSms({super.key, required this.profil});

  @override
  State<EcranModelesSms> createState() => _EtatModeles();
}

class _EtatModeles extends State<EcranModelesSms> {
  final _bon = TextEditingController();
  final _versement = TextEditingController();
  final _relance = TextEditingController();

  @override
  void initState() {
    super.initState();
    final p = DepotParametres.instance;
    _bon.text = p.modeleSmsBon;
    _versement.text = p.modeleSmsVersement;
    _relance.text = p.modeleRelance;
  }

  @override
  void dispose() {
    _bon.dispose();
    _versement.dispose();
    _relance.dispose();
    super.dispose();
  }

  void _enregistrer() {
    if (_bon.text.trim().isEmpty ||
        _versement.text.trim().isEmpty ||
        _relance.text.trim().isEmpty) {
      afficherInfo(context, 'Aucun modèle ne peut être vide.');
      return;
    }
    DepotParametres.instance.modifier(<String, dynamic>{
      'modeleSmsBon': _bon.text.trim(),
      'modeleSmsVersement': _versement.text.trim(),
      'modeleRelance': _relance.text.trim(),
    }, journal: 'modèles de SMS modifiés');
    afficherInfo(context, 'Modèles enregistrés.');
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final admin = widget.profil.estAdmin;
    return Scaffold(
      appBar: AppBar(title: const Text('Modèles de SMS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Mots à placer entre crochets, remplacés automatiquement :\n'
              '• Bon et versement : [montant] [nom] [rang] [total_avant] [total_apres]\n'
              '• Relance : [nom] [rang] [total] [retard]'),
          const SizedBox(height: 16),
          TextField(
            controller: _bon,
            enabled: admin,
            maxLines: 6,
            decoration: const InputDecoration(labelText: 'SMS après un bon'),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _versement,
            enabled: admin,
            maxLines: 6,
            decoration: const InputDecoration(labelText: 'SMS après un versement'),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _relance,
            enabled: admin,
            maxLines: 5,
            decoration: const InputDecoration(labelText: 'SMS de relance'),
          ),
          const SizedBox(height: 20),
          if (admin)
            FilledButton(
              onPressed: _enregistrer,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Enregistrer'),
              ),
            )
          else
            const Text("Seul l'administrateur peut modifier les modèles."),
        ],
      ),
    );
  }
}
