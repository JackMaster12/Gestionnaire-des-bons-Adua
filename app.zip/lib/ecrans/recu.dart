import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../noyau/client.dart';
import '../noyau/operation.dart';
import '../services/depot_operations.dart';
import '../services/rapport_pdf.dart';

/// Ouvre l'aperçu du reçu (ticket) d'un bon ou d'un versement.
void ouvrirRecu(BuildContext context, Client client, Operation op) {
  Navigator.of(context).push(MaterialPageRoute<void>(
    builder: (_) => EcranRecu(client: client, op: op),
  ));
}

class EcranRecu extends StatefulWidget {
  final Client client;
  final Operation op;
  const EcranRecu({super.key, required this.client, required this.op});

  @override
  State<EcranRecu> createState() => _EtatRecu();
}

class _EtatRecu extends State<EcranRecu> {
  int _largeur = 80;

  @override
  Widget build(BuildContext context) {
    final nom = 'recu_${widget.client.rang}_${widget.op.type.name}.pdf';
    return Scaffold(
      appBar: AppBar(title: const Text('Reçu (ticket)')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment<int>(value: 80, label: Text('Rouleau 80 mm')),
                ButtonSegment<int>(value: 57, label: Text('Rouleau 57 mm')),
              ],
              selected: <int>{_largeur},
              onSelectionChanged: (s) => setState(() => _largeur = s.first),
            ),
          ),
          Expanded(
            child: PdfPreview(
              key: ValueKey<int>(_largeur),
              build: (format) => recuOperation(
                client: widget.client,
                op: widget.op,
                operationsClient:
                    DepotOperations.instance.deClient(widget.client.cle),
                largeurMm: _largeur,
                edite: DateTime.now(),
              ),
              pdfFileName: nom,
              canChangePageFormat: false,
              canChangeOrientation: false,
              canDebug: false,
            ),
          ),
        ],
      ),
    );
  }
}
