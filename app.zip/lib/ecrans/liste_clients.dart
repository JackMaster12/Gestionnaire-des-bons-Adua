import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import '../services/depot_parametres.dart';
import 'client_fiche.dart';

/// Liste des comptes d'une catégorie du tableau de bord
/// (bloqués, montants élevés, hors tolérance, avec dette).
class EcranListeClients extends StatelessWidget {
  final ProfilUtilisateur profil;
  final FiltreListe filtre;
  const EcranListeClients({super.key, required this.profil, required this.filtre});

  String get _titre {
    switch (filtre) {
      case FiltreListe.avecDette:
        return 'Comptes avec une dette';
      case FiltreListe.horsTolerance:
        return 'Hors période de tolérance';
      case FiltreListe.montantsEleves:
        return 'Montants élevés';
      case FiltreListe.bloques:
        return 'Comptes bloqués';
    }
  }

  String _explication(DepotParametres p) {
    switch (filtre) {
      case FiltreListe.avecDette:
        return 'Clients dont le montant dû est supérieur à 0.';
      case FiltreListe.horsTolerance:
        return 'Dette sans versement depuis plus de ${p.toleranceJours} jours.';
      case FiltreListe.montantsEleves:
        return 'Montant dû supérieur à ${formaterMontant(p.seuilMontant)}.';
      case FiltreListe.bloques:
        return 'Clients qui ne peuvent plus prendre de bon.';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(_titre)),
      body: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[
          DepotClients.instance,
          DepotOperations.instance,
          DepotParametres.instance,
        ]),
        builder: (context, _) {
          final lignes = filtrerLignes(
            DepotOperations.instance.lignes(DepotClients.instance.actifs),
            filtre,
          );
          final total = lignes.fold<int>(
              0, (s, l) => s + (l.situation.du > 0 ? l.situation.du : 0));
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Card(
                  color: theme.colorScheme.secondaryContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${lignes.length} compte${lignes.length > 1 ? 's' : ''}'
                          '  •  Total dû : ${formaterMontant(total)}',
                          style: theme.textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(_explication(DepotParametres.instance)),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: lignes.isEmpty
                    ? Center(
                        child: Text('Aucun compte dans cette liste.',
                            style: theme.textTheme.titleMedium))
                    : ListView.separated(
                        itemCount: lignes.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final l = lignes[i];
                          final c = l.client;
                          final s = l.situation;
                          final infos = <String>[
                            'Rang ${c.rang}',
                            if (s.retardJours != null)
                              'retard ${libelleRetard(s.retardJours!)}',
                            if (c.bloque) 'BLOQUÉ',
                          ].join('  •  ');
                          return ListTile(
                            title: Text(c.nom,
                                style: const TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold)),
                            subtitle: Text(infos),
                            trailing: Text(
                              formaterMontant(s.du),
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: s.horsTolerance
                                    ? theme.colorScheme.error
                                    : null,
                              ),
                            ),
                            onTap: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                    builder: (_) => EcranClient(
                                        profil: profil, cle: c.cle))),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
