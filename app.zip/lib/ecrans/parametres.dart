import '../donnees/firebase.dart';
import 'package:flutter/material.dart';

import '../services/affichage.dart';
import 'package:flutter/services.dart';

import '../constantes.dart';
import '../donnees/plateforme.dart';
import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../services/appareil_service.dart';
import '../services/depot_parametres.dart';
import '../services/service_sms.dart';
import '../services/sms_natif.dart';
import 'dialogues.dart';
import 'file_sms.dart';
import 'modeles_sms.dart';
import '../services/journal_service.dart';
import '../services/outils.dart';

class EcranParametres extends StatefulWidget {
  final ProfilUtilisateur profil;
  const EcranParametres({super.key, required this.profil});

  @override
  State<EcranParametres> createState() => _EtatParametres();
}

class _EtatParametres extends State<EcranParametres> {
  final _nom = TextEditingController();
  final _tolerance = TextEditingController();
  final _seuil = TextEditingController();
  final _calmeDebut = TextEditingController();
  final _calmeFin = TextEditingController();
  String _id = '';
  bool _chargement = true;

  @override
  void initState() {
    super.initState();
    _charger();
  }

  @override
  void dispose() {
    _nom.dispose();
    _tolerance.dispose();
    _seuil.dispose();
    _calmeDebut.dispose();
    _calmeFin.dispose();
    super.dispose();
  }

  Future<void> _charger() async {
    final id = await ServiceAppareil.id();
    var nom = '';
    try {
      final d = await FirebaseFirestore.instance
          .collection(colAppareils)
          .doc(id)
          .get()
          .timeout(const Duration(seconds: 5));
      nom = (d.data()?['nom'] ?? '') as String;
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _id = id;
      _nom.text = nom;
      _tolerance.text = '${DepotParametres.instance.toleranceJours}';
      _seuil.text = '${DepotParametres.instance.seuilMontant}';
      _calmeDebut.text = '${DepotParametres.instance.heuresCalmesDebut}';
      _calmeFin.text = '${DepotParametres.instance.heuresCalmesFin}';
      _chargement = false;
    });
  }

  void _message(String texte) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texte)));
  }

  void _enregistrerNom() {
    final nom = _nom.text.trim();
    if (nom.isEmpty) {
      _message("Saisissez un nom pour l'appareil.");
      return;
    }
    final ref = FirebaseFirestore.instance.collection(colAppareils).doc(_id);
    lancer(() => ref.set(<String, dynamic>{
          'nom': nom,
          'majLe': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true)));
    _message("Nom de l'appareil enregistré.");
  }

  void _enregistrerSeuils() {
    final tol = int.tryParse(_tolerance.text.trim());
    final seuil = int.tryParse(_seuil.text.trim());
    if (tol == null || tol < 1 || tol > 3650) {
      _message('Tolérance : saisissez un nombre de jours entre 1 et 3650.');
      return;
    }
    if (seuil == null || seuil < 1) {
      _message('Seuil : saisissez un montant supérieur à 0.');
      return;
    }
    final debut = int.tryParse(_calmeDebut.text.trim());
    final fin = int.tryParse(_calmeFin.text.trim());
    if (debut == null || fin == null || debut < 0 || debut > 23 || fin < 0 || fin > 23) {
      _message('Heures calmes : saisissez des heures de 0 à 23.');
      return;
    }
    DepotParametres.instance.modifier(<String, dynamic>{
      'heuresCalmesDebut': debut,
      'heuresCalmesFin': fin,
    }, journal: 'heures calmes $debut h - $fin h');
    DepotParametres.instance.enregistrerSeuils(tolerance: tol, seuil: seuil);
    _message('Règles de suivi enregistrées (${formaterMontant(seuil)}, $tol jours).');
  }

  Future<void> _autoriserSms() async {
    final ok = await SmsNatif.demanderPermissions();
    if (!mounted) return;
    _message(ok
        ? "Envoi de SMS autorisé."
        : "Permission refusée. Autorisez « SMS » dans les réglages Android de l'application.");
  }

  Future<void> _testerSms() async {
    final champ = TextEditingController();
    final numero = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('SMS de test'),
        content: TextField(
          controller: champ,
          keyboardType: TextInputType.phone,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Numéro de destination'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Annuler')),
          FilledButton(
              onPressed: () => Navigator.of(ctx).pop(champ.text.trim()),
              child: const Text('Envoyer')),
        ],
      ),
    );
    champ.dispose();
    if (numero == null || numero.isEmpty) return;
    final erreur = await SmsNatif.envoyer(
        numero.replaceAll(RegExp(r'[^0-9+]'), ''),
        'Test ADUA : le téléphone expéditeur fonctionne.',
        DepotParametres.instance.simIndex);
    if (!mounted) return;
    _message(erreur == null ? 'SMS de test envoyé.' : 'Échec : $erreur');
  }

  void _changerExpediteur(bool devenir, String ancienId) {
    final db = FirebaseFirestore.instance;
    final lot = db.batch();
    final maintenant = FieldValue.serverTimestamp();
    if (devenir) {
      if (ancienId.isNotEmpty && ancienId != _id) {
        lot.set(
            db.collection(colAppareils).doc(ancienId),
            <String, dynamic>{'estExpediteurSms': false, 'majLe': maintenant},
            SetOptions(merge: true));
      }
      lot.set(
          db.collection(colAppareils).doc(_id),
          <String, dynamic>{'estExpediteurSms': true, 'majLe': maintenant},
          SetOptions(merge: true));
      lot.set(
          db.collection(colParametres).doc(docParametres),
          <String, dynamic>{'appareilExpediteurId': _id, 'majLe': maintenant},
          SetOptions(merge: true));
    } else {
      lot.set(
          db.collection(colAppareils).doc(_id),
          <String, dynamic>{'estExpediteurSms': false, 'majLe': maintenant},
          SetOptions(merge: true));
      lot.set(
          db.collection(colParametres).doc(docParametres),
          <String, dynamic>{'appareilExpediteurId': '', 'majLe': maintenant},
          SetOptions(merge: true));
    }
    lancer(() => lot.commit());
    Journal.ecrire(devenir ? 'expediteur_designe' : 'expediteur_retire',
        detail: _id);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: _chargement
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('Taille des écritures', style: theme.textTheme.titleMedium),
                const SizedBox(height: 8),
                ListenableBuilder(
                  listenable: Affichage.instance,
                  builder: (context, _) => Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final e in Affichage.choix)
                        ChoiceChip(
                          label: Text(Affichage.libelle(e)),
                          selected: (Affichage.instance.echelle - e).abs() < 0.01,
                          onSelected: (_) => Affichage.instance.definir(e),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Text('Cet appareil', style: theme.textTheme.titleMedium),
                const SizedBox(height: 10),
                TextField(
                  controller: _nom,
                  decoration: const InputDecoration(
                    labelText: "Nom de l'appareil",
                    helperText: 'Exemple : Téléphone caisse, Ordinateur bureau',
                  ),
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton.tonal(
                    onPressed: _enregistrerNom,
                    child: const Text('Enregistrer le nom'),
                  ),
                ),
                const SizedBox(height: 4),
                Text('Identifiant : ${_id.substring(0, 8)}',
                    style: theme.textTheme.bodySmall),
                const Divider(height: 36),
                Text('Envoi des SMS', style: theme.textTheme.titleMedium),
                const SizedBox(height: 6),
                StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                  stream: FirebaseFirestore.instance
                      .collection(colParametres)
                      .doc(docParametres)
                      .snapshots(),
                  builder: (context, snap) {
                    if (estWindows) {
                      return const Text(
                          "L'envoi des SMS se fait depuis le téléphone expéditeur : l'ordinateur n'a pas de carte SIM.");
                    }
                    final data = snap.data?.data() ?? <String, dynamic>{};
                    final expediteur =
                        (data['appareilExpediteurId'] ?? '') as String;
                    final moi = expediteur == _id && _id.isNotEmpty;
                    final texte = expediteur.isEmpty
                        ? 'Aucun appareil expéditeur désigné.'
                        : (moi
                            ? "Cet appareil est l'expéditeur (SIM 1 par défaut)."
                            : "Un autre appareil est l'expéditeur.");
                    final interrupteur = SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Cet appareil envoie les SMS'),
                      subtitle: Text(widget.profil.estAdmin
                          ? texte
                          : "$texte\nSeul l'administrateur peut le modifier."),
                      value: moi,
                      onChanged: widget.profil.estAdmin
                          ? (v) => _changerExpediteur(v, expediteur)
                          : null,
                    );
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        interrupteur,
                        if (moi) ...[
                          Text(
                              'Carte utilisée : SIM ${DepotParametres.instance.simIndex}.'
                              ' Gardez ce téléphone chargé, avec l\'application ouverte.',
                              style: theme.textTheme.bodySmall),
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              OutlinedButton.icon(
                                onPressed: _autoriserSms,
                                icon: const Icon(Icons.verified_user),
                                label: const Text("Autoriser l'envoi de SMS"),
                              ),
                              OutlinedButton.icon(
                                onPressed: _testerSms,
                                icon: const Icon(Icons.sms),
                                label: const Text('SMS de test'),
                              ),
                            ],
                          ),
                        ],
                      ],
                    );
                  },
                ),
                const SizedBox(height: 8),
                ListenableBuilder(
                  listenable: DepotParametres.instance,
                  builder: (context, _) {
                    final p = DepotParametres.instance;
                    final suffixe = widget.profil.estAdmin
                        ? ''
                        : "\nSeul l'administrateur peut le modifier.";
                    return SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Relance automatique'),
                      subtitle: Text(
                          'Chaque jour vers ${p.relanceAutoHeure}h, les comptes hors tolérance reçoivent un SMS '
                          '(au plus un tous les ${p.relanceAutoIntervalleJours} jours).'
                          '$suffixe'),
                      value: p.relanceAutoActive,
                      onChanged: widget.profil.estAdmin
                          ? (v) => p.modifier(<String, dynamic>{
                                'relanceAutoActive': v
                              }, journal: 'relance automatique : $v')
                          : null,
                    );
                  },
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.edit_note),
                  title: const Text('Modèles de SMS'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                      builder: (_) => EcranModelesSms(profil: widget.profil))),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.outbox),
                  title: const Text('File des SMS'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                      builder: (_) => EcranFileSms(profil: widget.profil))),
                ),
                ListenableBuilder(
                  listenable: ServiceSms.instance,
                  builder: (context, _) {
                    final m = ServiceSms.instance.dernierMessage;
                    return m.isEmpty
                        ? const SizedBox.shrink()
                        : Text(m, style: TextStyle(color: theme.colorScheme.error));
                  },
                ),
                const Divider(height: 36),
                Text('Règles de suivi', style: theme.textTheme.titleMedium),
                const SizedBox(height: 10),
                TextField(
                  controller: _tolerance,
                  enabled: widget.profil.estAdmin,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                    labelText: 'Période de tolérance (jours)',
                    helperText:
                        'Un client qui doit de l\'argent sans verser depuis plus de ce délai est « hors tolérance ».',
                    helperMaxLines: 3,
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _seuil,
                  enabled: widget.profil.estAdmin,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                    labelText: 'Seuil de montant élevé (F)',
                    helperText: 'Un montant dû supérieur à ce seuil est signalé.',
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _calmeDebut,
                        enabled: widget.profil.estAdmin,
                        keyboardType: TextInputType.number,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        decoration: const InputDecoration(
                            labelText: 'Heures calmes : début (h)'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: _calmeFin,
                        enabled: widget.profil.estAdmin,
                        keyboardType: TextInputType.number,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        decoration: const InputDecoration(
                            labelText: 'Heures calmes : fin (h)'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const Text(
                    'Aucun SMS automatique ne part pendant les heures calmes (22 et 7 par défaut).'),
                const SizedBox(height: 10),
                if (widget.profil.estAdmin)
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton.tonal(
                      onPressed: _enregistrerSeuils,
                      child: const Text('Enregistrer les règles'),
                    ),
                  )
                else
                  const Text("Seul l'administrateur peut modifier ces règles."),
                const Divider(height: 36),
                Text('À propos', style: theme.textTheme.titleMedium),
                const SizedBox(height: 6),
                const Text('Gestionnaire des bons ADUA'),
                Text('Version $versionAppli'),
              ],
            ),
    );
  }
}
