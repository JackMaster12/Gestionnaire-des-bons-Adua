import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/operation.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import 'dialogues.dart';
import 'recu.dart';

/// Historique complet d'un compte : le plus récent en premier.
class EcranHistorique extends StatelessWidget {
  final ProfilUtilisateur profil;
  final String cle;
  const EcranHistorique({super.key, required this.profil, required this.cle});

  static String _libelleSms(String etat) {
    switch (etat) {
      case 'en_attente':
        return "SMS en attente d'envoi";
      case 'en_cours':
        return "SMS en cours d'envoi";
      case 'envoye':
        return 'SMS envoyé';
      case 'echec':
        return "SMS : échec d'envoi";
      case 'expire':
        return 'SMS expiré (trop ancien)';
      default:
        return 'Pas de SMS';
    }
  }

  Future<void> _details(BuildContext context, Operation o, int? soldeApres) async {
    final lignes = <String>[
      'Date : ${formaterDate(o.dateOperation)}',
      'Saisie le : ${formaterDateHeure(o.saisieLe)}',
      if (o.parNom.isNotEmpty) 'Par : ${o.parNom}',
      if (o.montant > 0) 'Montant : ${formaterMontant(o.montant)}',
      if (soldeApres != null) 'Reste à payer après : ${formaterMontant(soldeApres)}',
      if (o.note.isNotEmpty) '\n${o.note}',
      '\n${_libelleSms(o.smsEtat)}',
      if (o.smsErreur.isNotEmpty) 'Erreur : ${o.smsErreur}',
      if (o.smsTexte.isNotEmpty) '\nTexte envoyé :\n${o.smsTexte}',
      if (!o.valide) '\nANNULÉE : ${o.annuleMotif}',
    ];
    final annuler = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(libelleType(o.type)),
        content: SingleChildScrollView(child: Text(lignes.join('\n'))),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Fermer'),
          ),
          if (o.valide && (o.type == TypeOperation.bon || o.type == TypeOperation.versement))
            TextButton.icon(
              onPressed: () {
                Navigator.of(ctx).pop(false);
                final c = DepotClients.instance.parCle(o.clientCle);
                if (c != null) ouvrirRecu(context, c, o);
              },
              icon: const Icon(Icons.receipt_long),
              label: const Text('Reçu'),
            ),
          if (o.valide)
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(ctx).colorScheme.error,
                foregroundColor: Theme.of(ctx).colorScheme.onError,
              ),
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text("Annuler l'opération"),
            ),
        ],
      ),
    );
    if (annuler != true || !context.mounted) return;
    final motif = await demanderMotif(
      context,
      titre: "Annuler l'opération ?",
      message:
          "${libelleType(o.type)} ${o.montant > 0 ? formaterMontant(o.montant) : ''} du ${formaterDate(o.dateOperation)}.\n"
          "L'opération reste visible dans l'historique mais ne compte plus.",
      obligatoire: true,
      bouton: 'Annuler l\'opération',
      danger: true,
    );
    if (motif == null) return;
    DepotOperations.instance.annuler(o, motif, profil.nom);
    if (context.mounted) afficherInfo(context, 'Opération annulée.');
  }

  IconData _icone(TypeOperation t) {
    switch (t) {
      case TypeOperation.bon:
        return Icons.add_shopping_cart;
      case TypeOperation.versement:
        return Icons.payments;
      case TypeOperation.appel:
        return Icons.phone_in_talk;
      case TypeOperation.message:
        return Icons.sms;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListenableBuilder(
      listenable: Listenable.merge(
          <Listenable>[DepotOperations.instance, DepotClients.instance]),
      builder: (context, _) {
        final client = DepotClients.instance.parCle(cle);
        final ops = DepotOperations.instance.deClient(cle);
        // Reste à payer après chaque opération (calcul du plus ancien au plus récent).
        final soldes = <String, int>{};
        var courant = 0;
        for (final o in ops) {
          if (o.valide) {
            if (o.type == TypeOperation.bon) courant += o.montant;
            if (o.type == TypeOperation.versement) courant -= o.montant;
            if (o.type == TypeOperation.bon || o.type == TypeOperation.versement) {
              soldes[o.cle] = courant;
            }
          }
        }
        final recentes = ops.reversed.toList();
        return Scaffold(
          appBar: AppBar(
              title: Text(client == null ? 'Historique' : 'Historique — ${client.nom}')),
          body: recentes.isEmpty
              ? const Center(child: Text("Aucune opération pour l'instant."))
              : ListView.separated(
                  itemCount: recentes.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final o = recentes[i];
                    final barre = o.valide
                        ? null
                        : const TextStyle(decoration: TextDecoration.lineThrough);
                    final couleur = !o.valide
                        ? theme.disabledColor
                        : o.type == TypeOperation.bon
                            ? theme.colorScheme.error
                            : o.type == TypeOperation.versement
                                ? Colors.green.shade700
                                : theme.colorScheme.primary;
                    final solde = soldes[o.cle];
                    final titre = o.montant > 0
                        ? '${libelleType(o.type)} — ${formaterMontant(o.montant)}'
                        : libelleType(o.type);
                    final sous = <String>[
                      formaterDate(o.dateOperation),
                      if (solde != null) 'Reste : ${formaterMontant(solde)}',
                      if (!o.valide) 'ANNULÉE : ${o.annuleMotif}',
                      if (o.note.isNotEmpty) o.note,
                    ].join('\n');
                    return ListTile(
                      isThreeLine: sous.contains('\n'),
                      leading: Icon(_icone(o.type), color: couleur),
                      title: Text(titre, style: barre),
                      subtitle: Text(sous, maxLines: 4, overflow: TextOverflow.ellipsis),
                      onTap: () => _details(context, o, solde),
                    );
                  },
                ),
        );
      },
    );
  }
}
