import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/rangs.dart';
import '../services/appareil_service.dart';
import '../services/auth_service.dart';
import '../services/depot_clients.dart';
import 'client_formulaire.dart';
import 'comptes.dart';
import 'conflits.dart';
import 'parametres.dart';
import 'recherche.dart';

class EcranAccueil extends StatefulWidget {
  final ProfilUtilisateur profil;
  const EcranAccueil({super.key, required this.profil});

  @override
  State<EcranAccueil> createState() => _EtatAccueil();
}

class _EtatAccueil extends State<EcranAccueil> {
  final DepotClients _depot = DepotClients.instance;

  @override
  void initState() {
    super.initState();
    ServiceAppareil.enregistrer();
    _depot.demarrer();
  }

  @override
  void dispose() {
    _depot.arreter();
    super.dispose();
  }

  void _bientot() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Disponible à l'étape 3B (bons et historique).")),
    );
  }

  void _aller(Widget ecran) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ecran));
  }

  void _menu(String valeur) {
    switch (valeur) {
      case 'parametres':
        _aller(EcranParametres(profil: widget.profil));
        break;
      case 'comptes':
        _aller(EcranComptes(profil: widget.profil));
        break;
      case 'conflits':
        _aller(EcranConflits(profil: widget.profil));
        break;
      case 'deconnexion':
        ServiceAuth.seDeconnecter();
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final profil = widget.profil;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bons ADUA'),
        actions: [
          PopupMenuButton<String>(
            onSelected: _menu,
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'parametres', child: Text('Paramètres')),
              if (profil.estAdmin)
                const PopupMenuItem(
                    value: 'comptes', child: Text('Comptes utilisateurs')),
              if (profil.estAdmin)
                const PopupMenuItem(
                    value: 'conflits', child: Text('Conflits de numéro')),
              const PopupMenuItem(
                  value: 'deconnexion', child: Text('Se déconnecter')),
            ],
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: _depot,
        builder: (context, _) {
          final conflits = _depot.enConflit.length;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Bonjour ${profil.nom}',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                  '${profil.estAdmin ? 'Administrateur' : 'Compte secondaire'}'
                  '  •  ${_depot.nombreActifs} / $rangMax comptes'),
              if (profil.estAdmin && conflits > 0) ...[
                const SizedBox(height: 12),
                Card(
                  color: theme.colorScheme.errorContainer,
                  child: ListTile(
                    leading: const Icon(Icons.warning_amber),
                    title: Text(conflits == 1
                        ? '1 compte en conflit de numéro'
                        : '$conflits comptes en conflit de numéro'),
                    subtitle: const Text('Appuyez pour les régler.'),
                    onTap: () => _aller(EcranConflits(profil: profil)),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Text('Tableau de bord', style: theme.textTheme.titleMedium),
              const SizedBox(height: 8),
              GridView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  mainAxisExtent: 92,
                ),
                children: [
                  const _CarteStat(titre: 'Total dû', valeur: '—'),
                  const _CarteStat(titre: 'Hors tolérance', valeur: '—'),
                  _CarteStat(
                      titre: 'Comptes bloqués',
                      valeur: '${_depot.nombreBloques}'),
                  const _CarteStat(titre: 'SMS en attente', valeur: '—'),
                ],
              ),
              const SizedBox(height: 20),
              Text('Commandes', style: theme.textTheme.titleMedium),
              const SizedBox(height: 8),
              GridView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  mainAxisExtent: 84,
                ),
                children: [
                  _BoutonAccueil(
                    icone: Icons.tag,
                    titre: 'Recherche par rang',
                    onTap: () => _aller(EcranRecherche(
                        profil: profil, mode: ModeRecherche.rang)),
                  ),
                  _BoutonAccueil(
                    icone: Icons.person_search,
                    titre: 'Recherche par nom',
                    onTap: () => _aller(EcranRecherche(
                        profil: profil, mode: ModeRecherche.nom)),
                  ),
                  _BoutonAccueil(
                    icone: Icons.phone,
                    titre: 'Recherche par téléphone',
                    onTap: () => _aller(EcranRecherche(
                        profil: profil, mode: ModeRecherche.telephone)),
                  ),
                  _BoutonAccueil(
                    icone: Icons.person_add,
                    titre: 'Nouveau client',
                    onTap: () =>
                        _aller(EcranClientFormulaire(profil: profil)),
                  ),
                  _BoutonAccueil(
                      icone: Icons.schedule,
                      titre: 'Clients en retard',
                      onTap: _bientot),
                  _BoutonAccueil(
                      icone: Icons.payments,
                      titre: 'Montants élevés',
                      onTap: _bientot),
                ],
              ),
            ],
          );
        },
      ),
    );
  }
}

class _CarteStat extends StatelessWidget {
  final String titre;
  final String valeur;
  const _CarteStat({required this.titre, required this.valeur});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(titre, style: theme.textTheme.labelLarge),
            const SizedBox(height: 4),
            Text(valeur,
                style: theme.textTheme.headlineSmall
                    ?.copyWith(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

class _BoutonAccueil extends StatelessWidget {
  final IconData icone;
  final String titre;
  final VoidCallback onTap;
  const _BoutonAccueil(
      {required this.icone, required this.titre, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icone, size: 28, color: theme.colorScheme.primary),
              const SizedBox(height: 6),
              Text(titre,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.labelLarge),
            ],
          ),
        ),
      ),
    );
  }
}
