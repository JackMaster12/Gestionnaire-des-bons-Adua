import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/rangs.dart';
import '../services/appareil_service.dart';
import '../services/auth_service.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import '../services/depot_parametres.dart';
import 'client_formulaire.dart';
import 'comptes.dart';
import 'conflits.dart';
import 'liste_clients.dart';
import 'parametres.dart';
import 'recherche.dart';
import 'tous_clients.dart';

class EcranAccueil extends StatefulWidget {
  final ProfilUtilisateur profil;
  const EcranAccueil({super.key, required this.profil});

  @override
  State<EcranAccueil> createState() => _EtatAccueil();
}

class _EtatAccueil extends State<EcranAccueil> {
  final DepotClients _depot = DepotClients.instance;
  bool _tableauDeplie = false;

  @override
  void initState() {
    super.initState();
    ServiceAppareil.enregistrer();
    DepotParametres.instance.demarrer();
    _depot.demarrer();
    DepotOperations.instance.demarrer();
  }

  @override
  void dispose() {
    _depot.arreter();
    DepotOperations.instance.arreter();
    DepotParametres.instance.arreter();
    super.dispose();
  }

  void _aller(Widget ecran) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ecran));
  }

  void _liste(FiltreListe filtre) {
    _aller(EcranListeClients(profil: widget.profil, filtre: filtre));
  }

  void _menu(String valeur) {
    switch (valeur) {
      case 'parametres':
        _aller(EcranParametres(profil: widget.profil));
        break;
      case 'comptes':
        _aller(EcranComptes(profil: widget.profil));
        break;
      case 'conflits':
        _aller(EcranConflits(profil: widget.profil));
        break;
      case 'deconnexion':
        ServiceAuth.seDeconnecter();
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final profil = widget.profil;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bons ADUA'),
        actions: [
          PopupMenuButton<String>(
            onSelected: _menu,
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'parametres', child: Text('Paramètres')),
              if (profil.estAdmin)
                const PopupMenuItem(
                    value: 'comptes', child: Text('Comptes utilisateurs')),
              if (profil.estAdmin)
                const PopupMenuItem(
                    value: 'conflits', child: Text('Conflits de numéro')),
              const PopupMenuItem(
                  value: 'deconnexion', child: Text('Se déconnecter')),
            ],
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[
          _depot,
          DepotOperations.instance,
          DepotParametres.instance,
        ]),
        builder: (context, _) {
          final conflits = _depot.enConflit.length;
          final synthese = calculerSynthese(
              DepotOperations.instance.lignes(_depot.actifs));
          final seuil = DepotParametres.instance.seuilMontant;
          final cartes = <_CarteStat>[
                  _CarteStat(
                    titre: 'Total dû',
                    valeur: formaterMontant(synthese.totalDu),
                    detail: 'Voir les comptes avec dette',
                    onTap: () => _liste(FiltreListe.avecDette),
                  ),
                  _CarteStat(
                    titre: 'Comptes avec dette',
                    valeur: '${synthese.nbAvecDette}',
                    detail: 'Voir la liste',
                    onTap: () => _liste(FiltreListe.avecDette),
                  ),
                  _CarteStat(
                    titre: 'Hors tolérance',
                    valeur: '${synthese.nbHorsTolerance}',
                    detail: formaterMontant(synthese.montantHorsTolerance),
                    alerte: synthese.nbHorsTolerance > 0,
                    onTap: () => _liste(FiltreListe.horsTolerance),
                  ),
                  _CarteStat(
                    titre: 'Montants élevés',
                    valeur: '${synthese.nbMontantsEleves}',
                    detail: 'Dû > ${formaterMontant(seuil)}',
                    onTap: () => _liste(FiltreListe.montantsEleves),
                  ),
                  _CarteStat(
                    titre: 'Comptes bloqués',
                    valeur: '${synthese.nbBloques}',
                    detail: 'Voir la liste',
                    onTap: () => _liste(FiltreListe.bloques),
                  ),
                  const _CarteStat(
                      titre: 'SMS en attente',
                      valeur: '—',
                      detail: 'Étape 6'),
          ];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Bonjour ${profil.nom}',
                  style: theme.textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                  '${profil.estAdmin ? 'Administrateur' : 'Compte secondaire'}'
                  '  •  ${_depot.nombreActifs} / $rangMax comptes'),
              if (profil.estAdmin && conflits > 0) ...[
                const SizedBox(height: 12),
                Card(
                  color: theme.colorScheme.errorContainer,
                  child: ListTile(
                    leading: const Icon(Icons.warning_amber),
                    title: Text(conflits == 1
                        ? '1 compte en conflit de numéro'
                        : '$conflits comptes en conflit de numéro'),
                    subtitle: const Text('Appuyez pour les régler.'),
                    onTap: () => _aller(EcranConflits(profil: profil)),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: Text('Tableau de bord',
                        style: theme.textTheme.titleMedium),
                  ),
                  TextButton.icon(
                    onPressed: () =>
                        setState(() => _tableauDeplie = !_tableauDeplie),
                    icon: Icon(_tableauDeplie
                        ? Icons.unfold_less
                        : Icons.unfold_more),
                    label: Text(_tableauDeplie ? 'Réduire' : 'Déplier'),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              if (_tableauDeplie)
                GridView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    mainAxisExtent: 104,
                  ),
                  children: cartes,
                )
              else
                SizedBox(
                  height: 56,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final c in cartes)
                        if (c.compact != null) c.compact!(context),
                    ],
                  ),
                ),
              const SizedBox(height: 20),
              Text('Commandes', style: theme.textTheme.titleMedium),
              const SizedBox(height: 8),
              GridView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  mainAxisExtent: 84,
                ),
                children: [
                  _BoutonAccueil(
                    icone: Icons.tag,
                    titre: 'Recherche par rang',
                    onTap: () => _aller(EcranRecherche(
                        profil: profil, mode: ModeRecherche.rang)),
                  ),
                  _BoutonAccueil(
                    icone: Icons.person_search,
                    titre: 'Recherche par nom',
                    onTap: () => _aller(EcranRecherche(
                        profil: profil, mode: ModeRecherche.nom)),
                  ),
                  _BoutonAccueil(
                    icone: Icons.phone,
                    titre: 'Recherche par téléphone',
                    onTap: () => _aller(EcranRecherche(
                        profil: profil, mode: ModeRecherche.telephone)),
                  ),
                  _BoutonAccueil(
                    icone: Icons.groups,
                    titre: 'Liste des clients',
                    onTap: () => _aller(EcranTousClients(profil: profil)),
                  ),
                  _BoutonAccueil(
                    icone: Icons.person_add,
                    titre: 'Nouveau client',
                    onTap: () =>
                        _aller(EcranClientFormulaire(profil: profil)),
                  ),
                  _BoutonAccueil(
                      icone: Icons.schedule,
                      titre: 'Clients en retard',
                      onTap: () => _liste(FiltreListe.horsTolerance)),
                  _BoutonAccueil(
                      icone: Icons.payments,
                      titre: 'Montants élevés',
                      onTap: () => _liste(FiltreListe.montantsEleves)),
                ],
              ),
            ],
          );
        },
      ),
    );
  }
}

class _CarteStat extends StatelessWidget {
  final String titre;
  final String valeur;
  final String detail;
  final bool alerte;
  final VoidCallback? onTap;
  const _CarteStat({
    required this.titre,
    required this.valeur,
    this.detail = '',
    this.alerte = false,
    this.onTap,
  });

  /// Version en ruban : une petite pastille « titre : valeur ».
  Widget Function(BuildContext)? get compact => (BuildContext context) {
        final theme = Theme.of(context);
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: Card(
            margin: EdgeInsets.zero,
            clipBehavior: Clip.antiAlias,
            color: alerte ? theme.colorScheme.errorContainer : null,
            child: InkWell(
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(titre, style: theme.textTheme.labelSmall),
                    Text(valeur,
                        style: theme.textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
          ),
        );
      };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      color: alerte ? theme.colorScheme.errorContainer : null,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(titre, style: theme.textTheme.labelLarge),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(valeur,
                    style: theme.textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.bold)),
              ),
              if (detail.isNotEmpty)
                Text(detail,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _BoutonAccueil extends StatelessWidget {
  final IconData icone;
  final String titre;
  final VoidCallback onTap;
  const _BoutonAccueil(
      {required this.icone, required this.titre, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icone, size: 28, color: theme.colorScheme.primary),
              const SizedBox(height: 6),
              Text(titre,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.labelLarge),
            ],
          ),
        ),
      ),
    );
  }
}
