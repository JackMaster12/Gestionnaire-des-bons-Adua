import 'package:flutter/material.dart';

import '../donnees/plateforme.dart';
import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/rangs.dart';
import '../services/appareil_service.dart';
import '../services/auth_service.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import '../services/depot_parametres.dart';
import '../services/service_sms.dart';
import '../theme.dart';
import '../widgets/logo.dart';
import 'client_formulaire.dart';
import 'comptes.dart';
import 'conflits.dart';
import 'file_sms.dart';
import 'liste_clients.dart';
import 'parametres.dart';
import 'recherche.dart';
import 'tous_clients.dart';

class EcranAccueil extends StatefulWidget {
  final ProfilUtilisateur profil;
  const EcranAccueil({super.key, required this.profil});

  @override
  State<EcranAccueil> createState() => _EtatAccueil();
}

class _EtatAccueil extends State<EcranAccueil> {
  final DepotClients _depot = DepotClients.instance;
  bool _tableauDeplie = false;

  @override
  void initState() {
    super.initState();
    ServiceAppareil.enregistrer();
    DepotParametres.instance.demarrer();
    _depot.demarrer();
    DepotOperations.instance.demarrer();
    ServiceSms.instance.demarrer();
  }

  @override
  void dispose() {
    ServiceSms.instance.arreter();
    _depot.arreter();
    DepotOperations.instance.arreter();
    DepotParametres.instance.arreter();
    super.dispose();
  }

  void _aller(Widget ecran) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ecran));
  }

  void _liste(FiltreListe filtre) {
    _aller(EcranListeClients(profil: widget.profil, filtre: filtre));
  }

  void _menu(String valeur) {
    switch (valeur) {
      case 'parametres':
        _aller(EcranParametres(profil: widget.profil));
        break;
      case 'file_sms':
        _aller(EcranFileSms(profil: widget.profil));
        break;
      case 'comptes':
        _aller(EcranComptes(profil: widget.profil));
        break;
      case 'conflits':
        _aller(EcranConflits(profil: widget.profil));
        break;
      case 'deconnexion':
        ServiceAuth.seDeconnecter();
        break;
    }
  }

  Widget _entete(BuildContext context, ProfilUtilisateur profil) {
    final theme = Theme.of(context);
    Widget pastille(String texte, IconData icone) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.18),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icone, size: 15, color: Colors.white),
              const SizedBox(width: 5),
              Text(texte,
                  style: const TextStyle(color: Colors.white, fontSize: 12.5)),
            ],
          ),
        );
    return Container(
      padding: EdgeInsets.fromLTRB(
          16, MediaQuery.of(context).padding.top + 12, 8, 22),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [CouleursAdua.vertFonce, CouleursAdua.vert, CouleursAdua.bleu],
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const LogoAdua(taille: 44),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Dépôt pharmaceutique ADUA',
                        style: theme.textTheme.labelMedium
                            ?.copyWith(color: Colors.white70)),
                    Text('Bons ADUA',
                        style: theme.textTheme.titleLarge?.copyWith(
                            color: Colors.white, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              boutonSync(context, couleur: Colors.white),
              PopupMenuButton<String>(
                iconColor: Colors.white,
                onSelected: _menu,
                itemBuilder: (_) => [
                  const PopupMenuItem(
                      value: 'parametres', child: Text('Paramètres')),
                  const PopupMenuItem(
                      value: 'file_sms', child: Text('File des SMS')),
                  if (profil.estAdmin)
                    const PopupMenuItem(
                        value: 'comptes', child: Text('Comptes utilisateurs')),
                  if (profil.estAdmin)
                    const PopupMenuItem(
                        value: 'conflits', child: Text('Conflits de numéro')),
                  const PopupMenuItem(
                      value: 'deconnexion', child: Text('Se déconnecter')),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Text('Bonjour ${profil.nom}',
                style: theme.textTheme.headlineSmall?.copyWith(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              pastille(
                  profil.estAdmin ? 'Administrateur' : 'Compte secondaire',
                  profil.estAdmin ? Icons.verified_user : Icons.person),
              pastille('${_depot.nombreActifs} / $rangMax comptes', Icons.groups),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final profil = widget.profil;
    return Scaffold(
      body: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[
          _depot,
          DepotOperations.instance,
          DepotParametres.instance,
        ]),
        builder: (context, _) {
          final conflits = _depot.enConflit.length;
          final synthese =
              calculerSynthese(DepotOperations.instance.lignes(_depot.actifs));
          final seuil = DepotParametres.instance.seuilMontant;
          final attente = DepotOperations.instance.nombreSmsEnAttente;
          final cartes = <_CarteStat>[
            _CarteStat(
              titre: 'Total dû',
              valeur: formaterMontant(synthese.totalDu),
              detail: '${synthese.nbAvecDette} compte${synthese.nbAvecDette > 1 ? 's' : ''} avec dette',
              icone: Icons.account_balance_wallet,
              couleur: CouleursAdua.bleu,
              onTap: () => _liste(FiltreListe.avecDette),
            ),
            _CarteStat(
              titre: 'Hors tolérance',
              valeur: '${synthese.nbHorsTolerance}',
              detail: formaterMontant(synthese.montantHorsTolerance),
              icone: Icons.schedule,
              couleur: CouleursAdua.rouge,
              alerte: synthese.nbHorsTolerance > 0,
              onTap: () => _liste(FiltreListe.horsTolerance),
            ),
            _CarteStat(
              titre: 'Montants élevés',
              valeur: '${synthese.nbMontantsEleves}',
              detail: 'Dû > ${formaterMontant(seuil)}',
              icone: Icons.trending_up,
              couleur: CouleursAdua.ambre,
              onTap: () => _liste(FiltreListe.montantsEleves),
            ),
            _CarteStat(
              titre: 'Comptes bloqués',
              valeur: '${synthese.nbBloques}',
              detail: 'Voir la liste',
              icone: Icons.block,
              couleur: CouleursAdua.gris,
              onTap: () => _liste(FiltreListe.bloques),
            ),
            _CarteStat(
              titre: 'SMS en attente',
              valeur: '$attente',
              detail: 'Voir la file',
              icone: Icons.sms,
              couleur: CouleursAdua.vert,
              onTap: () => _aller(EcranFileSms(profil: profil)),
            ),
          ];
          return ListView(
            padding: EdgeInsets.zero,
            children: [
              _entete(context, profil),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (profil.estAdmin && conflits > 0) ...[
                      Card(
                        color: theme.colorScheme.errorContainer,
                        child: ListTile(
                          leading: const Icon(Icons.warning_amber),
                          title: Text(conflits == 1
                              ? '1 compte en conflit de numéro'
                              : '$conflits comptes en conflit de numéro'),
                          subtitle: const Text('Appuyez pour les régler.'),
                          onTap: () => _aller(EcranConflits(profil: profil)),
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                    Row(
                      children: [
                        Expanded(
                          child: Text('Tableau de bord',
                              style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: CouleursAdua.texte)),
                        ),
                        TextButton.icon(
                          onPressed: () =>
                              setState(() => _tableauDeplie = !_tableauDeplie),
                          icon: Icon(_tableauDeplie
                              ? Icons.unfold_less
                              : Icons.unfold_more),
                          label: Text(_tableauDeplie ? 'Réduire' : 'Déplier'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    if (_tableauDeplie)
                      GridView(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate:
                            const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 300,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          mainAxisExtent: 118,
                        ),
                        children: cartes,
                      )
                    else
                      SizedBox(
                        height: 62,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [for (final c in cartes) c.pastille(context)],
                        ),
                      ),
                    const SizedBox(height: 24),
                    Text('Commandes',
                        style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: CouleursAdua.texte)),
                    const SizedBox(height: 10),
                    GridView(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 230,
                        mainAxisSpacing: 12,
                        crossAxisSpacing: 12,
                        mainAxisExtent: 104,
                      ),
                      children: [
                        _Tuile(
                          icone: Icons.tag,
                          titre: 'Recherche par rang',
                          onTap: () => _aller(EcranRecherche(
                              profil: profil, mode: ModeRecherche.rang)),
                        ),
                        _Tuile(
                          icone: Icons.person_search,
                          titre: 'Recherche par nom',
                          onTap: () => _aller(EcranRecherche(
                              profil: profil, mode: ModeRecherche.nom)),
                        ),
                        _Tuile(
                          icone: Icons.phone,
                          titre: 'Recherche par téléphone',
                          onTap: () => _aller(EcranRecherche(
                              profil: profil, mode: ModeRecherche.telephone)),
                        ),
                        _Tuile(
                          icone: Icons.groups,
                          titre: 'Liste des clients',
                          onTap: () => _aller(EcranTousClients(profil: profil)),
                        ),
                        _Tuile(
                          icone: Icons.person_add,
                          titre: 'Nouveau client',
                          onTap: () =>
                              _aller(EcranClientFormulaire(profil: profil)),
                        ),
                        _Tuile(
                          icone: Icons.schedule,
                          titre: 'Clients en retard',
                          onTap: () => _liste(FiltreListe.horsTolerance),
                        ),
                        _Tuile(
                          icone: Icons.payments,
                          titre: 'Montants élevés',
                          onTap: () => _liste(FiltreListe.montantsEleves),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Carte d'indicateur du tableau de bord (et sa version « pastille » du ruban).
class _CarteStat extends StatelessWidget {
  final String titre;
  final String valeur;
  final String detail;
  final IconData icone;
  final Color couleur;
  final bool alerte;
  final VoidCallback? onTap;
  const _CarteStat({
    required this.titre,
    required this.valeur,
    required this.detail,
    required this.icone,
    required this.couleur,
    this.alerte = false,
    this.onTap,
  });

  Widget _rond(double taille) => Container(
        width: taille,
        height: taille,
        decoration: BoxDecoration(
          color: CouleursAdua.teinte(couleur, 0.16),
          shape: BoxShape.circle,
        ),
        child: Icon(icone, size: taille * 0.55, color: couleur),
      );

  BoxDecoration _decor() => BoxDecoration(
        color: alerte ? CouleursAdua.teinte(couleur, 0.07) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: alerte ? couleur : Colors.grey.shade300,
          width: alerte ? 1.6 : 1,
        ),
      );

  /// Version du ruban : petite pastille cliquable.
  Widget pastille(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: Ink(
        decoration: _decor(),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _rond(32),
                const SizedBox(width: 10),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(titre,
                        style: theme.textTheme.labelSmall
                            ?.copyWith(color: CouleursAdua.gris)),
                    Text(valeur,
                        style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold, color: couleur)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Ink(
      decoration: _decor(),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              _rond(44),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(titre,
                        style: theme.textTheme.labelLarge
                            ?.copyWith(color: CouleursAdua.gris)),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(valeur,
                          style: theme.textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.bold, color: couleur)),
                    ),
                    Text(detail,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: CouleursAdua.gris)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Bouton de commande : icône dans un rond coloré, titre dessous.
class _Tuile extends StatelessWidget {
  final IconData icone;
  final String titre;
  final VoidCallback onTap;
  const _Tuile({required this.icone, required this.titre, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Ink(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: const BoxDecoration(
                  color: Color(0xFFE2F1EC),
                  shape: BoxShape.circle,
                ),
                child: Icon(icone, color: CouleursAdua.vert),
              ),
              const SizedBox(height: 8),
              Text(titre,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.labelLarge
                      ?.copyWith(color: CouleursAdua.texte)),
            ],
          ),
        ),
      ),
    );
  }
}
