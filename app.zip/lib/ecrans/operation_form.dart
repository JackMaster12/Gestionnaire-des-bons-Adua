import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/client.dart';
import '../noyau/operation.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import 'dialogues.dart';

/// Saisie d'un bon, d'un versement ou d'un appel.
/// Retourne true (via Navigator.pop) si l'opération a été enregistrée.
class EcranOperation extends StatefulWidget {
  final ProfilUtilisateur profil;
  final Client client;
  final TypeOperation type;
  const EcranOperation({
    super.key,
    required this.profil,
    required this.client,
    required this.type,
  });

  @override
  State<EcranOperation> createState() => _EtatOperation();
}

class _EtatOperation extends State<EcranOperation> {
  final _cle = GlobalKey<FormState>();
  final _montant = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();
  bool _enCours = false;

  bool get _avecMontant => widget.type != TypeOperation.appel;

  String get _titre {
    switch (widget.type) {
      case TypeOperation.bon:
        return 'Nouveau bon';
      case TypeOperation.versement:
        return 'Nouveau versement';
      case TypeOperation.appel:
        return 'Ajouter un appel';
      case TypeOperation.message:
        return 'Message';
    }
  }

  @override
  void dispose() {
    _montant.dispose();
    _note.dispose();
    super.dispose();
  }

  int get _valeur => int.tryParse(_montant.text.trim()) ?? 0;

  Future<void> _choisirDate() async {
    final maintenant = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(maintenant.year - 3),
      lastDate: maintenant,
      helpText: "Date de l'opération",
    );
    if (d != null) setState(() => _date = d);
  }

  Future<void> _enregistrer() async {
    if (!(_cle.currentState?.validate() ?? false)) return;
    final client = DepotClients.instance.parCle(widget.client.cle) ?? widget.client;
    final depot = DepotOperations.instance;
    final du = depot.situationDe(client.cle).du;
    final m = _avecMontant ? _valeur : 0;

    if (widget.type == TypeOperation.bon && client.bloque) {
      await alerte(context,
          '${client.nom} est bloqué : aucun nouveau bon n\'est possible.');
      return;
    }
    if (!mounted) return;

    String resume;
    if (widget.type == TypeOperation.bon) {
      resume = 'Bon de ${formaterMontant(m)}.\n'
          'Montant avant : ${formaterMontant(du)}\n'
          'Montant après : ${formaterMontant(du + m)}';
    } else if (widget.type == TypeOperation.versement) {
      resume = 'Versement de ${formaterMontant(m)}.\n'
          'Montant avant : ${formaterMontant(du)}\n'
          'Reste à payer : ${formaterMontant(du - m)}';
      if (m > du) {
        resume += '\n\n⚠️ Le versement dépasse le montant dû.';
      }
    } else {
      resume = 'Enregistrer cet appel dans l\'historique de ${client.nom} ?';
    }
    final ok = await confirmer(context,
        titre: 'Confirmer : ${libelleType(widget.type).toLowerCase()}',
        message: resume,
        bouton: 'Enregistrer');
    if (!ok || !mounted) return;

    setState(() => _enCours = true);
    final maintenant = DateTime.now();
    final aujourdhui = DateTime(maintenant.year, maintenant.month, maintenant.day);
    final jourChoisi = DateTime(_date.year, _date.month, _date.day);
    // Même jour qu'aujourd'hui : on garde l'heure réelle pour l'ordre des opérations.
    final dateOperation = jourChoisi == aujourdhui
        ? maintenant
        : DateTime(_date.year, _date.month, _date.day, 12);
    final enregistree = await depot.ajouter(
      client: client,
      type: widget.type,
      montant: m,
      note: _note.text,
      date: dateOperation,
      parNom: widget.profil.nom,
    );
    if (!mounted) return;
    Navigator.of(context).pop(enregistree);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(_titre)),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: DepotOperations.instance,
          builder: (context, _) {
            final du = DepotOperations.instance.situationDe(widget.client.cle).du;
            final apres = widget.type == TypeOperation.bon
                ? du + _valeur
                : du - _valeur;
            return Form(
              key: _cle,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.client.nom,
                              style: theme.textTheme.titleLarge
                                  ?.copyWith(fontWeight: FontWeight.bold)),
                          Text('Rang ${widget.client.rang}'),
                          const SizedBox(height: 6),
                          Text('Montant dû actuel : ${formaterMontant(du)}',
                              style: theme.textTheme.titleMedium),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (_avecMontant) ...[
                    TextFormField(
                      controller: _montant,
                      autofocus: true,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      style: const TextStyle(
                          fontSize: 34, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(
                        labelText: 'Montant (F)',
                        helperText: _valeur > 0
                            ? '${formaterMontant(_valeur)}  →  nouveau montant dû : ${formaterMontant(apres)}'
                            : null,
                      ),
                      onChanged: (_) => setState(() {}),
                      validator: (v) {
                        final n = int.tryParse((v ?? '').trim());
                        if (n == null || n <= 0) return 'Saisissez un montant';
                        if (n > 100000000) return 'Montant trop grand';
                        return null;
                      },
                    ),
                    const SizedBox(height: 14),
                  ],
                  InkWell(
                    onTap: _choisirDate,
                    child: InputDecorator(
                      decoration: const InputDecoration(
                          labelText: "Date de l'opération",
                          suffixIcon: Icon(Icons.calendar_today)),
                      child: Text(formaterDate(_date),
                          style: theme.textTheme.titleMedium),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _note,
                    maxLines: 3,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: InputDecoration(
                      labelText: widget.type == TypeOperation.appel
                          ? "Note de l'appel (ex. : a promis de payer vendredi)"
                          : 'Note (facultatif)',
                    ),
                  ),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: _enCours ? null : _enregistrer,
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('Enregistrer'),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
