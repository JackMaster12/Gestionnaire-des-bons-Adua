import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../modeles/profil.dart';
import '../noyau/client.dart';
import '../noyau/rangs.dart';
import '../services/depot_clients.dart';

/// Administrateur : comptes dont le numéro d'ordre est déjà pris par un
/// compte plus ancien.
class EcranConflits extends StatelessWidget {
  final ProfilUtilisateur profil;
  const EcranConflits({super.key, required this.profil});

  Future<void> _changer(BuildContext context, Client c) async {
    final depot = DepotClients.instance;
    final propose = premierRangLibre(depot.actifs.map((x) => x.rang));
    final nouveau = await showDialog<int>(
      context: context,
      builder: (_) => _DialogueRang(client: c, propose: propose),
    );
    if (nouveau != null) depot.changerRang(c, nouveau);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Conflits de numéro')),
      body: !profil.estAdmin
          ? const Center(child: Text("Réservé à l'administrateur."))
          : ListenableBuilder(
              listenable: DepotClients.instance,
              builder: (context, _) {
                final depot = DepotClients.instance;
                final liste = depot.enConflit;
                if (liste.isEmpty) {
                  return const Center(child: Text('Aucun conflit.'));
                }
                return ListView.separated(
                  itemCount: liste.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, i) {
                    final c = liste[i];
                    final gagnants = depot
                        .parRang(c.rang)
                        .where((x) => !x.enConflit)
                        .toList();
                    final avec =
                        gagnants.isEmpty ? '' : gagnants.first.nom;
                    return ListTile(
                      isThreeLine: true,
                      title: Text('${c.nom}  (rang ${c.rang})'),
                      subtitle: Text(
                          'Numéro déjà gardé par : $avec\nCréé hors ligne ou en même temps sur un autre appareil.'),
                      trailing: FilledButton(
                        onPressed: () => _changer(context, c),
                        child: const Text('Changer'),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

class _DialogueRang extends StatefulWidget {
  final Client client;
  final int? propose;
  const _DialogueRang({required this.client, required this.propose});

  @override
  State<_DialogueRang> createState() => _EtatDialogueRang();
}

class _EtatDialogueRang extends State<_DialogueRang> {
  late final TextEditingController _champ;
  String? _erreur;

  @override
  void initState() {
    super.initState();
    _champ = TextEditingController(text: widget.propose?.toString() ?? '');
  }

  @override
  void dispose() {
    _champ.dispose();
    super.dispose();
  }

  void _valider() {
    final n = int.tryParse(_champ.text.trim());
    if (n == null || n < 1 || n > rangMax) {
      setState(() => _erreur = 'Saisissez un nombre de 1 à $rangMax');
      return;
    }
    final pris = DepotClients.instance
        .parRang(n)
        .where((x) => x.cle != widget.client.cle)
        .toList();
    if (pris.isNotEmpty) {
      setState(() => _erreur = 'Ce numéro est déjà attribué à ${pris.first.nom}');
      return;
    }
    Navigator.of(context).pop(n);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Nouveau numéro pour ${widget.client.nom}'),
      content: TextField(
        controller: _champ,
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        autofocus: true,
        style: const TextStyle(fontSize: 28),
        decoration: InputDecoration(
          labelText: "Numéro d'ordre",
          errorText: _erreur,
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Annuler'),
        ),
        FilledButton(onPressed: _valider, child: const Text('Valider')),
      ],
    );
  }
}
