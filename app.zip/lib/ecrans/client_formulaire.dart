import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../modeles/profil.dart';
import '../noyau/client.dart';
import '../noyau/rangs.dart';
import '../services/depot_clients.dart';
import 'client_fiche.dart';

/// Formulaire unique : création (client == null) ou modification.
class EcranClientFormulaire extends StatefulWidget {
  final ProfilUtilisateur profil;
  final Client? client;
  const EcranClientFormulaire({super.key, required this.profil, this.client});

  @override
  State<EcranClientFormulaire> createState() => _EtatFormulaire();
}

class _EtatFormulaire extends State<EcranClientFormulaire> {
  final _cle = GlobalKey<FormState>();
  final _nom = TextEditingController();
  final _tel1 = TextEditingController();
  final _tel2 = TextEditingController();
  final _infos = TextEditingController();
  final _rang = TextEditingController();
  bool _afficherTel2 = false;
  bool _special = false;
  bool _enCours = false;

  bool get _creation => widget.client == null;

  @override
  void initState() {
    super.initState();
    final c = widget.client;
    if (c != null) {
      _nom.text = c.nom;
      _tel1.text = c.telephone1;
      _tel2.text = c.telephone2;
      _infos.text = c.autresInfos;
      _afficherTel2 = c.telephone2.isNotEmpty;
    }
  }

  @override
  void dispose() {
    _nom.dispose();
    _tel1.dispose();
    _tel2.dispose();
    _infos.dispose();
    _rang.dispose();
    super.dispose();
  }

  Future<void> _alerte(String message) {
    return showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('⚠️ Attention'),
        content: Text(message),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _enregistrer() async {
    if (!_cle.currentState!.validate()) return;
    final depot = DepotClients.instance;
    final existant = widget.client;
    final tel2 = _afficherTel2 ? _tel2.text : '';

    if (existant != null) {
      depot.modifier(existant,
          nom: _nom.text,
          telephone1: _tel1.text,
          telephone2: tel2,
          autresInfos: _infos.text);
      Navigator.of(context).pop();
      return;
    }

    final int rangChoisi;
    if (_special) {
      final saisi = int.parse(_rang.text.trim());
      final pris = depot.parRang(saisi);
      if (pris.isNotEmpty) {
        await _alerte(
            'Le numéro $saisi est déjà attribué à ${pris.first.nom}.\nChoisissez un autre numéro.');
        return;
      }
      rangChoisi = saisi;
    } else {
      final libre = premierRangLibre(depot.actifs.map((c) => c.rang));
      if (libre == null) {
        await _alerte(
            'Les $rangMax numéros sont utilisés. Impossible de créer un nouveau compte.');
        return;
      }
      rangChoisi = libre;
    }

    setState(() => _enCours = true);
    final client = await depot.creer(
      nom: _nom.text,
      telephone1: _tel1.text,
      telephone2: tel2,
      autresInfos: _infos.text,
      rang: rangChoisi,
      special: _special,
    );
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
        builder: (_) => EcranClient(profil: widget.profil, cle: client.cle)));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
          title: Text(_creation ? 'Nouveau client' : 'Modifier le compte')),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: DepotClients.instance,
          builder: (context, _) {
            final depot = DepotClients.instance;
            if (_creation && !depot.pret) {
              return const Center(child: CircularProgressIndicator());
            }
            final libre = premierRangLibre(depot.actifs.map((c) => c.rang));
            return Form(
              key: _cle,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  TextFormField(
                    controller: _nom,
                    textCapitalization: TextCapitalization.words,
                    decoration:
                        const InputDecoration(labelText: 'Nom du client'),
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Saisissez le nom'
                        : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _tel1,
                    keyboardType: TextInputType.phone,
                    decoration:
                        const InputDecoration(labelText: 'Téléphone (SMS)'),
                  ),
                  const SizedBox(height: 8),
                  if (_afficherTel2) ...[
                    TextFormField(
                      controller: _tel2,
                      keyboardType: TextInputType.phone,
                      decoration:
                          const InputDecoration(labelText: 'Deuxième numéro'),
                    ),
                  ] else
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () => setState(() => _afficherTel2 = true),
                        icon: const Icon(Icons.add),
                        label: const Text('Ajouter un deuxième numéro'),
                      ),
                    ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _infos,
                    maxLines: 3,
                    decoration:
                        const InputDecoration(labelText: 'Autres infos'),
                  ),
                  if (_creation) ...[
                    const Divider(height: 36),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text("Numéro d'ordre spécial"),
                      subtitle: const Text(
                          'Cochez pour choisir vous-même le numéro.'),
                      value: _special,
                      onChanged: (v) => setState(() => _special = v),
                    ),
                    if (_special)
                      TextFormField(
                        controller: _rang,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        decoration: InputDecoration(
                            labelText: "Numéro d'ordre (1 à $rangMax)"),
                        validator: (v) {
                          final n = int.tryParse((v ?? '').trim());
                          if (n == null || n < 1 || n > rangMax) {
                            return 'Saisissez un nombre de 1 à $rangMax';
                          }
                          return null;
                        },
                      )
                    else
                      Card(
                        color: theme.colorScheme.secondaryContainer,
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Text(
                            libre == null
                                ? 'Plus aucun numéro libre.'
                                : "Numéro d'ordre attribué automatiquement : $libre",
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                      ),
                  ],
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: _enCours ? null : _enregistrer,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text(_creation ? 'Créer le compte' : 'Enregistrer'),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
