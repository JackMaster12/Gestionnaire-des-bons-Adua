import 'package:flutter/material.dart';

import '../modeles/profil.dart';
import '../noyau/calculs.dart';
import '../noyau/texte.dart';
import '../services/depot_clients.dart';
import '../services/depot_operations.dart';
import '../services/depot_parametres.dart';
import 'client_fiche.dart';

/// Liste de tous les clients (par rang), avec un filtre rapide.
class EcranTousClients extends StatefulWidget {
  final ProfilUtilisateur profil;
  const EcranTousClients({super.key, required this.profil});

  @override
  State<EcranTousClients> createState() => _EtatTousClients();
}

class _EtatTousClients extends State<EcranTousClients> {
  final _champ = TextEditingController();
  String _filtre = '';

  @override
  void dispose() {
    _champ.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Tous les clients')),
      body: ListenableBuilder(
        listenable: Listenable.merge(<Listenable>[
          DepotClients.instance,
          DepotOperations.instance,
          DepotParametres.instance,
        ]),
        builder: (context, _) {
          var lignes =
              DepotOperations.instance.lignes(DepotClients.instance.actifs);
          lignes.sort((a, b) => a.client.rang.compareTo(b.client.rang));
          final q = normaliser(_filtre);
          final qc = chiffres(_filtre);
          if (q.isNotEmpty) {
            lignes = lignes.where((l) {
              final c = l.client;
              return c.nomRecherche.contains(q) ||
                  '${c.rang}' == _filtre.trim() ||
                  (qc.length >= 3 &&
                      (chiffres(c.telephone1).contains(qc) ||
                          chiffres(c.telephone2).contains(qc)));
            }).toList();
          }
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: TextField(
                  controller: _champ,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: 'Filtrer : nom, rang ou téléphone',
                    suffixIcon: _filtre.isEmpty
                        ? null
                        : IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _champ.clear();
                              setState(() => _filtre = '');
                            },
                          ),
                  ),
                  onChanged: (v) => setState(() => _filtre = v),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                      '${lignes.length} client${lignes.length > 1 ? 's' : ''}'),
                ),
              ),
              Expanded(
                child: lignes.isEmpty
                    ? const Center(child: Text('Aucun client.'))
                    : ListView.separated(
                        itemCount: lignes.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final l = lignes[i];
                          final c = l.client;
                          final s = l.situation;
                          return ListTile(
                            leading: CircleAvatar(child: Text('${c.rang}')),
                            title: Text(c.nom,
                                style: const TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold)),
                            subtitle: Text([
                              if (c.telephone1.isNotEmpty) c.telephone1,
                              if (c.bloque) 'BLOQUÉ',
                              if (s.horsTolerance) 'HORS TOLÉRANCE',
                            ].join('  •  ')),
                            trailing: Text(
                              formaterMontant(s.du),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: s.horsTolerance
                                    ? theme.colorScheme.error
                                    : null,
                              ),
                            ),
                            onTap: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                    builder: (_) => EcranClient(
                                        profil: widget.profil, cle: c.cle))),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}
