import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

/// Aperçu d'un PDF avec partage, enregistrement et impression.
class EcranApercuPdf extends StatefulWidget {
  final String titre;
  final String nomFichier;

  /// Construit le PDF ; [complet] n'a de sens que si [avecChoix] est vrai.
  final Future<Uint8List> Function(bool complet) construire;
  final bool avecChoix;

  const EcranApercuPdf({
    super.key,
    required this.titre,
    required this.nomFichier,
    required this.construire,
    this.avecChoix = false,
  });

  @override
  State<EcranApercuPdf> createState() => _EtatApercu();
}

class _EtatApercu extends State<EcranApercuPdf> {
  bool _complet = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.titre)),
      body: Column(
        children: [
          if (widget.avecChoix)
            Padding(
              padding: const EdgeInsets.all(12),
              child: SegmentedButton<bool>(
                segments: const [
                  ButtonSegment<bool>(value: false, label: Text('Résumé')),
                  ButtonSegment<bool>(
                      value: true, label: Text('Historique complet')),
                ],
                selected: <bool>{_complet},
                onSelectionChanged: (s) => setState(() => _complet = s.first),
              ),
            ),
          Expanded(
            child: PdfPreview(
              key: ValueKey<bool>(_complet),
              build: (format) => widget.construire(_complet),
              pdfFileName: widget.nomFichier,
              canChangePageFormat: false,
              canChangeOrientation: false,
              canDebug: false,
            ),
          ),
        ],
      ),
    );
  }
}
