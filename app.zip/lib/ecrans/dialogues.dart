import 'package:flutter/material.dart';

/// Demande une confirmation. Retourne true si l'utilisateur confirme.
Future<bool> confirmer(
  BuildContext context, {
  required String titre,
  required String message,
  String bouton = 'Confirmer',
  bool danger = false,
}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(titre),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: const Text('Annuler'),
        ),
        FilledButton(
          style: danger
              ? FilledButton.styleFrom(
                  backgroundColor: Theme.of(ctx).colorScheme.error,
                  foregroundColor: Theme.of(ctx).colorScheme.onError,
                )
              : null,
          onPressed: () => Navigator.of(ctx).pop(true),
          child: Text(bouton),
        ),
      ],
    ),
  );
  return r == true;
}

/// Demande un motif. Retourne le texte saisi (peut être vide si le motif est
/// facultatif) ou null si l'utilisateur annule.
Future<String?> demanderMotif(
  BuildContext context, {
  required String titre,
  required String message,
  required bool obligatoire,
  String bouton = 'Valider',
  bool danger = false,
}) {
  return showDialog<String>(
    context: context,
    builder: (_) => _DialogueMotif(
      titre: titre,
      message: message,
      obligatoire: obligatoire,
      bouton: bouton,
      danger: danger,
    ),
  );
}

class _DialogueMotif extends StatefulWidget {
  final String titre;
  final String message;
  final bool obligatoire;
  final String bouton;
  final bool danger;
  const _DialogueMotif({
    required this.titre,
    required this.message,
    required this.obligatoire,
    required this.bouton,
    required this.danger,
  });

  @override
  State<_DialogueMotif> createState() => _EtatDialogueMotif();
}

class _EtatDialogueMotif extends State<_DialogueMotif> {
  final _champ = TextEditingController();
  String? _erreur;

  @override
  void dispose() {
    _champ.dispose();
    super.dispose();
  }

  void _valider() {
    final texte = _champ.text.trim();
    if (widget.obligatoire && texte.isEmpty) {
      setState(() => _erreur = 'Le motif est obligatoire');
      return;
    }
    Navigator.of(context).pop(texte);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AlertDialog(
      title: Text(widget.titre),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.message),
            const SizedBox(height: 12),
            TextField(
              controller: _champ,
              maxLines: 2,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                labelText:
                    widget.obligatoire ? 'Motif (obligatoire)' : 'Motif (facultatif)',
                errorText: _erreur,
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Annuler'),
        ),
        FilledButton(
          style: widget.danger
              ? FilledButton.styleFrom(
                  backgroundColor: theme.colorScheme.error,
                  foregroundColor: theme.colorScheme.onError,
                )
              : null,
          onPressed: _valider,
          child: Text(widget.bouton),
        ),
      ],
    );
  }
}

/// Petit message d'information en bas de l'écran.
void afficherInfo(BuildContext context, String texte) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texte)));
}

/// Fenêtre d'alerte simple (bouton OK).
Future<void> alerte(BuildContext context, String message) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('⚠️ Attention'),
      content: Text(message),
      actions: [
        FilledButton(
          onPressed: () => Navigator.of(ctx).pop(),
          child: const Text('OK'),
        ),
      ],
    ),
  );
}
