// Règles du numéro d'ordre (rang) : pur Dart, sans Flutter ni Firebase.

import 'client.dart';

/// Nombre maximum de comptes : les rangs vont de 1 à 1000.
const int rangMax = 1000;

/// Plus petit rang libre à partir de 1, ou null si les 1000 sont pris.
int? premierRangLibre(Iterable<int> pris) {
  final ensemble = pris.toSet();
  for (var r = 1; r <= rangMax; r++) {
    if (!ensemble.contains(r)) return r;
  }
  return null;
}

/// Compare deux clients par ancienneté (le plus ancien d'abord).
/// À égalité d'heure, la clé interne départage : le résultat est identique
/// sur tous les appareils.
int comparerAnciennete(Client a, Client b) {
  final c = a.creeLeCorrige.compareTo(b.creeLeCorrige);
  if (c != 0) return c;
  return a.cle.compareTo(b.cle);
}

/// Pour chaque client ACTIF, indique s'il doit être marqué « en conflit ».
/// Quand plusieurs clients actifs portent le même rang, le plus ancien garde
/// le numéro (faux) et les autres sont en conflit (vrai).
Map<String, bool> etatsConflit(Iterable<Client> clients) {
  final parRang = <int, List<Client>>{};
  for (final c in clients) {
    if (!c.actif) continue;
    parRang.putIfAbsent(c.rang, () => <Client>[]).add(c);
  }
  final resultat = <String, bool>{};
  parRang.forEach((rang, liste) {
    liste.sort(comparerAnciennete);
    for (var i = 0; i < liste.length; i++) {
      resultat[liste[i].cle] = i > 0;
    }
  });
  return resultat;
}
