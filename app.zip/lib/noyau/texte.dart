// Outils de texte purs : aucune dépendance à Flutter ni à Firebase.
// Ce fichier sera réutilisé tel quel par la version Windows.

const Map<String, String> _accents = <String, String>{
  'à': 'a', 'â': 'a', 'ä': 'a', 'á': 'a', 'ã': 'a', 'å': 'a',
  'ç': 'c',
  'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e',
  'î': 'i', 'ï': 'i', 'í': 'i', 'ì': 'i',
  'ñ': 'n',
  'ô': 'o', 'ö': 'o', 'ó': 'o', 'ò': 'o', 'õ': 'o',
  'ù': 'u', 'û': 'u', 'ü': 'u', 'ú': 'u',
  'ÿ': 'y', 'ý': 'y',
  'œ': 'oe', 'æ': 'ae',
};

/// Minuscules, sans accents, espaces multiples réduits : sert à la recherche.
String normaliser(String texte) {
  final bas = texte.toLowerCase();
  final sb = StringBuffer();
  for (final r in bas.runes) {
    final c = String.fromCharCode(r);
    sb.write(_accents[c] ?? c);
  }
  return sb.toString().trim().replaceAll(RegExp(r'\s+'), ' ');
}

/// Garde uniquement les chiffres (numéros de téléphone).
String chiffres(String texte) => texte.replaceAll(RegExp(r'[^0-9]'), '');
