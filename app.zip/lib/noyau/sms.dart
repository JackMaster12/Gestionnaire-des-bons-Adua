// Règles d'envoi des SMS : pur Dart, réutilisable sur Android et Windows.

import 'calculs.dart';
import 'client.dart';
import 'operation.dart';

/// Heures calmes (ex. 22h à 7h) : aucun SMS n'est envoyé.
bool dansHeuresCalmes(DateTime maintenant, int debut, int fin) {
  final h = maintenant.hour;
  if (debut == fin) return false;
  if (debut > fin) return h >= debut || h < fin;
  return h >= debut && h < fin;
}

enum DecisionSms { envoyer, attendre, expirer, ignorer }

DecisionSms decider(
  Operation op, {
  required DateTime maintenant,
  required int delaiMaxHeures,
  required int calmeDebut,
  required int calmeFin,
}) {
  if (op.smsEtat != 'en_attente' || !op.valide) return DecisionSms.ignorer;
  final age = maintenant.difference(op.saisieLe);
  if (!op.smsRepris && age.inHours >= delaiMaxHeures) {
    return DecisionSms.expirer;
  }
  // Un renvoi demandé à la main part tout de suite, même la nuit.
  if (!op.smsRepris && dansHeuresCalmes(maintenant, calmeDebut, calmeFin)) {
    return DecisionSms.attendre;
  }
  return DecisionSms.envoyer;
}

/// Reste à payer juste avant et juste après une opération.
class SoldesOperation {
  final int avant;
  final int apres;
  const SoldesOperation(this.avant, this.apres);
}

SoldesOperation soldesOperation(Operation op, Iterable<Operation> operationsClient) {
  var avant = 0;
  for (final o in operationsClient) {
    if (!o.valide || o.cle == op.cle) continue;
    if (comparerOperations(o, op) >= 0) continue;
    if (o.type == TypeOperation.bon) avant += o.montant;
    if (o.type == TypeOperation.versement) avant -= o.montant;
  }
  final apres = op.type == TypeOperation.bon
      ? avant + op.montant
      : op.type == TypeOperation.versement
          ? avant - op.montant
          : avant;
  return SoldesOperation(avant, apres);
}

/// Texte du SMS d'une opération. Les montants « avant » et « après » sont
/// recalculés à partir de l'ordre réel des opérations valides du compte.
String composerSms(
  Operation op,
  Iterable<Operation> operationsClient,
  Client client, {
  required String modeleBon,
  required String modeleVersement,
}) {
  if (op.type == TypeOperation.message) return op.note;
  final s = soldesOperation(op, operationsClient);
  final avant = s.avant;
  final apres = s.apres;
  final modele = op.type == TypeOperation.bon ? modeleBon : modeleVersement;
  return remplirModele(modele, <String, String>{
    'montant': formaterMontant(op.montant),
    'nom': client.nom,
    'rang': '${client.rang}',
    'total_avant': formaterMontant(avant),
    'total_apres': formaterMontant(apres),
  });
}

/// Un compte hors tolérance doit être relancé s'il n'a reçu aucun message
/// depuis [intervalleJours] jours (ou jamais).
bool relanceDue(Situation s, DateTime maintenant, int intervalleJours) {
  if (!s.horsTolerance) return false;
  final dernier = s.dernierMessage;
  if (dernier == null) return true;
  return joursEntre(dernier, maintenant) >= intervalleJours;
}

String _deux(int n) => n < 10 ? '0$n' : '$n';

/// Identifiant fixe d'une relance du jour : deux appareils ne peuvent pas
/// créer deux relances le même jour pour le même client.
String cleRelance(String clientCle, DateTime jour) =>
    'relance_${clientCle}_${jour.year}-${_deux(jour.month)}-${_deux(jour.day)}';

String texteRelance(String modele, Client client, Situation s) {
  return remplirModele(modele, <String, String>{
    'nom': client.nom,
    'rang': '${client.rang}',
    'total': formaterMontant(s.du),
    'retard': s.retardJours == null ? '' : libelleRetard(s.retardJours!),
  });
}

/// Numéro nettoyé pour l'envoi (chiffres et +).
String numeroPourSms(String saisie) => saisie.replaceAll(RegExp(r'[^0-9+]'), '');
