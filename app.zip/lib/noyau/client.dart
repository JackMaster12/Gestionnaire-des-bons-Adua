// Modèle d'un compte client : pur Dart, réutilisable sur Android et Windows.

import 'texte.dart';

class Client {
  /// Clé interne (UUID), invisible pour l'utilisateur.
  final String cle;

  /// Numéro d'ordre (1 à 1000) : identifiant unique visible du client.
  final int rang;
  final bool rangSpecial;
  final String nom;
  final String telephone1;
  final String telephone2;
  final String autresInfos;
  final bool bloque;
  final bool enConflit;
  final bool actif;

  /// Heure de saisie sur l'appareil.
  final DateTime creeLe;

  /// Écart (en millisecondes) à AJOUTER à l'heure de l'appareil pour obtenir
  /// l'heure du serveur. 0 tant que la mesure n'est pas faite.
  final int decalageHorlogeMs;

  const Client({
    required this.cle,
    required this.rang,
    this.rangSpecial = false,
    required this.nom,
    this.telephone1 = '',
    this.telephone2 = '',
    this.autresInfos = '',
    this.bloque = false,
    this.enConflit = false,
    this.actif = true,
    required this.creeLe,
    this.decalageHorlogeMs = 0,
  });

  String get nomRecherche => normaliser(nom);

  /// Heure de saisie corrigée de l'écart d'horloge : sert à départager
  /// deux clients qui portent le même rang.
  DateTime get creeLeCorrige =>
      creeLe.add(Duration(milliseconds: decalageHorlogeMs));
}
