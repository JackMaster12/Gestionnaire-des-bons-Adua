// Modèle d'une opération : pur Dart, réutilisable sur Android et Windows.

enum TypeOperation { bon, versement, appel, message }

TypeOperation? typeDepuisCode(String code) {
  for (final t in TypeOperation.values) {
    if (t.name == code) return t;
  }
  return null;
}

String libelleType(TypeOperation t) {
  switch (t) {
    case TypeOperation.bon:
      return 'Bon';
    case TypeOperation.versement:
      return 'Versement';
    case TypeOperation.appel:
      return 'Appel';
    case TypeOperation.message:
      return 'Message';
  }
}

const String etatValide = 'valide';
const String etatAnnule = 'annule';
const String etatEfface = 'efface';

class Operation {
  final String cle;
  final String clientCle;
  final int clientRang;
  final TypeOperation type;

  /// Montant en francs (0 pour un appel ou un message).
  final int montant;
  final String note;

  /// Date choisie par l'utilisateur (peut être antérieure à la saisie).
  final DateTime dateOperation;

  /// Heure réelle de saisie sur l'appareil.
  final DateTime saisieLe;

  /// valide, annule ou efface. Seul cet état (et les champs sms) change.
  final String etat;
  final String annuleMotif;
  final String parNom;
  final String smsEtat;

  const Operation({
    required this.cle,
    required this.clientCle,
    required this.clientRang,
    required this.type,
    required this.montant,
    this.note = '',
    required this.dateOperation,
    required this.saisieLe,
    this.etat = etatValide,
    this.annuleMotif = '',
    this.parNom = '',
    this.smsEtat = 'aucun',
  });

  bool get valide => etat == etatValide;

  Operation avecEtat(String nouvelEtat, {String motif = ''}) {
    return Operation(
      cle: cle,
      clientCle: clientCle,
      clientRang: clientRang,
      type: type,
      montant: montant,
      note: note,
      dateOperation: dateOperation,
      saisieLe: saisieLe,
      etat: nouvelEtat,
      annuleMotif: motif.isEmpty ? annuleMotif : motif,
      parNom: parNom,
      smsEtat: smsEtat,
    );
  }
}

/// Ordre d'une opération dans le compte : date, puis heure de saisie, puis clé.
int comparerOperations(Operation a, Operation b) {
  final d = a.dateOperation.compareTo(b.dateOperation);
  if (d != 0) return d;
  final s = a.saisieLe.compareTo(b.saisieLe);
  if (s != 0) return s;
  return a.cle.compareTo(b.cle);
}
