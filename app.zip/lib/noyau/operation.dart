// Modèle d'une opération : pur Dart, réutilisable sur Android et Windows.

enum TypeOperation { bon, versement, appel, message }

TypeOperation? typeDepuisCode(String code) {
  for (final t in TypeOperation.values) {
    if (t.name == code) return t;
  }
  return null;
}

String libelleType(TypeOperation t) {
  switch (t) {
    case TypeOperation.bon:
      return 'Bon';
    case TypeOperation.versement:
      return 'Versement';
    case TypeOperation.appel:
      return 'Appel';
    case TypeOperation.message:
      return 'Message';
  }
}

const String etatValide = 'valide';
const String etatAnnule = 'annule';
const String etatEfface = 'efface';

class Operation {
  final String cle;
  final String clientCle;
  final int clientRang;
  final TypeOperation type;

  /// Montant en francs (0 pour un appel ou un message).
  final int montant;
  final String note;

  /// Date choisie par l'utilisateur (peut être antérieure à la saisie).
  final DateTime dateOperation;

  /// Heure réelle de saisie sur l'appareil.
  final DateTime saisieLe;

  /// valide, annule ou efface. Seuls cet état et les champs sms changent.
  final String etat;
  final String annuleMotif;
  final String parNom;

  /// aucun, en_attente, en_cours, envoye, echec, expire.
  final String smsEtat;
  final String smsErreur;

  /// Texte réellement envoyé (rempli à l'envoi).
  final String smsTexte;

  /// Renvoi demandé à la main : l'expiration de 48 h ne s'applique plus.
  final bool smsRepris;

  const Operation({
    required this.cle,
    required this.clientCle,
    required this.clientRang,
    required this.type,
    required this.montant,
    this.note = '',
    required this.dateOperation,
    required this.saisieLe,
    this.etat = etatValide,
    this.annuleMotif = '',
    this.parNom = '',
    this.smsEtat = 'aucun',
    this.smsErreur = '',
    this.smsTexte = '',
    this.smsRepris = false,
  });

  bool get valide => etat == etatValide;

  Operation _copie({
    String? etat,
    String? annuleMotif,
    String? smsEtat,
    String? smsErreur,
    String? smsTexte,
    bool? smsRepris,
  }) {
    return Operation(
      cle: cle,
      clientCle: clientCle,
      clientRang: clientRang,
      type: type,
      montant: montant,
      note: note,
      dateOperation: dateOperation,
      saisieLe: saisieLe,
      etat: etat ?? this.etat,
      annuleMotif: annuleMotif ?? this.annuleMotif,
      parNom: parNom,
      smsEtat: smsEtat ?? this.smsEtat,
      smsErreur: smsErreur ?? this.smsErreur,
      smsTexte: smsTexte ?? this.smsTexte,
      smsRepris: smsRepris ?? this.smsRepris,
    );
  }

  Operation avecEtat(String nouvelEtat, {String motif = ''}) {
    return _copie(
        etat: nouvelEtat, annuleMotif: motif.isEmpty ? annuleMotif : motif);
  }

  Operation avecSms({
    String? etat,
    String? erreur,
    String? texte,
    bool? repris,
  }) {
    return _copie(
        smsEtat: etat, smsErreur: erreur, smsTexte: texte, smsRepris: repris);
  }
}

/// Ordre d'une opération dans le compte : date, puis heure de saisie, puis clé.
int comparerOperations(Operation a, Operation b) {
  final d = a.dateOperation.compareTo(b.dateOperation);
  if (d != 0) return d;
  final s = a.saisieLe.compareTo(b.saisieLe);
  if (s != 0) return s;
  return a.cle.compareTo(b.cle);
}
