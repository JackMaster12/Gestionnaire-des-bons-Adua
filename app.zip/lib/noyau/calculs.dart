// Calculs du compte client : pur Dart, réutilisable sur Android et Windows.
// Le montant dû est TOUJOURS recalculé : bons valides moins versements valides.

import 'client.dart';
import 'operation.dart';

/// Montant dû : bons valides moins versements valides.
int calculerSolde(Iterable<Operation> ops) {
  var s = 0;
  for (final o in ops) {
    if (!o.valide) continue;
    if (o.type == TypeOperation.bon) {
      s += o.montant;
    } else if (o.type == TypeOperation.versement) {
      s -= o.montant;
    }
  }
  return s;
}

DateTime _jour(DateTime d) => DateTime.utc(d.year, d.month, d.day);

/// Nombre de jours entre deux dates (heures ignorées).
int joursEntre(DateTime debut, DateTime fin) =>
    _jour(fin).difference(_jour(debut)).inDays;

class Situation {
  final int du;
  final DateTime? dernierBon;
  final DateTime? dernierVersement;
  final DateTime? dernierAppel;
  final DateTime? dernierMessage;

  /// Jours de retard (null s'il n'y a rien à payer).
  final int? retardJours;
  final bool horsTolerance;
  final bool montantEleve;

  const Situation({
    required this.du,
    this.dernierBon,
    this.dernierVersement,
    this.dernierAppel,
    this.dernierMessage,
    this.retardJours,
    this.horsTolerance = false,
    this.montantEleve = false,
  });
}

DateTime? _plusRecent(DateTime? a, DateTime b) =>
    (a == null || b.isAfter(a)) ? b : a;

/// Retard : depuis le dernier versement, sinon depuis le premier bon.
/// Aucun retard si le client ne doit rien.
Situation calculerSituation(
  Iterable<Operation> ops, {
  required DateTime maintenant,
  int tolerance = 90,
  int seuil = 10000,
}) {
  DateTime? dernierBon, dernierVersement, dernierAppel, dernierMessage;
  DateTime? premierBon;
  for (final o in ops) {
    if (!o.valide) continue;
    switch (o.type) {
      case TypeOperation.bon:
        dernierBon = _plusRecent(dernierBon, o.dateOperation);
        if (premierBon == null || o.dateOperation.isBefore(premierBon)) {
          premierBon = o.dateOperation;
        }
        break;
      case TypeOperation.versement:
        dernierVersement = _plusRecent(dernierVersement, o.dateOperation);
        break;
      case TypeOperation.appel:
        dernierAppel = _plusRecent(dernierAppel, o.dateOperation);
        break;
      case TypeOperation.message:
        dernierMessage = _plusRecent(dernierMessage, o.dateOperation);
        break;
    }
  }
  final du = calculerSolde(ops);
  int? retard;
  if (du > 0) {
    final reference = dernierVersement ?? premierBon;
    if (reference != null) {
      final r = joursEntre(reference, maintenant);
      retard = r < 0 ? 0 : r;
    }
  }
  return Situation(
    du: du,
    dernierBon: dernierBon,
    dernierVersement: dernierVersement,
    dernierAppel: dernierAppel,
    dernierMessage: dernierMessage,
    retardJours: retard,
    horsTolerance: du > 0 && retard != null && retard > tolerance,
    montantEleve: du > seuil,
  );
}

// ---------- Listes et synthèse du tableau de bord ----------

enum FiltreListe { avecDette, horsTolerance, montantsEleves, bloques }

class LigneSuivi {
  final Client client;
  final Situation situation;
  const LigneSuivi(this.client, this.situation);
}

class Synthese {
  final int totalDu;
  final int nbAvecDette;
  final int nbHorsTolerance;
  final int montantHorsTolerance;
  final int nbMontantsEleves;
  final int nbBloques;
  const Synthese({
    required this.totalDu,
    required this.nbAvecDette,
    required this.nbHorsTolerance,
    required this.montantHorsTolerance,
    required this.nbMontantsEleves,
    required this.nbBloques,
  });
}

Synthese calculerSynthese(Iterable<LigneSuivi> lignes) {
  var total = 0, avecDette = 0, ht = 0, montantHt = 0, eleves = 0, bloques = 0;
  for (final l in lignes) {
    final du = l.situation.du;
    if (du > 0) {
      total += du;
      avecDette++;
    }
    if (l.situation.horsTolerance) {
      ht++;
      montantHt += du;
    }
    if (l.situation.montantEleve) eleves++;
    if (l.client.bloque) bloques++;
  }
  return Synthese(
    totalDu: total,
    nbAvecDette: avecDette,
    nbHorsTolerance: ht,
    montantHorsTolerance: montantHt,
    nbMontantsEleves: eleves,
    nbBloques: bloques,
  );
}

/// Clients correspondant au filtre : plus gros montant d'abord
/// (les comptes bloqués sont classés par rang).
List<LigneSuivi> filtrerLignes(Iterable<LigneSuivi> lignes, FiltreListe f) {
  bool garde(LigneSuivi l) {
    switch (f) {
      case FiltreListe.avecDette:
        return l.situation.du > 0;
      case FiltreListe.horsTolerance:
        return l.situation.horsTolerance;
      case FiltreListe.montantsEleves:
        return l.situation.montantEleve;
      case FiltreListe.bloques:
        return l.client.bloque;
    }
  }

  final liste = lignes.where(garde).toList();
  liste.sort((a, b) {
    if (f != FiltreListe.bloques) {
      final d = b.situation.du.compareTo(a.situation.du);
      if (d != 0) return d;
    }
    return a.client.rang.compareTo(b.client.rang);
  });
  return liste;
}

// ---------- Affichage ----------

/// 12500 -> "12 500 F"
String formaterMontant(int n) {
  final negatif = n < 0;
  final s = (negatif ? -n : n).toString();
  final sb = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) sb.write(' ');
    sb.write(s[i]);
  }
  return '${negatif ? '-' : ''}$sb F';
}

String _deux(int n) => n < 10 ? '0$n' : '$n';

String formaterDate(DateTime d) => '${_deux(d.day)}/${_deux(d.month)}/${d.year}';

String formaterDateHeure(DateTime d) =>
    '${formaterDate(d)} ${_deux(d.hour)}:${_deux(d.minute)}';

String libelleRetard(int jours) => jours <= 1 ? '$jours jour' : '$jours jours';

/// Remplace [nom], [rang], [total]… dans un modèle de SMS.
String remplirModele(String modele, Map<String, String> valeurs) {
  var texte = modele;
  valeurs.forEach((cle, valeur) {
    texte = texte.replaceAll('[$cle]', valeur);
  });
  return texte;
}
