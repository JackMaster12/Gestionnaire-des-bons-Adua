#!/usr/bin/env python3
"""Prépare le projet Flutter pour Windows (à lancer depuis la racine du projet) :
- remplace les paquets Firebase par la base SQLite locale + synchronisation REST ;
- copie windows_src/ dans lib/donnees/ ;
- lit la configuration Firebase dans google-services.json ;
- lance l'analyse du code et les tests."""
import json
import pathlib
import re
import shutil
import subprocess
import sys


def echec(message):
    print("Error: " + message)
    sys.exit(1)


# 1) pubspec.yaml : on retire Firebase, on ajoute SQLite et HTTP.
p = pathlib.Path("pubspec.yaml")
texte = p.read_text(encoding="utf-8")
for nom in ("firebase_core", "firebase_auth", "cloud_firestore"):
    texte = re.sub(r"(?m)^\s+" + nom + r":.*\n", "", texte)
extra = (
    "  http: ^1.2.0\n"
    "  sqlite3: ^3.0.0\n"
    "  path: ^1.9.0\n"
    "  path_provider: ^2.1.0\n"
)
marque = "  flutter_localizations:\n    sdk: flutter\n"
if marque not in texte:
    echec("pubspec.yaml : flutter_localizations introuvable")
texte = texte.replace(marque, marque + extra, 1)
p.write_text(texte, encoding="utf-8")

# 2) Sources Windows -> lib/donnees/
source = pathlib.Path("windows_src")
if not source.exists():
    echec("dossier windows_src introuvable dans app.zip")
cible = pathlib.Path("lib/donnees")
cible.mkdir(parents=True, exist_ok=True)
for f in source.glob("*.dart"):
    shutil.copy(f, cible / f.name)

# 3) Configuration Firebase (clé d'API et projet) lue dans google-services.json
try:
    gs = json.loads(pathlib.Path("google-services.json").read_text(encoding="utf-8"))
    projet = gs["project_info"]["project_id"]
    client = gs["client"][0]
    cle = client["api_key"][0]["current_key"]
    app_id = client["client_info"]["mobilesdk_app_id"]
except Exception as e:  # noqa
    echec("google-services.json illisible : %s" % e)
(cible / "config_firebase.dart").write_text(
    "// Généré par tools/patch_windows.py\n"
    "const String configApiKey = '%s';\n"
    "const String configProjectId = '%s';\n"
    "const String configAppId = '%s';\n" % (cle, projet, app_id),
    encoding="utf-8",
)

# 4) Titre de la fenêtre
for chemin in pathlib.Path("windows/runner").glob("main.cpp"):
    t = chemin.read_text(encoding="utf-8")
    t = t.replace('L"bons_adua"', 'L"Bons ADUA"')
    chemin.write_text(t, encoding="utf-8")

print("Windows prêt : SQLite local + synchronisation, projet %s." % projet)


def lancer(commande):
    print("$ " + " ".join(commande), flush=True)
    if subprocess.run(commande, shell=(sys.platform == "win32")).returncode != 0:
        echec("la vérification a échoué : " + " ".join(commande))


exemple = pathlib.Path("test/widget_test.dart")
if exemple.exists() and "MyApp" in exemple.read_text(encoding="utf-8"):
    exemple.unlink()

lancer(["flutter", "pub", "get"])
lancer(["flutter", "analyze", "--no-fatal-infos", "--no-fatal-warnings"])
if pathlib.Path("test").exists():
    lancer(["flutter", "test"])
print("Analyse et tests réussis.")
