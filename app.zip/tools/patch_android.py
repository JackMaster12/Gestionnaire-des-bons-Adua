#!/usr/bin/env python3
"""Prépare le projet Android généré par `flutter create` :
- ajoute le plugin Google Services (Firebase) ;
- fixe minSdk à 23.
À lancer depuis la racine du projet Flutter."""
import pathlib
import re
import subprocess
import sys

ANDROID = pathlib.Path("android")
GS_VERSION = "4.4.2"
ID_GS = "com.google.gms.google-services"


def echec(message):
    print("Error: " + message)
    sys.exit(1)


# 1) settings.gradle(.kts) : déclaration du plugin
fait = False
for nom in ("settings.gradle.kts", "settings.gradle"):
    p = ANDROID / nom
    if not p.exists():
        continue
    kts = nom.endswith(".kts")
    lignes = p.read_text(encoding="utf-8").split("\n")
    if any(ID_GS in l for l in lignes):
        fait = True
        break
    sortie = []
    for l in lignes:
        sortie.append(l)
        m = re.match(
            r'^(\s*)id\s*\(?\s*["\']com\.android\.application["\']\s*\)?\s*version', l)
        if m and not fait:
            ind = m.group(1)
            if kts:
                sortie.append(f'{ind}id("{ID_GS}") version "{GS_VERSION}" apply false')
            else:
                sortie.append(f'{ind}id "{ID_GS}" version "{GS_VERSION}" apply false')
            fait = True
    if fait:
        p.write_text("\n".join(sortie), encoding="utf-8")
    break
if not fait:
    echec("impossible d'ajouter le plugin Google Services dans settings.gradle")

# 2) app/build.gradle(.kts) : application du plugin + minSdk
fait = False
for nom in ("app/build.gradle.kts", "app/build.gradle"):
    p = ANDROID / nom
    if not p.exists():
        continue
    kts = nom.endswith(".kts")
    texte = p.read_text(encoding="utf-8")
    if ID_GS not in texte:
        sortie = []
        ajoute = False
        for l in texte.split("\n"):
            sortie.append(l)
            m = re.match(
                r'^(\s*)id\s*\(?\s*["\']com\.android\.application["\']\s*\)?\s*$', l)
            if m and not ajoute:
                ind = m.group(1)
                sortie.append(f'{ind}id("{ID_GS}")' if kts else f'{ind}id "{ID_GS}"')
                ajoute = True
        if not ajoute:
            echec("impossible d'appliquer le plugin Google Services dans app/build.gradle")
        texte = "\n".join(sortie)
    texte, n = re.subn(
        r'minSdk(?:Version)?\s*=?\s*(?:flutter\.minSdkVersion|\d+)', 'minSdk = 23', texte)
    if n == 0:
        echec("minSdk introuvable dans app/build.gradle")
    p.write_text(texte, encoding="utf-8")
    fait = True
    break
if not fait:
    echec("app/build.gradle introuvable")

# 2b) SMS : permissions dans le manifeste + pont Kotlin MainActivity.
manifeste = ANDROID / "app/src/main/AndroidManifest.xml"
m = manifeste.read_text(encoding="utf-8")
if "android.permission.SEND_SMS" not in m:
    bloc = (
        '    <uses-permission android:name="android.permission.SEND_SMS"/>\n'
        '    <uses-permission android:name="android.permission.READ_PHONE_STATE"/>\n'
        '    <uses-feature android:name="android.hardware.telephony" android:required="false"/>\n'
    )
    if "<application" not in m:
        echec("AndroidManifest.xml : balise application introuvable")
    m = m.replace("<application", bloc + "    <application", 1)
    manifeste.write_text(m, encoding="utf-8")
principal = ANDROID / "app/src/main"
for ancien in list(principal.rglob("MainActivity.kt")) + list(principal.rglob("MainActivity.java")):
    ancien.unlink()
cible = principal / "kotlin/com/adua/bons_adua/MainActivity.kt"
cible.parent.mkdir(parents=True, exist_ok=True)
source = pathlib.Path("tools/MainActivity.kt.txt")
if not source.exists():
    echec("tools/MainActivity.kt.txt introuvable")
cible.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
print("SMS : permissions et MainActivity.kt installés.")

# 2c) Icône de l'application (logo ADUA)
for densite in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
    source_icone = pathlib.Path("icones/ic_launcher_%s.png" % densite)
    dossier = ANDROID / ("app/src/main/res/mipmap-%s" % densite)
    if source_icone.exists() and dossier.exists():
        (dossier / "ic_launcher.png").write_bytes(source_icone.read_bytes())
print("Icône ADUA installée.")

# 2d) Son de démarrage (ressource brute Android)
son = pathlib.Path("icones/adua_demarrage.wav")
if not son.exists():
    echec("icones/adua_demarrage.wav introuvable")
raw = ANDROID / "app/src/main/res/raw"
raw.mkdir(parents=True, exist_ok=True)
(raw / "adua_demarrage.wav").write_bytes(son.read_bytes())
print("Son de démarrage installé.")

print("Android prêt : plugin Google Services ajouté, minSdk = 23.")


# 3) Vérifications automatiques : analyse du code et tests.
#    Les erreurs s'affichent dans ce journal, bien avant la compilation Gradle.
def lancer(commande):
    print("$ " + " ".join(commande), flush=True)
    if subprocess.run(commande).returncode != 0:
        echec("la vérification a échoué : " + " ".join(commande))


# Le test d'exemple généré par flutter create ne correspond pas à l'application.
exemple = pathlib.Path("test/widget_test.dart")
if exemple.exists() and "MyApp" in exemple.read_text(encoding="utf-8"):
    exemple.unlink()

lancer(["flutter", "pub", "get"])
lancer(["flutter", "analyze", "--no-fatal-infos", "--no-fatal-warnings"])
if pathlib.Path("test").exists():
    lancer(["flutter", "test"])
print("Analyse et tests réussis.")
