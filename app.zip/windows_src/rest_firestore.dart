import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'api_auth.dart';
import 'config_firebase.dart';
import 'valeurs.dart';

/// Réponse d'erreur du serveur Firestore (par opposition à une panne de réseau).
class ErreurServeur implements Exception {
  final int statut;
  final String code;
  final String message;
  const ErreurServeur(this.statut, this.code, this.message);

  @override
  String toString() => 'Firestore $statut $code $message';
}

/// Pas de session ouverte : rien à synchroniser.
class SansSession implements Exception {
  const SansSession();
}

class DocRest {
  final String chemin;
  final Map<String, dynamic> data;
  const DocRest(this.chemin, this.data);
}

class RestFirestore {
  RestFirestore._();
  static final RestFirestore instance = RestFirestore._();

  static const Duration _delai = Duration(seconds: 30);

  String get _racine =>
      'projects/$configProjectId/databases/(default)/documents';
  String get _base => 'https://firestore.googleapis.com/v1/$_racine';

  Future<Map<String, String>> _entetes() async {
    final jeton = await FirebaseAuth.instance.jetonValide();
    if (jeton == null) throw const SansSession();
    return <String, String>{
      'Authorization': 'Bearer $jeton',
      'Content-Type': 'application/json',
    };
  }

  Never _erreur(http.Response r) {
    var code = 'UNKNOWN';
    var msg = r.body;
    try {
      final e = (jsonDecode(r.body) as dynamic);
      final err = e is List ? (e.first as Map<String, dynamic>)['error'] : e['error'];
      if (err is Map<String, dynamic>) {
        code = '${err['status'] ?? code}';
        msg = '${err['message'] ?? msg}';
      }
    } catch (_) {}
    throw ErreurServeur(r.statusCode, code, msg);
  }

  String _cheminDepuisNom(String nom) {
    final i = nom.indexOf('/documents/');
    return i < 0 ? nom : nom.substring(i + '/documents/'.length);
  }

  /// Lit un document sur le serveur (null s'il n'existe pas).
  Future<Map<String, dynamic>?> lireDocument(String chemin) async {
    final r = await http
        .get(Uri.parse('$_base/$chemin'), headers: await _entetes())
        .timeout(_delai);
    if (r.statusCode == 404) return null;
    if (r.statusCode != 200) _erreur(r);
    final corps = jsonDecode(r.body) as Map<String, dynamic>;
    final champs = corps['fields'];
    return champsDepuisRest(champs is Map<String, dynamic> ? champs : <String, dynamic>{});
  }

  /// Documents d'une collection de premier niveau, triés par majLe.
  /// [depuis] : ne renvoie que ceux dont majLe >= depuis.
  Future<List<DocRest>> requete(String collection,
      {Timestamp? depuis, int limite = 500, bool trier = true}) async {
    final requeteStruct = <String, Object?>{
      'from': <Object?>[
        <String, Object?>{'collectionId': collection}
      ],
      'limit': limite,
    };
    if (depuis != null) {
      requeteStruct['where'] = <String, Object?>{
        'fieldFilter': <String, Object?>{
          'field': <String, Object?>{'fieldPath': 'majLe'},
          'op': 'GREATER_THAN_OR_EQUAL',
          'value': valeurVersRest(depuis),
        }
      };
    }
    if (trier) {
      requeteStruct['orderBy'] = <Object?>[
        <String, Object?>{
          'field': <String, Object?>{'fieldPath': 'majLe'},
          'direction': 'ASCENDING',
        }
      ];
    }
    final r = await http
        .post(
          Uri.parse('$_base:runQuery'),
          headers: await _entetes(),
          body: jsonEncode(<String, Object?>{'structuredQuery': requeteStruct}),
        )
        .timeout(_delai);
    if (r.statusCode != 200) _erreur(r);
    final liste = jsonDecode(r.body) as List<dynamic>;
    final resultat = <DocRest>[];
    for (final e in liste) {
      final doc = (e as Map<String, dynamic>)['document'];
      if (doc is! Map<String, dynamic>) continue;
      final champs = doc['fields'];
      resultat.add(DocRest(
        _cheminDepuisNom(doc['name'] as String),
        champsDepuisRest(champs is Map<String, dynamic> ? champs : <String, dynamic>{}),
      ));
    }
    return resultat;
  }

  static final RegExp _simple = RegExp(r'^[a-zA-Z_][a-zA-Z_0-9]*$');
  String _chemChamp(String k) => _simple.hasMatch(k) ? k : '`${k.replaceAll('`', r'\`')}`';

  /// Envoie une écriture de la file (une écriture = une validation).
  Future<void> ecrire(String chemin, String mode, Map<String, dynamic> data) async {
    final champs = <String, Object?>{};
    final transformations = <Object?>[];
    final masque = <String>[];
    data.forEach((k, v) {
      if (v is FieldValue) {
        transformations.add(<String, Object?>{
          'fieldPath': _chemChamp(k),
          'setToServerValue': 'REQUEST_TIME',
        });
      } else {
        champs[k] = valeurVersRest(v);
        masque.add(_chemChamp(k));
      }
    });
    final ecriture = <String, Object?>{
      'update': <String, Object?>{
        'name': '$_racine/$chemin',
        'fields': champs,
      },
    };
    if (mode != 'set') {
      ecriture['updateMask'] = <String, Object?>{'fieldPaths': masque};
    }
    if (transformations.isNotEmpty) ecriture['updateTransforms'] = transformations;
    if (mode == 'update') {
      ecriture['currentDocument'] = <String, Object?>{'exists': true};
    }
    final r = await http
        .post(
          Uri.parse('$_base:commit'),
          headers: await _entetes(),
          body: jsonEncode(<String, Object?>{
            'writes': <Object?>[ecriture]
          }),
        )
        .timeout(_delai);
    if (r.statusCode != 200) _erreur(r);
  }
}
