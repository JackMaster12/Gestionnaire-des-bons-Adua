// Imitation du sous-ensemble de firebase_auth / firebase_core utilisé par
// l'application, en passant par l'API REST d'authentification de Google.

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'base_locale.dart';
import 'config_firebase.dart';
import 'sync_service.dart';

class FirebaseException implements Exception {
  final String plugin;
  final String code;
  final String? message;
  FirebaseException({required this.plugin, required this.code, this.message});

  @override
  String toString() => '[$plugin/$code] ${message ?? ''}';
}

class FirebaseAuthException extends FirebaseException {
  FirebaseAuthException({required String code, String? message})
      : super(plugin: 'firebase_auth', code: code, message: message);
}

class FirebaseOptions {
  final String apiKey;
  final String appId;
  final String projectId;
  const FirebaseOptions(
      {required this.apiKey, required this.appId, required this.projectId});
}

class FirebaseApp {
  final String name;
  final FirebaseOptions options;
  FirebaseApp._(this.name, this.options);

  Future<void> delete() async {
    Firebase._apps.remove(name);
  }
}

class Firebase {
  static const String _defaut = '[DEFAULT]';
  static final Map<String, FirebaseApp> _apps = <String, FirebaseApp>{};

  static Future<FirebaseApp> initializeApp(
      {String? name, FirebaseOptions? options}) async {
    final n = name ?? _defaut;
    final existante = _apps[n];
    if (existante != null) return existante;
    final opts = options ??
        const FirebaseOptions(
            apiKey: configApiKey, appId: configAppId, projectId: configProjectId);
    final app = FirebaseApp._(n, opts);
    _apps[n] = app;
    if (n == _defaut) {
      await BaseLocale.instance.ouvrir();
      FirebaseAuth.instance._restaurer();
      SyncService.instance.demarrer();
    }
    return app;
  }

  static FirebaseApp app([String name = _defaut]) {
    final a = _apps[name];
    if (a == null) {
      throw StateError("Aucune application Firebase nommée '$name'");
    }
    return a;
  }
}

class User {
  final String uid;
  final String? email;
  final FirebaseAuth _auth;
  User._(this.uid, this.email, this._auth);

  Future<void> delete() => _auth._supprimerCompte();
}

class UserCredential {
  final User? user;
  const UserCredential(this.user);
}

class FirebaseAuth {
  final bool _persistant;
  FirebaseAuth._(this._persistant);

  static final FirebaseAuth instance = FirebaseAuth._(true);
  static final Map<String, FirebaseAuth> _autres = <String, FirebaseAuth>{};

  static FirebaseAuth instanceFor({required FirebaseApp app}) {
    if (app.name == '[DEFAULT]') return instance;
    return _autres.putIfAbsent(app.name, () => FirebaseAuth._(false));
  }

  String? _uid;
  String? _email;
  String? _jeton;
  String? _rafraichissement;
  DateTime? _expire;
  final StreamController<User?> _ctrl = StreamController<User?>.broadcast();

  User? get currentUser => _uid == null ? null : User._(_uid!, _email, this);

  Stream<User?> authStateChanges() async* {
    yield currentUser;
    yield* _ctrl.stream;
  }

  void _restaurer() {
    final b = BaseLocale.instance;
    _uid = b.meta('auth_uid');
    _email = b.meta('auth_email');
    _rafraichissement = b.meta('auth_refresh');
    _jeton = null;
    _expire = null;
    if (_rafraichissement == null) _uid = null;
  }

  void _enregistrerSession(Map<String, dynamic> r, {required bool signup}) {
    _uid = (r['localId'] ?? r['user_id']) as String?;
    _email = (r['email'] as String?) ?? _email;
    _jeton = (r['idToken'] ?? r['id_token']) as String?;
    _rafraichissement = (r['refreshToken'] ?? r['refresh_token']) as String?;
    final secondes = int.tryParse('${r['expiresIn'] ?? r['expires_in'] ?? 3600}') ?? 3600;
    _expire = DateTime.now().add(Duration(seconds: secondes));
    if (_persistant) {
      final b = BaseLocale.instance;
      b.definirMeta('auth_uid', _uid);
      b.definirMeta('auth_email', _email);
      b.definirMeta('auth_refresh', _rafraichissement);
    }
  }

  Future<Map<String, dynamic>> _appel(String url, Map<String, Object?> corps,
      {bool formulaire = false}) async {
    http.Response r;
    try {
      r = await http
          .post(
            Uri.parse(url),
            headers: formulaire
                ? <String, String>{'Content-Type': 'application/x-www-form-urlencoded'}
                : <String, String>{'Content-Type': 'application/json'},
            body: formulaire ? corps.map((k, v) => MapEntry(k, '$v')) : jsonEncode(corps),
          )
          .timeout(const Duration(seconds: 25));
    } on SocketException {
      throw FirebaseAuthException(code: 'network-request-failed');
    } on TimeoutException {
      throw FirebaseAuthException(code: 'network-request-failed');
    } on http.ClientException {
      throw FirebaseAuthException(code: 'network-request-failed');
    }
    Map<String, dynamic> corpsRep;
    try {
      corpsRep = jsonDecode(r.body) as Map<String, dynamic>;
    } catch (_) {
      throw FirebaseAuthException(code: 'unknown', message: 'Réponse inattendue');
    }
    if (r.statusCode >= 200 && r.statusCode < 300) return corpsRep;
    final erreur = corpsRep['error'];
    var msg = '';
    if (erreur is Map<String, dynamic>) msg = '${erreur['message'] ?? ''}';
    throw FirebaseAuthException(code: _codeDepuisMessage(msg), message: msg);
  }

  static String _codeDepuisMessage(String m) {
    if (m.startsWith('INVALID_LOGIN_CREDENTIALS')) return 'invalid-credential';
    if (m.startsWith('EMAIL_NOT_FOUND')) return 'user-not-found';
    if (m.startsWith('INVALID_PASSWORD')) return 'wrong-password';
    if (m.startsWith('INVALID_EMAIL')) return 'invalid-email';
    if (m.startsWith('EMAIL_EXISTS')) return 'email-already-in-use';
    if (m.startsWith('WEAK_PASSWORD')) return 'weak-password';
    if (m.startsWith('USER_DISABLED')) return 'user-disabled';
    if (m.startsWith('TOO_MANY_ATTEMPTS')) return 'too-many-requests';
    if (m.startsWith('OPERATION_NOT_ALLOWED') ||
        m.startsWith('PASSWORD_LOGIN_DISABLED')) {
      return 'operation-not-allowed';
    }
    return 'unknown';
  }

  Future<UserCredential> signInWithEmailAndPassword(
      {required String email, required String password}) async {
    final r = await _appel(
      'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$configApiKey',
      <String, Object?>{'email': email, 'password': password, 'returnSecureToken': true},
    );
    _enregistrerSession(r, signup: false);
    _ctrl.add(currentUser);
    if (_persistant) SyncService.instance.synchroniser();
    return UserCredential(currentUser);
  }

  Future<UserCredential> createUserWithEmailAndPassword(
      {required String email, required String password}) async {
    final r = await _appel(
      'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$configApiKey',
      <String, Object?>{'email': email, 'password': password, 'returnSecureToken': true},
    );
    _enregistrerSession(r, signup: true);
    _ctrl.add(currentUser);
    if (_persistant) SyncService.instance.synchroniser();
    return UserCredential(currentUser);
  }

  Future<void> signOut() async {
    _uid = null;
    _email = null;
    _jeton = null;
    _rafraichissement = null;
    _expire = null;
    if (_persistant) {
      final b = BaseLocale.instance;
      b.definirMeta('auth_uid', null);
      b.definirMeta('auth_email', null);
      b.definirMeta('auth_refresh', null);
    }
    _ctrl.add(null);
  }

  Future<void> _supprimerCompte() async {
    final jeton = await jetonValide();
    if (jeton == null) throw FirebaseAuthException(code: 'user-not-found');
    await _appel(
      'https://identitytoolkit.googleapis.com/v1/accounts:delete?key=$configApiKey',
      <String, Object?>{'idToken': jeton},
    );
    await signOut();
  }

  /// Jeton d'accès valable (renouvelé si besoin). Null si personne n'est connecté.
  /// Lève une erreur réseau si le renouvellement est impossible hors ligne.
  Future<String?> jetonValide() async {
    if (_uid == null) return null;
    final expire = _expire;
    if (_jeton != null &&
        expire != null &&
        expire.isAfter(DateTime.now().add(const Duration(minutes: 2)))) {
      return _jeton;
    }
    final refresh = _rafraichissement;
    if (refresh == null) return null;
    try {
      final r = await _appel(
        'https://securetoken.googleapis.com/v1/token?key=$configApiKey',
        <String, Object?>{'grant_type': 'refresh_token', 'refresh_token': refresh},
        formulaire: true,
      );
      _enregistrerSession(r, signup: false);
      return _jeton;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'network-request-failed') rethrow;
      // Session refusée (compte désactivé ou supprimé) : on déconnecte.
      await signOut();
      return null;
    }
  }
}
