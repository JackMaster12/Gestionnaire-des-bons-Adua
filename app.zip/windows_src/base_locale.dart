import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as chemin_lib;
import 'package:path_provider/path_provider.dart';
import 'package:sqlite3/sqlite3.dart';

import 'valeurs.dart';

class Changement {
  final String coll;
  final String id;
  const Changement(this.coll, this.id);
}

class LigneDoc {
  final String id;
  final Map<String, dynamic> data;
  const LigneDoc(this.id, this.data);
}

class EntreeFile {
  final int seq;
  final String chemin;

  /// set (remplace), merge (fusionne), update (modifie un document existant).
  final String mode;
  final Map<String, dynamic> data;
  const EntreeFile(this.seq, this.chemin, this.mode, this.data);
}

/// Base SQLite de l'ordinateur : documents, file des écritures à envoyer,
/// réglages. Toutes les lectures et écritures de l'application passent ici,
/// donc l'application marche sans Internet.
class BaseLocale {
  BaseLocale._();
  static final BaseLocale instance = BaseLocale._();

  Database? _db;
  final StreamController<Changement> _bus =
      StreamController<Changement>.broadcast();

  bool get ouverte => _db != null;
  Stream<Changement> get changements => _bus.stream;

  Database get _base {
    final d = _db;
    if (d == null) throw StateError('Base locale non ouverte');
    return d;
  }

  Future<void> ouvrir() async {
    if (_db != null) return;
    final dossier = await getApplicationSupportDirectory();
    final d = Directory(chemin_lib.join(dossier.path, 'bons_adua'));
    if (!d.existsSync()) d.createSync(recursive: true);
    final base = sqlite3.open(chemin_lib.join(d.path, 'donnees.db'));
    base.execute('PRAGMA journal_mode=WAL');
    base.execute('PRAGMA synchronous=NORMAL');
    base.execute('''
      CREATE TABLE IF NOT EXISTS docs (
        chemin TEXT PRIMARY KEY,
        coll TEXT NOT NULL,
        id TEXT NOT NULL,
        json TEXT NOT NULL,
        maj INTEGER NOT NULL DEFAULT 0
      )''');
    base.execute('CREATE INDEX IF NOT EXISTS idx_docs_coll ON docs(coll, maj)');
    base.execute('''
      CREATE TABLE IF NOT EXISTS file (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        chemin TEXT NOT NULL,
        mode TEXT NOT NULL,
        json TEXT NOT NULL
      )''');
    base.execute(
        'CREATE TABLE IF NOT EXISTS meta (cle TEXT PRIMARY KEY, valeur TEXT)');
    _db = base;
  }

  // ---------- Réglages ----------

  String? meta(String cle) {
    final r = _base.select('SELECT valeur FROM meta WHERE cle = ?', [cle]);
    if (r.isEmpty) return null;
    return r.first['valeur'] as String?;
  }

  void definirMeta(String cle, String? valeur) {
    if (valeur == null) {
      _base.execute('DELETE FROM meta WHERE cle = ?', [cle]);
    } else {
      _base.execute(
          'INSERT OR REPLACE INTO meta (cle, valeur) VALUES (?, ?)', [cle, valeur]);
    }
  }

  // ---------- Documents ----------

  static String collDe(String chemin) {
    final i = chemin.lastIndexOf('/');
    return i < 0 ? '' : chemin.substring(0, i);
  }

  static String idDe(String chemin) => chemin.substring(chemin.lastIndexOf('/') + 1);

  Map<String, dynamic>? lire(String chemin) {
    final r = _base.select('SELECT json FROM docs WHERE chemin = ?', [chemin]);
    if (r.isEmpty) return null;
    return _decoder(r.first['json'] as String);
  }

  Map<String, dynamic> _decoder(String json) {
    final v = depuisJsonLocal(jsonDecode(json));
    return v is Map<String, dynamic> ? v : <String, dynamic>{};
  }

  List<LigneDoc> lireCollection(String coll, {int? majMin}) {
    final r = majMin == null
        ? _base.select('SELECT id, json FROM docs WHERE coll = ?', [coll])
        : _base.select(
            'SELECT id, json FROM docs WHERE coll = ? AND maj >= ?', [coll, majMin]);
    return [
      for (final ligne in r)
        LigneDoc(ligne['id'] as String, _decoder(ligne['json'] as String))
    ];
  }

  void _ecrireDoc(String chemin, Map<String, dynamic> data) {
    final maj = data['majLe'];
    _base.execute(
      'INSERT OR REPLACE INTO docs (chemin, coll, id, json, maj) VALUES (?, ?, ?, ?, ?)',
      [
        chemin,
        collDe(chemin),
        idDe(chemin),
        jsonEncode(versJsonLocal(data)),
        maj is Timestamp ? maj.microsecondes : 0,
      ],
    );
  }

  /// Remplace les valeurs « heure du serveur » par l'heure locale.
  Map<String, dynamic> _resoudre(Map<String, dynamic> data) {
    final maintenant = Timestamp.now();
    return <String, dynamic>{
      for (final e in data.entries)
        e.key: e.value is FieldValue ? maintenant : e.value
    };
  }

  void _enfiler(String chemin, String mode, Map<String, dynamic> data) {
    _base.execute(
      'INSERT INTO file (chemin, mode, json) VALUES (?, ?, ?)',
      [chemin, mode, jsonEncode(versJsonLocal(data))],
    );
  }

  /// Écriture faite sur cet ordinateur : appliquée tout de suite en local,
  /// puis mise dans la file pour être envoyée à Firebase.
  void ecrire(String chemin, Map<String, dynamic> data, String mode) {
    final existant = lire(chemin);
    final resolu = _resoudre(data);
    final Map<String, dynamic> nouveau =
        (mode == 'set') ? resolu : <String, dynamic>{...?existant, ...resolu};
    _base.execute('BEGIN');
    try {
      _ecrireDoc(chemin, nouveau);
      _enfiler(chemin, mode, data);
      _base.execute('COMMIT');
    } catch (_) {
      _base.execute('ROLLBACK');
      rethrow;
    }
    _bus.add(Changement(collDe(chemin), idDe(chemin)));
  }

  bool aEcritureEnAttente(String chemin) {
    final r = _base.select('SELECT 1 FROM file WHERE chemin = ? LIMIT 1', [chemin]);
    return r.isNotEmpty;
  }

  /// Documents reçus du serveur. Un document qui a encore une écriture
  /// en attente n'est pas écrasé.
  void recevoir(List<MapEntry<String, Map<String, dynamic>>> docs) {
    if (docs.isEmpty) return;
    final touches = <Changement>[];
    _base.execute('BEGIN');
    try {
      for (final d in docs) {
        if (aEcritureEnAttente(d.key)) continue;
        _ecrireDoc(d.key, d.value);
        touches.add(Changement(collDe(d.key), idDe(d.key)));
      }
      _base.execute('COMMIT');
    } catch (_) {
      _base.execute('ROLLBACK');
      rethrow;
    }
    for (final c in touches) {
      _bus.add(c);
    }
  }

  // ---------- File des écritures ----------

  int nombreEnAttente() {
    final r = _base.select('SELECT COUNT(*) AS n FROM file');
    return (r.first['n'] as int?) ?? 0;
  }

  List<EntreeFile> fileEnAttente({int limite = 50}) {
    final r = _base.select(
        'SELECT seq, chemin, mode, json FROM file ORDER BY seq ASC LIMIT ?', [limite]);
    return [
      for (final l in r)
        EntreeFile(l['seq'] as int, l['chemin'] as String, l['mode'] as String,
            _decoder(l['json'] as String))
    ];
  }

  void retirerDeLaFile(int seq) {
    _base.execute('DELETE FROM file WHERE seq = ?', [seq]);
  }
}
