import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import 'api_auth.dart';
import 'base_locale.dart';
import 'rest_firestore.dart';
import 'valeurs.dart';

/// Synchronisation de l'ordinateur avec Firebase.
/// 1) on envoie d'abord toutes les écritures faites hors ligne (dans l'ordre) ;
/// 2) on ne reçoit ensuite que les documents modifiés depuis la dernière fois.
/// Tout est prévu pour une connexion très courte (quelques minutes par jour).
class SyncService extends ChangeNotifier {
  SyncService._();
  static final SyncService instance = SyncService._();

  /// Collections volumineuses : lecture incrémentale (majLe >= dernier curseur).
  static const List<String> _incrementales = <String>['clients', 'operations'];

  /// Petites collections : relues en entier, mais rarement.
  /// (« etat » n'est pas listé : les règles n'autorisent que sa lecture directe.)
  static const List<String> _petites = <String>[
    'utilisateurs',
    'appareils',
    'parametres',
  ];

  Timer? _minuteur;
  Timer? _delaiEcriture;
  bool enCours = false;
  DateTime? dernierSucces;
  String erreur = '';
  bool horsLigne = false;
  int enAttente = 0;
  int rejets = 0;
  String dernierRejet = '';
  String avertissement = '';
  DateTime? _dernierePetite;

  void demarrer() {
    if (_minuteur != null) return;
    enAttente = BaseLocale.instance.nombreEnAttente();
    _minuteur = Timer.periodic(const Duration(minutes: 5), (_) => synchroniser());
    synchroniser();
  }

  void arreter() {
    _minuteur?.cancel();
    _minuteur = null;
    _delaiEcriture?.cancel();
  }

  /// Appelé après chaque écriture locale : envoi rapide si Internet est là.
  void signalerEcriture() {
    enAttente = BaseLocale.instance.nombreEnAttente();
    notifyListeners();
    _delaiEcriture?.cancel();
    _delaiEcriture = Timer(const Duration(seconds: 4), () => synchroniser());
  }

  Future<void> synchroniser({bool forcer = false}) async {
    if (enCours) return;
    if (!BaseLocale.instance.ouverte) return;
    if (FirebaseAuth.instance.currentUser == null) return;
    enCours = true;
    erreur = '';
    notifyListeners();
    try {
      await _pousser();
      await _tirer(forcer: forcer);
      dernierSucces = DateTime.now();
      horsLigne = false;
      BaseLocale.instance.definirMeta('sync_ok', dernierSucces!.toIso8601String());
    } on SansSession {
      erreur = '';
    } catch (e) {
      if (_estReseau(e)) {
        horsLigne = true;
        erreur = 'Pas de connexion Internet : les données restent sur cet ordinateur.';
      } else {
        erreur = 'Synchronisation interrompue : $e';
      }
    } finally {
      enCours = false;
      enAttente = BaseLocale.instance.nombreEnAttente();
      notifyListeners();
    }
  }

  bool _estReseau(Object e) {
    if (e is SocketException || e is TimeoutException || e is http.ClientException) {
      return true;
    }
    if (e is FirebaseAuthException && e.code == 'network-request-failed') return true;
    if (e is ErreurServeur && e.statut >= 500) return true;
    return false;
  }

  Future<void> _pousser() async {
    final base = BaseLocale.instance;
    while (true) {
      final lot = base.fileEnAttente(limite: 50);
      if (lot.isEmpty) return;
      for (final e in lot) {
        try {
          await RestFirestore.instance.ecrire(e.chemin, e.mode, e.data);
          base.retirerDeLaFile(e.seq);
        } on ErreurServeur catch (err) {
          // Erreur définitive (règles de sécurité, document absent...) :
          // on abandonne cette écriture et on continue avec les suivantes.
          if (err.statut == 401 || err.statut == 429 || err.statut >= 500) rethrow;
          base.retirerDeLaFile(e.seq);
          rejets++;
          dernierRejet = '${e.chemin} : ${err.code}';
        }
        enAttente = base.nombreEnAttente();
        notifyListeners();
      }
    }
  }

  Future<void> _tirer({required bool forcer}) async {
    final base = BaseLocale.instance;
    for (final coll in _incrementales) {
      await _tirerIncremental(coll);
    }
    final maintenant = DateTime.now();
    final derniere = _dernierePetite;
    if (forcer ||
        derniere == null ||
        maintenant.difference(derniere).inMinutes >= 30) {
      for (final coll in _petites) {
        try {
          final docs =
              await RestFirestore.instance.requete(coll, limite: 300, trier: false);
          base.recevoir([for (final d in docs) MapEntry(d.chemin, d.data)]);
        } on ErreurServeur catch (err) {
          // Refus des règles de sécurité pour cette petite collection : on continue.
          if (err.statut == 401 || err.statut >= 500) rethrow;
          avertissement = '$coll : ${err.code}';
        }
      }
      _dernierePetite = maintenant;
    }
  }

  Future<void> _tirerIncremental(String coll) async {
    final base = BaseLocale.instance;
    final cle = 'curseur_$coll';
    final enregistre = base.meta(cle);
    Timestamp? curseur =
        enregistre == null ? null : Timestamp.depuisMicro(int.parse(enregistre));
    var limite = 500;
    while (true) {
      final docs = await RestFirestore.instance
          .requete(coll, depuis: curseur, limite: limite);
      base.recevoir([for (final d in docs) MapEntry(d.chemin, d.data)]);
      Timestamp? max;
      for (final d in docs) {
        final m = d.data['majLe'];
        if (m is Timestamp && (max == null || m.compareTo(max) > 0)) max = m;
      }
      if (max != null) {
        curseur = max;
        base.definirMeta(cle, '${max.microsecondes}');
      }
      if (docs.length < limite) return;
      // Page pleine : si tous les documents ont le même majLe, on agrandit la page.
      if (max != null && docs.every((d) => d.data['majLe'] == max)) {
        limite = limite * 2;
        if (limite > 20000) return;
      }
    }
  }
}
