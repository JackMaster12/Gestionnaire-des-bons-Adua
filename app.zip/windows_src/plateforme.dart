// Version Windows de lib/donnees/plateforme.dart.
import 'package:flutter/material.dart';

import 'sync_service.dart';

const bool estWindows = true;
const String nomPlateforme = 'windows';

String _heure(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

/// Indicateur de synchronisation avec Firebase (clic = synchroniser maintenant).
Widget boutonSync(BuildContext context) {
  return ListenableBuilder(
    listenable: SyncService.instance,
    builder: (context, _) {
      final s = SyncService.instance;
      String texte;
      IconData icone;
      if (s.enCours) {
        texte = 'Synchronisation…';
        icone = Icons.sync;
      } else if (s.horsLigne) {
        texte = s.enAttente > 0 ? 'Hors ligne · ${s.enAttente} à envoyer' : 'Hors ligne';
        icone = Icons.cloud_off;
      } else if (s.erreur.isNotEmpty) {
        texte = 'Erreur de synchronisation';
        icone = Icons.error_outline;
      } else if (s.dernierSucces != null) {
        texte = 'Synchronisé ${_heure(s.dernierSucces!)}'
            '${s.enAttente > 0 ? ' · ${s.enAttente} à envoyer' : ''}';
        icone = Icons.cloud_done;
      } else {
        texte = 'Pas encore synchronisé';
        icone = Icons.cloud_queue;
      }
      final aide = [
        if (s.erreur.isNotEmpty) s.erreur,
        if (s.rejets > 0) '${s.rejets} écriture(s) refusée(s) : ${s.dernierRejet}',
        'Cliquer pour synchroniser maintenant',
      ].join('\n');
      return Tooltip(
        message: aide,
        child: TextButton.icon(
          onPressed: s.enCours ? null : () => s.synchroniser(forcer: true),
          icon: Icon(icone),
          label: Text(texte),
        ),
      );
    },
  );
}
