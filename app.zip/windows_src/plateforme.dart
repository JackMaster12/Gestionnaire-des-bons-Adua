// Version Windows de lib/donnees/plateforme.dart.
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

import 'son_demarrage.dart';
import 'sync_service.dart';

const bool estWindows = true;
const String nomPlateforme = 'windows';

String _heure(DateTime d) =>
    '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

Future<void> _cliquer(BuildContext context, SyncService s) async {
  await s.synchroniser(forcer: true);
  if (!context.mounted) return;
  final details = [
    if (s.erreur.isNotEmpty) s.erreur,
    if (s.avertissement.isNotEmpty) 'Avertissement : ${s.avertissement}',
    if (s.rejets > 0) '${s.rejets} écriture(s) refusée(s) par le serveur : ${s.dernierRejet}',
  ];
  if (details.isEmpty) return;
  await showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Synchronisation'),
      content: SelectableText(details.join('\n\n')),
      actions: [
        TextButton(
            onPressed: () => Navigator.of(ctx).pop(), child: const Text('Fermer')),
      ],
    ),
  );
}

/// Indicateur de synchronisation avec Firebase (clic = synchroniser maintenant).
Widget boutonSync(BuildContext context, {Color? couleur}) {
  return ListenableBuilder(
    listenable: SyncService.instance,
    builder: (context, _) {
      final s = SyncService.instance;
      String texte;
      IconData icone;
      if (s.enCours) {
        texte = 'Synchronisation…';
        icone = Icons.sync;
      } else if (s.horsLigne) {
        texte = s.enAttente > 0 ? 'Hors ligne · ${s.enAttente} à envoyer' : 'Hors ligne';
        icone = Icons.cloud_off;
      } else if (s.erreur.isNotEmpty) {
        texte = 'Erreur de synchronisation';
        icone = Icons.error_outline;
      } else if (s.dernierSucces != null) {
        texte = 'Synchronisé ${_heure(s.dernierSucces!)}'
            '${s.enAttente > 0 ? ' · ${s.enAttente} à envoyer' : ''}';
        icone = Icons.cloud_done;
      } else {
        texte = 'Pas encore synchronisé';
        icone = Icons.cloud_queue;
      }
      final aide = [
        if (s.erreur.isNotEmpty) s.erreur,
        if (s.rejets > 0) '${s.rejets} écriture(s) refusée(s) : ${s.dernierRejet}',
        'Cliquer pour synchroniser maintenant',
      ].join('\n');
      return Tooltip(
        message: aide,
        child: TextButton.icon(
          style: TextButton.styleFrom(foregroundColor: couleur),
          onPressed: s.enCours ? null : () => _cliquer(context, s),
          icon: Icon(icone),
          label: Text(texte),
        ),
      );
    },
  );
}

/// Joue le petit son de lancement via Windows (PowerShell, sans bloquer l'écran).
Future<void> jouerSonDemarrage() async {
  try {
    final fichier = File('${Directory.systemTemp.path}\\adua_demarrage.wav');
    await fichier.writeAsBytes(base64Decode(sonDemarrageBase64), flush: true);
    await Process.run('powershell', <String>[
      '-NoProfile',
      '-WindowStyle',
      'Hidden',
      '-Command',
      "(New-Object System.Media.SoundPlayer '${fichier.path}').PlaySync()",
    ]);
  } catch (_) {}
}
