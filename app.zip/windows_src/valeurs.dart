// Types de valeurs compatibles avec cloud_firestore (version Windows).

class Timestamp implements Comparable<Timestamp> {
  /// Microsecondes depuis le 1er janvier 1970 UTC.
  final int microsecondes;
  const Timestamp.depuisMicro(this.microsecondes);

  factory Timestamp.fromDate(DateTime d) =>
      Timestamp.depuisMicro(d.microsecondsSinceEpoch);
  factory Timestamp.now() => Timestamp.fromDate(DateTime.now());

  DateTime toDate() => DateTime.fromMicrosecondsSinceEpoch(microsecondes);

  @override
  int compareTo(Timestamp other) => microsecondes.compareTo(other.microsecondes);

  @override
  bool operator ==(Object other) =>
      other is Timestamp && other.microsecondes == microsecondes;

  @override
  int get hashCode => microsecondes.hashCode;

  @override
  String toString() => 'Timestamp($microsecondes)';
}

class FieldValue {
  final String _type;
  const FieldValue._(this._type);
  static FieldValue serverTimestamp() => const FieldValue._('serverTimestamp');
  bool get estHorodatageServeur => _type == 'serverTimestamp';
}

// ---------- Stockage local (JSON) ----------

/// Valeur Dart -> JSON local. Timestamp et FieldValue deviennent de petits objets marqués.
Object? versJsonLocal(Object? v) {
  if (v is Timestamp) return <String, Object?>{r'$ts': v.microsecondes};
  if (v is FieldValue) return <String, Object?>{r'$sv': 1};
  if (v is Map) {
    return <String, Object?>{
      for (final e in v.entries) e.key.toString(): versJsonLocal(e.value)
    };
  }
  if (v is List) return <Object?>[for (final e in v) versJsonLocal(e)];
  return v;
}

Object? depuisJsonLocal(Object? v) {
  if (v is Map) {
    if (v.length == 1 && v.containsKey(r'$ts')) {
      return Timestamp.depuisMicro((v[r'$ts'] as num).toInt());
    }
    if (v.length == 1 && v.containsKey(r'$sv')) return FieldValue.serverTimestamp();
    return <String, dynamic>{
      for (final e in v.entries) e.key.toString(): depuisJsonLocal(e.value)
    };
  }
  if (v is List) return <dynamic>[for (final e in v) depuisJsonLocal(e)];
  return v;
}

// ---------- Format de l'API REST de Firestore ----------

Map<String, Object?> valeurVersRest(Object? v) {
  if (v == null) return <String, Object?>{'nullValue': null};
  if (v is bool) return <String, Object?>{'booleanValue': v};
  if (v is int) return <String, Object?>{'integerValue': '$v'};
  if (v is double) return <String, Object?>{'doubleValue': v};
  if (v is String) return <String, Object?>{'stringValue': v};
  if (v is Timestamp) {
    final iso = DateTime.fromMicrosecondsSinceEpoch(v.microsecondes, isUtc: true)
        .toIso8601String();
    return <String, Object?>{'timestampValue': iso};
  }
  if (v is Map) {
    return <String, Object?>{
      'mapValue': <String, Object?>{
        'fields': <String, Object?>{
          for (final e in v.entries) e.key.toString(): valeurVersRest(e.value)
        }
      }
    };
  }
  if (v is List) {
    return <String, Object?>{
      'arrayValue': <String, Object?>{
        'values': <Object?>[for (final e in v) valeurVersRest(e)]
      }
    };
  }
  return <String, Object?>{'stringValue': v.toString()};
}

Object? valeurDepuisRest(Map<String, dynamic> v) {
  if (v.containsKey('nullValue')) return null;
  if (v.containsKey('booleanValue')) return v['booleanValue'] as bool;
  if (v.containsKey('integerValue')) return int.parse('${v['integerValue']}');
  if (v.containsKey('doubleValue')) return (v['doubleValue'] as num).toDouble();
  if (v.containsKey('stringValue')) return v['stringValue'] as String;
  if (v.containsKey('timestampValue')) {
    return Timestamp.fromDate(DateTime.parse(v['timestampValue'] as String).toUtc());
  }
  if (v.containsKey('mapValue')) {
    final m = (v['mapValue'] as Map<String, dynamic>)['fields'];
    return champsDepuisRest(m is Map<String, dynamic> ? m : <String, dynamic>{});
  }
  if (v.containsKey('arrayValue')) {
    final liste = (v['arrayValue'] as Map<String, dynamic>)['values'];
    if (liste is! List) return <dynamic>[];
    return <dynamic>[
      for (final e in liste) valeurDepuisRest(e as Map<String, dynamic>)
    ];
  }
  if (v.containsKey('referenceValue')) return v['referenceValue'];
  return null;
}

Map<String, dynamic> champsDepuisRest(Map<String, dynamic> champs) {
  return <String, dynamic>{
    for (final e in champs.entries)
      e.key: valeurDepuisRest(e.value as Map<String, dynamic>)
  };
}
