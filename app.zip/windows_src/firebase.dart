// Version Windows de lib/donnees/firebase.dart : mêmes noms que les paquets
// Firebase, mais les données vivent dans une base SQLite locale.
export 'api_auth.dart';
export 'api_firestore.dart';
