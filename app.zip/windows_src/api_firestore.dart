// Imitation du sous-ensemble de cloud_firestore utilisé par l'application,
// branchée sur la base SQLite locale (voir base_locale.dart).

import 'dart:async';
import 'dart:math';

import 'base_locale.dart';
import 'config_firebase.dart';
import 'rest_firestore.dart';
import 'sync_service.dart';
import 'valeurs.dart';

export 'valeurs.dart' show Timestamp, FieldValue;

enum Source { server, cache, serverAndCache }

class GetOptions {
  final Source source;
  const GetOptions({this.source = Source.serverAndCache});
}

class SetOptions {
  final bool? merge;
  const SetOptions({this.merge});
}

class Settings {
  static const int CACHE_SIZE_UNLIMITED = -1;
  final bool? persistenceEnabled;
  final int? cacheSizeBytes;
  const Settings({this.persistenceEnabled, this.cacheSizeBytes});
}

class SnapshotMetadata {
  final bool isFromCache;
  final bool hasPendingWrites;
  const SnapshotMetadata(this.isFromCache, this.hasPendingWrites);
}

enum DocumentChangeType { added, modified, removed }

class DocumentSnapshot<T extends Object?> {
  final String id;
  final DocumentReference<T> reference;
  final Map<String, dynamic>? _donnees;
  final SnapshotMetadata metadata;

  DocumentSnapshot._(this.id, this.reference, this._donnees, this.metadata);

  bool get exists => _donnees != null;

  T? data() => _donnees as T?;

  dynamic operator [](Object champ) => _donnees?[champ.toString()];
}

class QueryDocumentSnapshot<T extends Object?> extends DocumentSnapshot<T> {
  QueryDocumentSnapshot._(
      String id, DocumentReference<T> ref, Map<String, dynamic> donnees, SnapshotMetadata m)
      : super._(id, ref, donnees, m);

  @override
  T data() => _donnees as T;
}

class DocumentChange<T extends Object?> {
  final DocumentChangeType type;
  final QueryDocumentSnapshot<T> doc;
  const DocumentChange._(this.type, this.doc);
}

class QuerySnapshot<T extends Object?> {
  final List<QueryDocumentSnapshot<T>> docs;
  final List<DocumentChange<T>> docChanges;
  final SnapshotMetadata metadata;
  QuerySnapshot._(this.docs, this.docChanges, this.metadata);
  int get size => docs.length;
}

BaseLocale get _base {
  final b = BaseLocale.instance;
  if (!b.ouverte) {
    throw StateError("Firebase.initializeApp() n'a pas été appelé");
  }
  return b;
}

class Query<T extends Object?> {
  final String _coll;
  final int? _majMin;
  const Query._(this._coll, this._majMin);

  Query<T> where(
    Object champ, {
    Object? isEqualTo,
    Object? isGreaterThanOrEqualTo,
  }) {
    if (champ == 'majLe' &&
        isGreaterThanOrEqualTo is Timestamp &&
        isEqualTo == null) {
      return Query<T>._(_coll, isGreaterThanOrEqualTo.microsecondes);
    }
    throw UnimplementedError('Filtre non géré dans la version Windows : $champ');
  }

  QueryDocumentSnapshot<T> _doc(LigneDoc l, bool enAttente) {
    final ref = DocumentReference<T>._('$_coll/${l.id}');
    return QueryDocumentSnapshot<T>._(l.id, ref, l.data, SnapshotMetadata(false, enAttente));
  }

  Future<QuerySnapshot<T>> get([GetOptions? options]) async {
    final lignes = _base.lireCollection(_coll, majMin: _majMin);
    final docs = [for (final l in lignes) _doc(l, false)];
    return QuerySnapshot<T>._(docs, [
      for (final d in docs) DocumentChange<T>._(DocumentChangeType.added, d)
    ], const SnapshotMetadata(true, false));
  }

  Stream<QuerySnapshot<T>> snapshots() {
    late StreamController<QuerySnapshot<T>> ctrl;
    StreamSubscription<Changement>? abo;
    Timer? minuteur;
    final modifies = <String>{};

    void emettre(bool initial) {
      if (ctrl.isClosed) return;
      final lignes = _base.lireCollection(_coll, majMin: _majMin);
      final docs = [for (final l in lignes) _doc(l, false)];
      final ids = Set<String>.of(modifies);
      modifies.clear();
      final changements = [
        for (final d in docs)
          if (initial || ids.contains(d.id))
            DocumentChange<T>._(
                initial ? DocumentChangeType.added : DocumentChangeType.modified, d)
      ];
      ctrl.add(QuerySnapshot<T>._(docs, changements, const SnapshotMetadata(false, false)));
    }

    ctrl = StreamController<QuerySnapshot<T>>(
      onListen: () {
        scheduleMicrotask(() => emettre(true));
        abo = _base.changements.listen((c) {
          if (c.coll != _coll) return;
          modifies.add(c.id);
          minuteur ??= Timer(const Duration(milliseconds: 40), () {
            minuteur = null;
            emettre(false);
          });
        });
      },
      onCancel: () {
        minuteur?.cancel();
        abo?.cancel();
      },
    );
    return ctrl.stream;
  }
}

class CollectionReference<T extends Object?> extends Query<T> {
  final String path;
  const CollectionReference._(String chemin)
      : path = chemin,
        super._(chemin, null);

  String get id => path.substring(path.lastIndexOf('/') + 1);

  DocumentReference<T> doc([String? idDoc]) {
    final identifiant = idDoc ?? _idAleatoire();
    return DocumentReference<T>._('$path/$identifiant');
  }

  static String _idAleatoire() {
    final r = Random.secure();
    const lettres = 'abcdefghijklmnopqrstuvwxyz0123456789';
    return List<String>.generate(20, (_) => lettres[r.nextInt(lettres.length)]).join();
  }
}

class DocumentReference<T extends Object?> {
  final String path;
  const DocumentReference._(this.path);

  String get id => path.substring(path.lastIndexOf('/') + 1);

  CollectionReference<T> collection(String sous) =>
      CollectionReference<T>._('$path/$sous');

  DocumentSnapshot<T> _instantane() {
    final d = _base.lire(path);
    final fromCache = d == null && _base.meta('sync_ok') == null;
    return DocumentSnapshot<T>._(id, this, d, SnapshotMetadata(fromCache, false));
  }

  Future<DocumentSnapshot<T>> get([GetOptions? options]) async {
    if (options != null && options.source == Source.server) {
      final d = await RestFirestore.instance.lireDocument(path);
      return DocumentSnapshot<T>._(id, this, d, const SnapshotMetadata(false, false));
    }
    return _instantane();
  }

  Stream<DocumentSnapshot<T>> snapshots() {
    late StreamController<DocumentSnapshot<T>> ctrl;
    StreamSubscription<Changement>? abo;
    ctrl = StreamController<DocumentSnapshot<T>>(
      onListen: () {
        scheduleMicrotask(() {
          if (!ctrl.isClosed) ctrl.add(_instantane());
        });
        final coll = BaseLocale.collDe(path);
        abo = _base.changements.listen((c) {
          if (c.coll == coll && c.id == id && !ctrl.isClosed) ctrl.add(_instantane());
        });
      },
      onCancel: () => abo?.cancel(),
    );
    return ctrl.stream;
  }

  Future<void> set(T data, [SetOptions? options]) {
    _base.ecrire(
        path, Map<String, dynamic>.from(data as Map), (options?.merge ?? false) ? 'merge' : 'set');
    SyncService.instance.signalerEcriture();
    return Future<void>.value();
  }

  Future<void> update(Map<String, Object?> data) {
    _base.ecrire(path, Map<String, dynamic>.from(data), 'update');
    SyncService.instance.signalerEcriture();
    return Future<void>.value();
  }
}

class _OperationLot {
  final DocumentReference<Object?> ref;
  final Map<String, dynamic> data;
  final String mode;
  const _OperationLot(this.ref, this.data, this.mode);
}

class WriteBatch {
  final List<_OperationLot> _ops = <_OperationLot>[];

  void set<T extends Object?>(DocumentReference<T> document, T data,
      [SetOptions? options]) {
    _ops.add(_OperationLot(document, Map<String, dynamic>.from(data as Map),
        (options?.merge ?? false) ? 'merge' : 'set'));
  }

  void update(DocumentReference<Object?> document, Map<String, Object?> data) {
    _ops.add(_OperationLot(document, Map<String, dynamic>.from(data), 'update'));
  }

  Future<void> commit() {
    for (final o in _ops) {
      _base.ecrire(o.ref.path, o.data, o.mode);
    }
    _ops.clear();
    SyncService.instance.signalerEcriture();
    return Future<void>.value();
  }
}

class FirebaseFirestore {
  FirebaseFirestore._();
  static final FirebaseFirestore instance = FirebaseFirestore._();

  set settings(Settings s) {}

  CollectionReference<Map<String, dynamic>> collection(String chemin) =>
      CollectionReference<Map<String, dynamic>>._(chemin);

  WriteBatch batch() => WriteBatch();

  String get projet => configProjectId;
}
