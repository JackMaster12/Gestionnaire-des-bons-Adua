// Remplacé à la compilation par tools/patch_windows.py (valeurs lues dans google-services.json).
const String configApiKey = '';
const String configProjectId = '';
const String configAppId = '';
